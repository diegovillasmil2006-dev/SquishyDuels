# Squishy Duels: match stage (final-kill replay)

The repo already has `Squishy Duels Match HUD.dc.html` at the root. That page loads the 3D arena from `uploads/match-stage.html`, which was never uploaded. The final-kill replay lives in that file.

## Where the files go
Unzip this folder at the **repo root**, next to `Squishy Duels Match HUD.dc.html`.

| File | Why it's needed |
|---|---|
| `uploads/match-stage.html` | **The missing file.** It holds the bot match sim, the 60 Hz recorder, the final-kill replay and the podium. |
| `uploads/sd/avatar.js`, `fx.js`, `arena.js` | Modules the stage imports. They aren't in the repo yet. |
| `uploads/sd/kit.js`, `toon.js`, `toys.js` | Also imported by the stage. The repo only has copies inside `Squishy Duels TDMFFAhud/`, which the root page can't reach. |
| `support.js`, `uploads/hud-lib.js`, `uploads/hud-icons/*`, `uploads/*.png` | Needed to run the root Match HUD page. |

## Run it
ES modules don't load from `file://`, so serve the repo root with a local server (for example `npx serve`). Then open `Squishy Duels Match HUD.dc.html`. Bots play the match, and the replay runs after the final squish (press Space to skip).

## Porting
`REPLAY_SPEC.md` describes the recorder format, playback timing, camera shots, UI beats and messages. It also suggests a Roblox mapping and flags the parts that aren't Roblox-safe.
