# Final-kill replay: spec for the Roblox port

Source: `uploads/match-stage.html` (3D: recorder and playback) and `Squishy Duels Match HUD.dc.html` (2D overlay). The two talk through `postMessage` messages named `ms-*`. All numbers below are the prototype's values. Distances are in studs, and time is in seconds unless noted.

## 1. Recorder (match-stage.html: `record()`, `step()`)
- The sim runs at a fixed 60 Hz step (`DT = 1/60`). `record()` runs every tick until 84 ticks (1.4 s) after the final hit.
- Ring buffer: `BUF = 600` frames, which is 10 s.
- Frame stride is `N × (57 + 11)` floats, so 68 floats per player.
- At 12 players that's 816 floats per frame and 489,600 floats in total, about 1.96 MB as f32.

Per player (57 floats):
| Floats | Value |
|---|---|
| 3 | Root position |
| 1 | Root yaw |
| 3 | Root scale (squash on hit, pop on respawn) |
| 1 | Visible flag |
| 1 | Held-toy scale (0 = hidden while it's in flight) |
| 45 | 15 joints × Euler XYZ: root, waist, neck, l/r Shoulder, l/r Elbow, l/r Wrist, l/r Hip, l/r Knee, l/r Ankle (R15 Motor6Ds) |
| 3 | Root joint offset (bob/crouch) |

Per projectile, one per player (11 floats):
| Floats | Value |
|---|---|
| 1 | State: 0 hidden, 1 flying, 2 squashing on impact |
| 3 | Position |
| 4 | Quaternion |
| 3 | Scale |

Event log, `events[]` = `{ f: frame, k: kind, a: playerIndex, b: payload }`, capped at 900 entries:
`throw`, `hit [x,y,z,killerIndex]`, `poof`, `splat [x,z]`, `dash`, `dust`, `land`, `spawn`.

## 2. Playback (`startReplay`, `applyFrame`, `rspeed`, `replayStep`)
- **Window:** from 156 frames (2.6 s) before the final hit to 78 frames (1.3 s) after, clamped to what's in the buffer. That's about 3.9 s of match time.
- **Markers:** `tk` = time of the final hit. `tr` = the killer's last `throw` event before it.
- **Interpolation:** each display frame lerps between frame floor and floor+1:
  - positions, scales and joint Eulers: linear
  - yaw: shortest-angle lerp
  - projectile rotation: slerp
  - visibility and projectile state: taken from the floor frame
- **Speed curve** (match time `t`; slow = 0.25×, the HUD `slowMo` prop, clamped 0.08–1):
  1. 1× until `tk − 0.55`
  2. smoothstep down to slow by `tk − 0.15`
  3. hold slow until `tk + 0.5`
  4. smoothstep back to 1× by `tk + 0.95`
- **Hit-stop:** playback snaps to exactly `tk` and freezes for 0.16 s real time. Then:
  - camera shake impulse 0.12
  - the victim's chest position (+3 up) is projected to screen and sent as `ms-impact {x, y}` (0–1)
- **Events:** each logged event re-fires when playback crosses its frame (hit VFX at ×1.7 for the final hit, poof, splat, dust, dash ribbon, spawn). Projectile trails rebuild from the recorded positions. Particles advance on match time, so they slow down too.
- **End:** when `t ≥ duration` the stage sends `ms-replay-done`. The HUD waits 450 ms, then goes to the podium.
- **Skip:** Space or the SKIP button sends `ms-skip`, which ends playback at once.

## 3. Camera (`replayCam`)
`K` = killer, `V` = victim, `kv` = unit vector K→V on XZ, `rt` = perpendicular to `kv`. Each frame, position, look target and FOV are smoothed with `1 − e^(−4.2·dt)`; the first frame snaps.

| Shot | When (match time) | Position | Look at | FOV |
|---|---|---|---|---|
| Chase | `t < tr − 0.3` | K − kv·9.5 + rt·3.8, y = K.y + 5.2 | lerp(K, V, 0.6) + 2.6 up | 50 |
| Projectile | until `tk − 0.06` | proj + rt·7 − kv·3, y = max(proj.y + 1.2, 2.5) | lerp(proj, V + 3 up, 0.35) | 44 |
| Orbit victim | until `tk + 1.0` | radius 8, height 3.8, 0.5 rad/s (real time), starts at current angle | V + 2.6 up | 40 |
| Wide | after | mid(K, V) + rt·13, y = 9 | K + 2.4 up | 50 |

## 4. 2D overlay beats (Match HUD)
Times are from the final squish.

**0 s: final squish**
- Title overlay starts: VICTORY!/DEFEAT letters drop 50 ms apart, with sunburst.
- At 0.25 s: fanfare, plus a 2D confetti rain on a win.

**2.9 s: `ms-replay` sent**
- Letterbox bars, 76 px top and bottom, slide in over 0.5 s.
- FINAL KILL ribbon unfurls at 0.2 s; its letters drop 45 ms apart from 0.35 s.
- REPLAY pill with a blinking dot, and a mm:ss.cc timecode driven by `ms-rt`.
- SLOW-MO chip shows while speed < 0.9.
- Speed-line opacity = (1 − speed)·1.2.
- SKIP button fades in at 1 s.
- At +0.7 s, the calling card pops in bottom-left with a FINAL KILL chip (killer headshot, toy banner, Grip level, win streak).
- When playback enters slow motion: a low drone (140→55 Hz, 1.4 s) plus a noise sweep.

**`ms-impact`**
- SQUISHED! stamp at the victim's screen position, clamped to the screen: 9 letters, 40 ms apart, fading out over 2.6 s.
- Invert flash for 130 ms (2 steps).
- White flash: 650 ms, starting 90 ms later, peak 0.9 at 12%.
- Impact boom, splat and slam layers. The slam comes at +140 ms.
- 2D burst of 46 particles plus 3 rings at 0, 100 and 200 ms.
- 16 px HUD jolt.

**`ms-replay-done` + 450 ms:** podium.

## 5. Messages
| Direction | Message | Payload |
|---|---|---|
| HUD → stage | `ms-replay` | `{ slow }` starts playback |
| HUD → stage | `ms-skip` | ends playback |
| stage → HUD | `ms-rt` | every frame `{ t, dur, sp }` (sp = 0 during hit-stop) |
| stage → HUD | `ms-impact` | `{ x, y }` victim screen position, 0–1 |
| stage → HUD | `ms-rev` | `{ k: 'throw' \| 'hit' \| 'poof', fin }` SFX sync for re-fired events |
| stage → HUD | `ms-replay-done` | playback finished or skipped |

## 6. Suggested Roblox mapping
- **Record on the client.** Each client records every character it can see on a fixed 60 Hz accumulator in `RunService.Heartbeat`. 30 Hz also works, because playback interpolates.
  - Store the HumanoidRootPart CFrame and each `Motor6D.Transform`, rather than Eulers. Store the projectile CFrame, scale and state.
  - Use a `buffer` (`writef32`) ring of 600 frames. Keep the event log in parallel.
  - The server only needs to tell clients which kill is the final one. No replication is needed.
- **Play back on clones.** Clone the characters (`Archivable = true`) into a replay folder and anchor their roots. Remove the `Animate` scripts and stop the Animators.
  - Each frame, set the root CFrame and every `Motor6D.Transform` from `CFrame:Lerp` of the two nearest frames. Hide the live characters while this runs.
- **Camera:** set `CameraType = Scriptable` and drive `CFrame` and `FieldOfView` with the four shots above. Restore the old camera on done or skip.
- **Clock:** advance the playback clock by `dt × rspeed(t)` and apply the 0.16 s hit-stop at `tk`. Re-fire VFX from the event log through the same functions the live match uses.
- **UI:** one ScreenGui:
  - letterbox Frames, banner TextLabels and the REPLAY pill
  - timecode TextLabel and SLOW-MO chip
  - SKIP TextButton, plus `ContextActionService` for Space and ButtonX
  - flashes are full-screen Frames tweening `BackgroundTransparency`

## 7. Not Roblox-safe in the prototype (replace when porting)
- **Invert flash** (`backdrop-filter: invert`): use a `ColorCorrectionEffect` punch for 2 frames (Contrast +1, Saturation −1), or just the white flash.
- **Speed lines** (CSS `conic-gradient` + mask): use a rotating ImageLabel with a radial streak texture.
- **FINAL KILL banner unfurl** (`clip-path`): use a horizontal Size/Scale tween, or a `UIGradient` transparency sweep.
- **Twinkle stars on the calling card** (`clip-path` star): use a star ImageLabel.
- **Sunburst behind the title and calling card** (`repeating-conic-gradient` + mask): use a rotating sunburst ImageLabel.
- **Grey squished heads and drop shadows** (CSS `filter`): use `ImageColor3` grey plus an overlay Frame. Drop shadows become an offset duplicate image.
