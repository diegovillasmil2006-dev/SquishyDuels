# Squishy Duels — Project Handoff

Read this first, then read the files listed under "Code map" before changing anything.

## What this project is
3D art and animation previews for **Squishy Duels**, a Roblox dodgeball game where you throw squishy toys. Built with three.js 0.184 (unpkg import map + SRI hashes) as plain HTML pages with ES modules in `sd/`. **It is not a game.** The pages show polished models, animations, VFX and SFX, and buttons trigger the animations.

## Pages
1. **Squishy Duels 3D Lab.html**: done and verified. It has four views:
   - Lineup: all 14 toys at matched scale.
   - Inspect: squeeze, turnaround cameras, throw at a target, Dragon ultimate.
   - Avatar motion: R15 dash in 4 directions, jump, throw, pose sheets, frame timeline.
   - Arena 5v5: "Sweetshop Stadium" with a live 10-player simulation and particle/trail budgets.
   - Export: OBJ/GLB via `three-d-stage.js`. It strips the toon outlines before exporting.
2. **Squishy Duels FP Animations.html**: loaded and screenshot-checked (idle, inspect, squish, throw, drop/ground splat, Dragon/Birdie/Donut/Axolotl ultimates, third-person dash + run-jump). It contains:
   - A first-person viewmodel with blocky Roblox arms rendered in a separate scene, using `clearDepth`.
   - A unique inspect animation for each of the 14 toys (the `INS` table).
   - A hold-to-squish animation.
   - Dodgeball throw styles (the `THROWS` table + `THROW_STYLE` in `ults.js`).
   - A drop that leaves the toy squashed flat on the floor, face up, then peeling back up.
   - Ultimates for Birdie, Donut, Cloud Bunny, Cupcake Axolotl and Dragon.
   - A "Watch a dash" third-person mode: another player dashes F/B/L/R, jumps, or runs and jumps, plus an auto loop.
   - The setting is the new bloxy arena "Pinewood Camp" with 3 target dummies.
   - `window.SDFP.advance(sec)` steps frames for screenshots; set `SDFP.freeze = true` first so the live loop does not add real-time frames. The 3D Lab has the equivalent `window.SD.advance`.

## The user's latest request (status)
- [x] Ultimates + balance for the Epics. See `sd/ults.js`. All values are proposals.
- [x] A second arena with a different, bloxier Roblox theme. See `sd/blox.js` (Pinewood Camp: plank deck, log walls, crates, stumps, watchtowers, voxel trees, cabins, campfire). Selectable in the 3D Lab Arena tab (Sweetshop Stadium / Pinewood Camp switch, own facts + 10-player sim on the deck).
- [~] Remake the squishies to look more cartoonish with black outlines. `sd/toon.js` adds toon shading and inverted-hull outlines, and `face()` in `kit.js` makes the eyes 22% bigger and adds a `face_squish` state (chevron eyes + open mouth). `buildToy()` applies these automatically, so the 3D Lab picks them up. **Not visually checked yet.** The outline width or the skip regex may need tuning.
- [x] Grounded squash: the toy flattens on the floor with its face up. Code is in `fp.js` (`groundStart` / the `'ground'` phase). Untested.
- [x] First-person inspect animations per toy, the squish animation, and a throw animation per toy. All untested.
- [x] Third-person dash animations as seen by another player. Untested.
- Reference material from the user: `uploads/Squishy Combat effects upgrade/` (their earlier first-person prototype: spring arms, face states, hitstop, FOV kicks) and `uploads/pasted-1791395620152-0.png`. The original brief is `uploads/SQUISHY_DUELS_CLAUDE_DESIGN_ULTRAPROMPT.md`.

## Squish Island (newest: base lobby preview for the Roblox spec)
- Spec: `docs/superpowers/specs/2026-10-11-lobby-bases-capsules-design.md` (numbers checked against the user's SquishyDuels Studio code; every value [P]).
- 3D Lab → Lobby tab now opens **Squish Island** (`sd/island.js`); a switch at the top of the panel brings back the old candy plaza (`lobby.js`).
- Built Roblox-style: every static piece is a part (`add()`), merged per material after the build; studs are a canvas texture with UVs in studs (`BR`, `CT`, own `mergeUV` because kit `mergeGeos` drops UVs). The panel shows the part count against the 5,200 budget.
- Contents: 10 bases (44 × 52 st) in a ring, Donut Arch gates with name signs, statues, Birdie/Toast/Chocolate/Kitty props; the hub with brick Duel tower + blocky Dragon, 7 stalls, range, foam mats, Butter Fountain, painted zone name; garden props; beach, sea and Cloud Bunny clouds.
- Capsules animate (press, squash 58% / 125%, spring back, Coin + Grip pops for your base). The Capsules station has Tap, Spam-tap, Upgrade (confetti, spin, ring flash) and Next look; states Foam / Jelly / Marshmallow / Royal / Locked. The base station has Owned / Open plot.
- Your base is B6 (south, sky blue). `CAPSULE` in island.js holds the spec formulas.
- 2026-10-12: `docs/superpowers/specs/2026-10-12-big-number-progression-design.md` replaces the capsule numbers: 10 tiers × 10 levels, squishy powers ×1/×4/×16/×64, no hourly cap. The preview shows the 10 tier looks (Capsules station states, Next look) and the new numbers; the build plan is `docs/superpowers/plans/2026-10-12-lobby-bases-progression-plan.md`.

## Wax crunch pass (newest, matched to uploads/Video Project 2.mp4)
- Reference: a wax-coated butter squishy ("wax cracking squishies, crunchy vs soft"), pinched by two thumbs. Measured from 2.58–4.3 s: dry crackles, ~90 onsets/s, ~33 bursts/s of 1–6, ~4 ms ring, 0.5–8 kHz with peaks near 2.8 / 4.5 / 7.3 kHz, a fine micro-crackle haze between them and a 400–800 Hz foam body under the strokes. The squish audio is saved as `audio/ref-clip2.wav`. Frames are in `shots/clip2-*.jpg`, and the synth-vs-clip spectrogram is `shots/wax-compare4.png`.
- **Sound** (`squish.js`, wax layer): `SquishAudio.mode = 'wax'` (or `'slime'` for the old engine). The user found the full wax crackle too crackly, so `SquishAudio.flav` picks a flavour (`FLAV`): `'soft'` (default: muffled foam squeeze, crackles low-passed into soft pops, mostly body), `'light'` (thin dull crust) or `'crunch'` (the full clip match). The FP knead panel switches between Soft squish, Light crunch, Wax crunch and Slime; the wax HUD is hidden for Soft and Slime. Crackle grains are 1–3 micro-impulses through 3–4 damped modes, plus a snap, grit and a short body ring (`crackBuf`). Looped haze (`fizzBuf`) and body (`bodyBuf`) beds follow strain via `waxFrame()`. `crack(type, E, pan, intact)` plays bursts. Per-material flavour comes from `WAX` (foam = crunchy butter, mochi = glossy/finer, jelly = candy-glass, plush = muffled). `audio/wax-preview.wav` is rendered with the same generators.
- **Crack model** (`SoftSquish._cells/_wax`): ~200–480 Poisson-disk cells over the coat (face parts excluded). Normal swing plus displacement change loads each cell. Past its threshold (`WAX.th`) a cell cracks: a sound burst plays, neighbours are loaded (cascades) and the coat wears (`WAX.wear`). `soft.cracks`, `soft.waxLeft` (coat left) and `soft.local` (current crunchiness) drive the HUD. `rewax()` resets the coat. Calibrated with the thumb crunch to ~30–45 cracks/s on fresh coat.
- **Shader**: no visible crack lines (removed at the user's request). The wax coat shows only as a toon gloss (`sqGloss`, cache key `sd-soft-4`). Damage is still tracked per cell for sound and wear. Outline normals now bend with the surface, so folds no longer spike.
- **Thumb crunch** (`soft.thumbs(on)`): two thumb brushes on the front face press, slide together, ease off and press again (0.56 s cycle, jittered). A pinch field compresses between them, pushes a ridge toward the camera, folds the top down, and swells and curls the ends. On release it recovers at the material's rise speed.
- **FP page**, knead mode: F hold = thumb crunch (the hands come up and the thumbs track the dents; the toy tilts to show its top), Q hold = palm squeeze (was F), W = re-wax, R = face front. In knead mode the hands render in their own pass on top of the toy. Flakes (`fx` pool `flake`) pop off big cracks, with a small jolt. A wax HUD sits at the top centre. The panel has a Coat row, Sound (Wax crunch / Slime) and Compare (▶ your clip / ▶ our crunch). There is a warm vignette in knead mode. `SDFP.crunch(on)` drives the crunch for tests.

## Knead pass (matched to uploads/squish animation.mp4)
- Reference clip: Roblox squishy inspect screen. A butter stick fills the screen; the cursor kneads it. Lumps hold, the label text warps, and it recovers in about 1.5-2 s. Dragging the background tumbles it. Audio measured from the clip: squish bursts peak at 1.3-2.5 kHz, with a crackle shelf about 11 dB down out to ~12 kHz and 200-300 ms tails. Frame sheets are in `shots/clip-*.jpg` and the spectrogram is `shots/clip-audio.png`.
- `SoftSquish` rewritten around a per-vertex memory field. The finger path is stamped every 0.28 r with drag smear, so material follows the finger. Every material has a dent radius of 0.15 × max dimension; dent depth is the smaller of 0.95 r and 0.42 × min dimension. Static per-vertex noise makes lumps uneven. Per-vertex springs give the wobble. Normals come from recomputed face normals applied as a delta on the authored normals. Dragging off the silhouette starts `pullTo(ray)`: a taffy stretch with soft clamp `tanh`, slip at 1.75 × max, necking, and a body tug. Mochi keeps 22% of each pull (`plastic`).
- `SquishAudio` is slime (the user rejected the earlier foam crackle). Every sound is built from bubble grains: damped sines that chirp upward as an air pocket collapses. Banks are rendered once per slime type: clicks, blorps, squelches (a jittery bubble pulse train with crackle and a low body), sticky peels and stretch ticks. Grains are scheduled per frame: click rate follows the deformation rate, plus a few while holding. Presses layer squelch + blorp + clicks; releases peel; stretching makes ticks; snap = peel + blorp + squelch. `SLIME` sets the per-material flavour (foam = butter, mochi = glossy, jelly = clear, plush = cloud). `sfx.squish/release` route to the slime engine via `sfx.slime`. A preview render is at `audio/slime-preview.wav`.
- FP page: E = knead close-up. The toy fits the free area between picker and panel and the hands drop out of frame. A fingertip ring replaces the cursor. Drag on the toy to knead, off the edge to stretch, and on the background to spin it with inertia. F = palm squeeze, R = face front, ← → switch toys and stay in knead, E/Esc = back.

## Squeeze feel pass
- `sd/squish.js`: `SoftSquish` deforms the held/inspected toy per vertex. Palm and fingertip contacts make dents with a soft rim. Squeezed volume bulges out elsewhere. Dents hold, then creep back (slow-rise) on a per-material curve. Normals are corrected analytically. Outlines share the deformed positions. A shader patch adds crease rays around dents, dent shading and foam pores, which get stronger under pressure.
- Materials (`FEELS`/`TOY_FEEL`): foam (bread, toast, etc.), mochi (Mochi Fox), jelly (Frog, Axolotl), plush (Birdie, Cloud Bunny, Dragon).
- `SquishAudio` is procedural ASMR: a looping crackle/rustle/squelch layer whose level follows the deformation speed, so it crackles faintly during the slow rise too. It also plays contact taps, palm thumps, sticky peels (mochi) and an air-return hiss, panned toward the finger.
- FP page: F = two-palm squeeze into the dents; P = three scripted pokes. Click or drag on the toy to poke and trace dents with the thumb (`handForTip` solves the thumb-tip position). The toy moves into a closer focus pose and the world FOV narrows slightly.
- 3D Lab Inspect: Space/button = top palm press plus the old squash. Click or drag on the toy = finger dents. `prepExport` swaps in the original geometry for export.
- Superseded in part by the knead pass above.

## Lobby + arenas pass
- **3D Lab → Lobby tab (key 4):** `sd/lobby.js` builds the whole hub (232 × 184 st) with all 12 stations: spawn/promenade with floor logo + wayfinding post, duel gate + 10-pad queue (states Waiting/Full/Ready/Match found), squishy box (Available/Opening/Unavailable, odds board), shop (Purchasable/Owned/Locked), collection (all 14 toys), quest board, daily reward (7-day calendar), squeeze zone (6 foam mats + giant Kitty Bread), grip gym (Jelly + Marshmallow pads, rank tower, lock states), royal cushion (Locked/Open/In use), practice range, world kit (wall modules, gumdrop pillars/hedges, candy lamps, cotton-candy trees, benches, lollipops). Each station has Front / ¾ / Detail cameras, state buttons, footprint rings and R15 scale avatars.
- **Arenas tab (key 5):** now 5 arenas. New in `sd/arenas2.js`: Pillow Fort Park (funnel layout, blanket fort), Bubble Reef Court (rotational 180° symmetry, giant clam, aquarium tanks), Arcade Toyworks (staggered grid, brick walls, cabinets, claw machine with toy prizes). All share the court/spawn/boundary/proxy/annotation helpers and run the 10-player sim.
- Shared kit helpers (rb, pill, plate, toyAt, lollipop, lockIcon…) live in `lobby.js` and are reused by the arenas. `rb()` auto-boxes very thin parts so long bars don't get pointed ends.

## Earlier pass
- Viewmodel rebuilt to Roblox proportions: smaller blocky hands with a thumb nub, arms anchored low-outside so forearms enter from the bottom corners instead of crossing the screen.
- Squish is now a two-palm side squeeze: the toy narrows and squirts taller between the hands (axis remap of the Squisher), hands roll inward, face stays visible. Recovery keeps the same axis until settled.
- Throws start from wherever the hands currently are (no snap).
- Player spots moved off the stumps; dummies regrouped so area ultimates show a multi-hit; TP camera frames all dash endpoints clear of UI.
- Dragon ultimate head now grows in 2.4 m ahead of the camera (it used to spawn inside the camera and black out the screen). Donut roller grows into a giant tilted wheel with sprinkle spray.
- UI: compact action bar, hint moved into the panel, picker hidden in Watch-a-dash mode.

## Next steps
1. Cloud Bunny ultimate and the per-toy throw styles beyond overhand/glide still need a visual pass.
2. Make sure exported files contain no `*_outline` meshes.

## Code map (`sd/`)
- `kit.js`: geometry helpers (warpSphere, superellipsoid, taperTube, lathe), `mat()` cache, raycast `stick()`, and `face()`, which builds the `face_normal` and `face_squish` groups.
- `toys.js`: the 14 toy builders, plus `CATALOG` (rarity, flight style, squeeze springs, trail), `buildToy(id, {toon, outline})`, `Squisher` (spring squeeze that auto-swaps the face state), `DragonHead`, and `toonHead`.
- `toon.js`: `toonify()`, the outline shader (pixel-width, smoothed normals), and `prepExport()`.
- `fx.js`: `SFX` (procedural Web Audio) and `FX` (instanced particles, ribbons, rings, splats, flash).
- `avatar.js`: blocky R15 avatar builder, dash/jump/throw keyframes, and `Animator`.
- `arena.js`: Sweetshop Stadium, `COVERS`, and `ArenaSim`.
- `blox.js`: Pinewood Camp (bloxy arena).
- `lobby.js`: lobby + shared world kit. `arenas2.js`: Pillow Fort Park, Bubble Reef Court, Arcade Toyworks.
- `ults.js`: `ULTS` balance tables, `THROW_STYLE` per toy, and `INSPECT_NOTE` per toy.
- `main.js`: the 3D Lab app. `fp.js`: the first-person page.
- `three-d-stage.js`: stage web component (lighting, orbit controls, export). It was modified so exports call `window.__sdPrepExport`.

## Conventions
- Scale: 1 stud = 0.28 m (`STUD`).
- Toys have their pivot at the base center and face +Z.
- Every part is a named mesh so it can be rigged after import.
- Team colors: mint `#5FD3AE`, strawberry `#F2687F`.
- Rarity colors: Common `#7C8A96`, Uncommon `#3FAF7E`, Epic `#9A63E8`, Exclusive `#E8A23A`.
- UI font: Fredoka (+ DM Mono). UI style is cream paper with ink borders.
- All gameplay numbers (dash 14 st / 0.22 s, JumpPower 50, ultimate radii and cooldowns) are placeholders, not confirmed game values.
- The user wants concise replies and polish over game logic.
