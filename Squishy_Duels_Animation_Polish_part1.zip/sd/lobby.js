import { THREE, V3, mat, mesh, group, warpSphere, superF, lathe, mergeGeos, rng, STUD } from './kit.js';
import { toonify } from './toon.js';
import { buildToy, CATALOG, RARITY } from './toys.js';
import { buildAvatar, Animator } from './avatar.js';

/* ---------- shared world kit (used by lobby + arenas) ---------- */
const TAU = Math.PI * 2;
export const s = (v) => v * STUD;
const GC = new Map();
export const rb = (w, h, d, n = 6) => { const ar = Math.max(w, h, d) / Math.min(w, h, d); if (ar > 5) n = Math.max(n, ar > 12 ? 14 : 10); const k = [w, h, d, n].join(); if (!GC.has(k)) GC.set(k, warpSphere(superF(s(w / 2), s(h / 2), s(d / 2), n, n), 28, 18)); return GC.get(k); };
export const pill = (w, h, d, n = 2, m = 4) => { const k = ['p', w, h, d, n, m].join(); if (!GC.has(k)) GC.set(k, warpSphere(superF(s(w / 2), s(h / 2), s(d / 2), n, m), 32, 20)); return GC.get(k); };
export const B = (w, h, d) => new THREE.BoxGeometry(s(w), s(h), s(d));
export const C = (r0, r1, h, n = 32) => new THREE.CylinderGeometry(s(r0), s(r1), s(h), n);
export const SPH = (r, w = 20, h = 14) => new THREE.SphereGeometry(s(r), w, h);
export const TOR = (R, t, rs = 10, ts = 48, arc = TAU) => new THREE.TorusGeometry(s(R), s(t), rs, ts, arc);
export const bake = (list) => mergeGeos(list.map((m) => { m.updateMatrix(); return m.geometry.clone().applyMatrix4(m.matrix); }));
export const at = (geo, x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0, sc = 1) => { const m = new THREE.Mesh(geo); m.position.set(s(x), s(y), s(z)); m.rotation.set(rx, ry, rz); if (Array.isArray(sc)) m.scale.set(...sc); else m.scale.setScalar(sc); return m; };
export const put = (geo, mt, name, parent, x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0) => mesh(geo, mt, name, parent, [s(x), s(y), s(z)], [rx, ry, rz]);
export const grp = (name, parent, x = 0, y = 0, z = 0, ry = 0) => group(name, parent, [s(x), s(y), s(z)], [0, ry, 0]);
export const tm = (name, hex, rough = 0.6) => new THREE.MeshStandardMaterial({ name, color: hex, roughness: rough });
export const glow = (m, hex, k = 0.9) => { const mt = m.material; mt.color.set(hex); mt.emissive.set(k ? hex : 0x000000); mt.emissiveIntensity = k || 1; };
export function flat(r0, r1, mt, name, parent, x, z, y = 0.05, seg = 72) { const g = new THREE.RingGeometry(s(r0), s(r1), seg); g.rotateX(-Math.PI / 2); return mesh(g, mt, name, parent, [s(x), s(y), s(z)]); }
export const GUM = lathe([[0, 0], [3, 0], [3.1, 1.5], [2.7, 4.2], [1.6, 5.6], [0, 6]].map(([r, y]) => [s(r), s(y)]), 28, 18);
function rr(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
export function canvasMat(draw, w = 512, h = 128, name = 'sign_tex') { const c = document.createElement('canvas'); c.width = w; c.height = h; draw(c.getContext('2d'), w, h); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; return new THREE.MeshBasicMaterial({ name, map: t, transparent: true }); }
export function plate(text, w, h, parent, x, y, z, ry = 0, o = {}) {
  const ch = Math.max(64, Math.round((512 * h) / w));
  const m = canvasMat((g, W, H) => {
    if (o.bg !== null) { g.fillStyle = o.bg || '#FFF9F1'; rr(g, 4, 4, W - 8, H - 8, Math.min(W, H) * (o.round ?? 0.24)); g.fill(); if (o.border !== null) { g.lineWidth = 7; g.strokeStyle = o.border || '#2B2233'; g.stroke(); } }
    const fs = o.size || Math.round(H * 0.56); g.fillStyle = o.fg || '#2B2233'; g.font = `700 ${fs}px Fredoka, system-ui, sans-serif`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(text, W / 2, H / 2 + fs * 0.06, W - 28);
  }, 512, ch, 'sign_' + text.toLowerCase().replace(/[^a-z0-9]+/g, '_'));
  const p = put(new THREE.PlaneGeometry(s(w), s(h)), m, 'sign_plate', parent, x, y, z, 0, ry, 0); p.userData.noOutline = true; p.userData.noShadow = true; return p;
}
const TP = {};
export function toyAt(id, parent, x, y, z, tall, ry = 0) {
  const p = TP[id] || (TP[id] = buildToy(id, { outline: 2.2 }));
  const r = p.root.clone(true); r.scale.setScalar(s(tall) / Math.max(p.size.y, p.size.x * 0.8)); r.position.set(s(x), s(y), s(z)); r.rotation.y = ry; parent.add(r);
  r.traverse((o) => { if (o.isMesh && !o.userData.isOutline) o.castShadow = true; }); return r;
}
export function lollipop(parent, x, z, h, rad, ca, cb, M, name = 'lollipop') {
  const g = grp(name, parent, x, 0, z);
  put(C(rad * 0.09, rad * 0.09, h, 16), M.white, 'lollipop_stick', g, 0, h / 2, 0);
  const d = group('lollipop_candy', g, [0, s(h), 0], [Math.PI / 2, 0, 0]);
  put(C(rad, rad, rad * 0.25, 56), M.white, 'lollipop_disk', d);
  [0.9, 0.7, 0.5, 0.3].forEach((k, i) => { for (const f of [-1, 1]) put(TOR(rad * k, rad * 0.07, 8, 56), i % 2 ? cb : ca, 'lollipop_swirl', d, 0, f * rad * 0.12, 0, Math.PI / 2); });
  return g;
}
export function cottonTree(lists, x, z, k, ci) {
  lists.stick.push(at(C(0.45 * k, 0.6 * k, 9 * k, 10), x, 4.5 * k, z));
  [[0, 11, 0, 4.6], [2.4, 9.4, 1.2, 3.2], [-2.2, 9.8, -1, 3.4], [0.6, 13.6, -0.8, 3]].forEach(([dx, y, dz, r0]) => lists.fluff[ci].push(at(pill(r0 * 2 * k, r0 * 1.7 * k, r0 * 2 * k, 2, 2.4), x + dx * k, y * k, z + dz * k)));
}
export function lockIcon(parent, x, y, z, M, k = 1) {
  const g = grp('lock_icon', parent, x, y, z);
  put(TOR(1.1 * k, 0.32 * k, 8, 20, Math.PI), M.gold, 'lock_shackle', g, 0, 1.2 * k, 0);
  put(rb(3 * k, 2.4 * k, 1.2 * k, 6), M.gold, 'lock_body', g, 0, 0, 0);
  put(C(0.32 * k, 0.32 * k, 0.3, 12), M.dark, 'lock_keyhole_dot', g, 0, 0.2 * k, 0.6 * k, Math.PI / 2);
  return g;
}
export function checkIcon(parent, x, y, z, M, k = 1) {
  const g = grp('check_icon', parent, x, y, z);
  put(rb(1.2 * k, 2.6 * k, 0.8, 6), M.mint, 'check_stroke', g, -0.7 * k, -0.2 * k, 0, 0, 0, 0.75);
  put(rb(1.2 * k, 4.4 * k, 0.8, 6), M.mint, 'check_stroke', g, 0.7 * k, 0.5 * k, 0, 0, 0, -0.6);
  return g;
}
function ropeLine(parent, pts, h, M, name = 'rope_barrier') {
  const g = group(name, parent);
  pts.forEach(([x, z]) => { put(C(0.32, 0.4, h, 14), M.gold, 'rope_post', g, x, h / 2, z); put(SPH(0.55, 12, 8), M.gold, 'rope_post_cap', g, x, h + 0.3, z); });
  for (let i = 0; i < pts.length - 1; i++) { const [x0, z0] = pts[i], [x1, z1] = pts[i + 1], L = Math.hypot(x1 - x0, z1 - z0); put(rb(L, 0.5, 0.5, 4), M.velvet, 'rope', g, (x0 + x1) / 2, h - 0.6, (z0 + z1) / 2, 0, -Math.atan2(z1 - z0, x1 - x0), 0); }
  return g;
}
export function palette() {
  return {
    floor: mat('lobby_floor_cream', 0xF4E6D3, 0.88), seam: mat('lobby_tile_seam', 0xE8D6BF, 0.9), path: mat('path_pink', 0xF8CAD4, 0.8), curb: mat('path_curb_cream', 0xFFF6EA, 0.8),
    mint: mat('team_mint', 0x5FD3AE, 0.62), berry: mat('team_strawberry', 0xF2687F, 0.62), mintL: mat('court_mint', 0xBDEAD6, 0.8), berryL: mat('court_strawberry', 0xF8CAD4, 0.8),
    cream: mat('cushion_cream', 0xFFF3E2, 0.82), white: mat('trim_white', 0xFFFDF8, 0.6), butter: mat('butter_yellow', 0xFFD25E, 0.6), lilac: mat('lilac', 0xD9C6F5, 0.72), violet: mat('violet', 0xB892F0, 0.66),
    sky: mat('sky_blue', 0x8FD3F4, 0.65), plum: mat('scoreboard_plum', 0x3F3756, 0.6), wafer: mat('wafer', 0xE5B06C, 0.78), waferD: mat('wafer_groove', 0xC98F4B, 0.8), choc: mat('chocolate', 0x7A4A35, 0.7),
    gold: mat('gold_trim', 0xE8B84A, 0.34, { metalness: 0.35 }), royal: mat('royal_velvet', 0x7E57C2, 0.78), velvet: mat('velvet_rope', 0xC9405A, 0.8), glass: mat('glass', 0xE4F6FF, 0.12, { transparent: true, opacity: 0.26, depthWrite: false }),
    glow: mat('lamp_glow', 0xFFF6DC, 0.5, { emissive: 0xFFF1C8, emissiveIntensity: 1.2 }), red: mat('strawberry_red', 0xEE4A5C, 0.62), green: mat('frog_green', 0x6CC56A, 0.7), cork: mat('cork', 0xD9A06B, 0.92), paper: mat('card_paper', 0xFFFBF2, 0.8),
    jelly: mat('jelly_shell', 0xFF6F86, 0.18, { transparent: true, opacity: 0.62, depthWrite: false }), jellyCore: mat('jelly_core', 0xE8445C, 0.3), mallow: mat('marshmallow', 0xFFF9F4, 0.8), toast: mat('mallow_toast', 0xE2A866, 0.8),
    stone: mat('pebble', 0xE8DCCB, 0.9), dark: mat('ink_dark', 0x2B2233, 0.6), pinkFluff: mat('cotton_candy_pink', 0xF9B8D0, 0.9), blueFluff: mat('cotton_candy_blue', 0xA9DDF6, 0.9), stick: mat('candy_stick', 0xFFF4E6, 0.7),
    sky2: mat('window_sky', 0xCFEFFF, 0.5, { emissive: 0xBFE6FF, emissiveIntensity: 0.25 }),
  };
}

/* ---------- station copy (panel) ---------- */
export const STATION_INFO = {
  spawn: { what: 'Spawn medallion with the floor logo, promenade ring and a wayfinding post with one arrow per station.', foot: 'Ø29 st medallion · Ø66 st promenade · 8–10 st paths', interact: 'Spawn ring · wayfinding post', mats: 'Cream stone, strawberry rim, pink path with cream curb', keep: 'Spawn location and every exit stay clear of props' },
  duel: { what: 'Arch silhouette visible from spawn, queue stage with 5 mint + 5 strawberry pads, slot board on the lintel.', foot: '48 × 30 st stage · arch 36 st wide, 30 st tall', interact: '10 queue pads · slot board · portal', mats: 'Team-colored pillars, plum lintel, butter badge, velvet curtains', keep: 'Matchmaking rules unchanged — states are presentation only' },
  box: { what: 'Gift-box display with a lid that opens backwards, reveal pedestal with a light beam, odds board beside it.', foot: 'Ø23 st dais', interact: 'Reveal pedestal · odds board', mats: 'Strawberry box, butter ribbon, lilac dais, gold trim', keep: 'Odds and prices come from the live config — the board only lays them out' },
  shop: { what: 'Bakery counter under a striped awning, glass display case, coin stack and a preview turntable.', foot: '30 × 18 st', interact: 'Counter (buy) · turntable (preview)', mats: 'Wafer counter, mint/cream awning, glass case', keep: 'Coins only — no new currencies or prices' },
  collection: { what: 'Curved 7-bay shelf with all 14 squishies on rarity-rimmed pedestals and an inventory kiosk.', foot: '36 × 26 st', interact: 'Kiosk opens Collection UI', mats: 'Lilac bays, white shelves, rarity rims', keep: 'Shows owned/unowned from saved data; IDs unchanged' },
  quests: { what: 'Cork board in a candy frame with Daily / Weekly / Duel columns of pinned cards and progress strips.', foot: '20 × 10 st', interact: 'Board opens Quests UI', mats: 'Cork, strawberry frame, paper cards', keep: 'Quest logic and rewards unchanged' },
  daily: { what: 'Giant gift on a dais with a 7-day calendar arc behind it.', foot: 'Ø15 st dais', interact: 'Gift (claim)', mats: 'Mint gift, butter ribbon, cream day tiles', keep: 'Timer and rewards unchanged; no screen-filling confetti' },
  squeeze: { what: 'Six foam mats with refill meters around the giant Kitty Bread statue.', foot: 'Ø45 st zone · mats Ø7.6 st, 9 st apart', interact: '6 mats (one player each)', mats: 'Mint floor, cream foam mats, strawberry rims', keep: 'Coin/Grip rewards and refill limits from existing code' },
  grip: { what: 'Jelly Pad and Marshmallow Pad with level pips, rank tower between them.', foot: '44 × 24 st', interact: '2 pads · rank tower', mats: 'Translucent jelly over opaque core, toasted marshmallow', keep: 'Grip is progress, not currency; unlock requirements unchanged' },
  royal: { what: 'Tufted velvet cushion under a domed gold canopy, rope + lock when locked.', foot: 'Ø25 st dais · canopy 20 st tall', interact: 'Cushion (one player)', mats: 'Royal velvet, gold piping, lilac dome', keep: 'Existing requirement and reward' },
  practice: { what: 'Firing line with three throw spots, three bullseye targets, padded backstop and rope side rails.', foot: '36 × 40 st lane', interact: '3 throw spots · targets', mats: 'Mint lane, cream/strawberry targets, pillow backstop', keep: 'Practice never awards duel Coins for hits' },
  kit: { what: 'Wall modules (plain, shelf, window), gumdrop pillars, hedges, candy-cane lamps, cotton-candy trees, benches, lollipops.', foot: '232 × 184 st hub', interact: '—', mats: 'Cream walls, strawberry caps, pastel gumdrops', keep: 'Nothing here blocks paths or cameras' },
};

export const LOBBY = { W: 232, D: 184 };

export function buildLobby() {
  const r = rng(11), hx = LOBBY.W / 2, hz = LOBBY.D / 2, M = palette();
  const A = group('SD_LOBBY'), arch = group('LOBBY_KIT', A), annot = group('ANNOTATIONS');
  const stations = [], late = [], avatars = [];
  const camFor = (x, z, ry, o = {}) => {
    const d = o.d ?? 30, h = o.h ?? 11, th = o.th ?? 5, f = V3(Math.sin(ry), 0, Math.cos(ry)), rt = V3(Math.cos(ry), 0, -Math.sin(ry)), T = V3(s(x), s(th), s(z));
    const det = o.det || [0, 5, 4], D = T.clone().setY(s(det[1])).addScaledVector(rt, s(det[0])).addScaledVector(f, s(det[2]));
    return { Front: [T.clone().addScaledVector(f, s(d)).setY(s(h)), T], '¾ view': [T.clone().addScaledVector(f, s(d * 0.78)).addScaledVector(rt, s(d * 0.62)).setY(s(h * 1.35)), T], Detail: [D.clone().addScaledVector(f, s(o.dd ?? 11)).setY(s(det[1] + 3)), D] };
  };
  const st = (id, name, x, z, o = {}) => { const ry = o.ry ?? Math.atan2(-x, -z); const g = grp('STATION_' + id, arch, x, 0, z, ry); const rec = { id, name, x, z, ry, g, top: o.top ?? 18, foot: o.foot ?? 14, states: o.states || [], cur: (o.states || [])[0], set: () => {}, cams: camFor(x, z, ry, o.cam), info: STATION_INFO[id], entry: o.entry }; stations.push(rec); return rec; };

  /* floor */
  put(B(LOBBY.W + 90, 2, LOBBY.D + 90), M.floor, 'floor_base', arch, 0, -1, 0);
  { const sm = []; for (let x = -hx + 8; x < hx; x += 12) sm.push(at(B(0.25, 0.03, LOBBY.D), x, 0.015, 0)); for (let z = -hz + 8; z < hz; z += 12) sm.push(at(B(LOBBY.W, 0.03, 0.25), 0, 0.015, z)); put(bake(sm), M.seam, 'floor_tile_line', arch); }

  /* ---- stations ---- */
  const spawn = st('spawn', 'Spawn + Promenade', 0, 0, { ry: 0, top: 4, foot: 33, cam: { d: 30, h: 24, th: 0, det: [0, 1, 0], dd: 16 } });
  const duel = st('duel', 'Duel Gate + Queue', 0, -66, { top: 9, foot: 26, cam: { d: 72, h: 18, th: 17, det: [0, 2, 8], dd: 18 }, states: ['Waiting 3/10', 'Full 10/10', 'Ready', 'Match found'] });
  const box = st('box', 'Squishy Box', -58, -46, { top: 13, foot: 12, cam: { d: 42, h: 14, th: 6, det: [0, 4, 6], dd: 12 }, states: ['Available', 'Opening', 'Unavailable'] });
  const shop = st('shop', 'Shop Counter', 58, -46, { top: 20, foot: 16, cam: { d: 44, h: 13, th: 8, det: [0, 6, 1], dd: 13 }, states: ['Purchasable', 'Owned', 'Locked'] });
  const coll = st('collection', 'Collection Display', -86, 4, { top: 17, foot: 18, cam: { d: 40, h: 12, th: 7, det: [0, 7, -8], dd: 13 } });
  const quests = st('quests', 'Quest Board', 84, -14, { top: 19, foot: 11, cam: { d: 32, h: 10, th: 8, det: [0, 8.5, -1], dd: 11 }, states: ['Available', 'Completed', 'Claimed'] });
  const daily = st('daily', 'Daily Reward', 84, 20, { top: 12, foot: 9, cam: { d: 32, h: 10, th: 5, det: [0, 4, 0], dd: 11 }, states: ['Ready to claim', 'Claimed', 'Next in 14h'] });
  const squeeze = st('squeeze', 'Squeeze Zone', -58, 52, { top: 17, foot: 23, cam: { d: 44, h: 16, th: 6, det: [9, 2, 9], dd: 10 }, states: ['Ready', 'Refilling', 'Busy'] });
  const grip = st('grip', 'Grip Gym', -2, 70, { top: 13, foot: 23, cam: { d: 46, h: 15, th: 4, det: [-11, 3, 0], dd: 14 }, states: ['Jelly open · Marshmallow locked', 'Both open', 'Both locked'] });
  const royal = st('royal', 'Royal Cushion', 46, 58, { top: 26, foot: 13, cam: { d: 36, h: 20, th: 9, det: [0, 3, 0], dd: 14 }, states: ['Locked', 'Open', 'In use'] });
  const prac = st('practice', 'Practice Range', 88, 62, { ry: -Math.PI / 2, top: 11, foot: 20, entry: [72, 62], cam: { d: 30, h: 9, th: 5, det: [0, 6, -16], dd: 12 }, states: ['Idle', 'Target hit'] });
  const kit = st('kit', 'World Kit', -hx + 20, -hz + 6, { ry: 0, top: 10, foot: 12, cam: { d: 30, h: 12, th: 7, det: [0, 8, -2], dd: 12 } });

  /* paths + promenade */
  const pp = [], pe = [];
  const path = (x0, z0, x1, z1, w) => { const L = Math.hypot(x1 - x0, z1 - z0), ry = -Math.atan2(z1 - z0, x1 - x0), cx = (x0 + x1) / 2, cz = (z0 + z1) / 2; pe.push(at(B(L, 0.08, w + 1.8), cx, 0.04, cz, 0, ry)); pp.push(at(B(L, 0.1, w), cx, 0.05, cz, 0, ry)); for (const [x, z] of [[x1, z1]]) { pe.push(at(C(w / 2 + 0.9, w / 2 + 0.9, 0.08, 40), x, 0.04, z)); pp.push(at(C(w / 2, w / 2, 0.1, 40), x, 0.05, z)); } };
  const pathAngles = [];
  for (const S0 of stations) {
    if (S0.id === 'spawn' || S0.id === 'kit') continue;
    const [ex, ez] = S0.entry || [S0.x, S0.z], L = Math.hypot(ex, ez), ux = ex / L, uz = ez / L, end = S0.entry ? 0 : S0.foot + 1;
    path(ux * 31, uz * 31, ex - ux * end, ez - uz * end, S0.id === 'duel' ? 11 : 8); pathAngles.push(Math.atan2(uz, ux));
  }
  put(bake(pe), M.curb, 'paint_path_curb', arch); put(bake(pp), M.path, 'paint_path', arch);
  flat(22.6, 33.4, M.curb, 'paint_promenade_curb', arch, 0, 0, 0.06); flat(23.4, 32.6, M.path, 'paint_promenade', arch, 0, 0, 0.1);

  /* spawn medallion + wayfinding */
  {
    const g = spawn.g;
    put(C(14, 14.5, 0.7, 72), M.white, 'spawn_medallion', g, 0, 0.35, 0);
    put(TOR(14.25, 0.55, 10, 80), M.berry, 'spawn_medallion_rim', g, 0, 0.7, 0, Math.PI / 2);
    const logo = put(new THREE.CircleGeometry(s(12.8), 72), canvasMat((c, W, H) => {
      c.fillStyle = '#FFF9F1'; c.beginPath(); c.arc(W / 2, H / 2, W / 2, 0, TAU); c.fill();
      c.strokeStyle = '#5FD3AE'; c.lineWidth = 18; c.setLineDash([46, 26]); c.beginPath(); c.arc(W / 2, H / 2, W / 2 - 40, 0, TAU); c.stroke(); c.setLineDash([]);
      c.fillStyle = '#F8CAD4'; c.beginPath(); c.arc(W / 2, H / 2, W * 0.33, 0, TAU); c.fill();
      c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillStyle = '#2B2233'; c.font = '700 150px Fredoka, system-ui'; c.fillText('Squishy', W / 2, H / 2 - 70); c.fillStyle = '#F2687F'; c.font = '700 170px Fredoka, system-ui'; c.fillText('Duels', W / 2, H / 2 + 92);
      c.fillStyle = '#FFD25E'; for (let i = 0; i < 8; i++) { const a = (i / 8) * TAU + 0.39, x = W / 2 + Math.cos(a) * W * 0.4, y = H / 2 + Math.sin(a) * H * 0.4; c.beginPath(); for (let k = 0; k < 10; k++) { const rr2 = k % 2 ? 12 : 28, aa = (k / 10) * TAU - Math.PI / 2; c.lineTo(x + Math.cos(aa) * rr2, y + Math.sin(aa) * rr2); } c.fill(); }
    }, 1024, 1024, 'spawn_logo_tex'), 'paint_spawn_logo', g, 0, 0.72, 0, -Math.PI / 2);
    logo.userData.noOutline = true; logo.userData.noShadow = true;
    const wp = grp('wayfinding_post', g, 19, 0, 19, -Math.PI / 4);
    put(C(0.7, 0.85, 16, 16), M.white, 'wayfinding_pole', wp, 0, 8, 0); put(SPH(1.1, 16, 12), M.berry, 'wayfinding_finial', wp, 0, 16.4, 0); put(C(2.2, 2.6, 0.8, 24), M.plum, 'wayfinding_base', wp, 0, 0.4, 0);
    const dests = [['DUEL', duel, '#5FD3AE'], ['SHOP', shop, '#FFD25E'], ['BOXES', box, '#F2687F'], ['SQUEEZE', squeeze, '#8FD3F4'], ['GRIP', grip, '#B892F0'], ['RANGE', prac, '#FFB070']];
    dests.forEach(([t, d, col], i) => {
      const ang = Math.atan2(d.z - 19, d.x - 19), arm = group('wayfinding_arrow', wp, [0, s(5.4 + i * 1.75), 0], [0, -ang + Math.PI / 4, 0]);
      const sh = new THREE.Shape(); sh.moveTo(-0.4, -0.75); sh.lineTo(5.4, -0.75); sh.lineTo(6.6, 0); sh.lineTo(5.4, 0.75); sh.lineTo(-0.4, 0.75); sh.lineTo(-0.4, -0.75);
      const geo = new THREE.ExtrudeGeometry(sh, { depth: 0.35, bevelEnabled: true, bevelThickness: 0.12, bevelSize: 0.12, bevelSegments: 2 }); geo.translate(0, 0, -0.175); geo.scale(STUD, STUD, STUD);
      mesh(geo, mat('arrow_' + t.toLowerCase(), new THREE.Color(col).getHex(), 0.6), 'wayfinding_arrow_board', arm);
      for (const f of [1, -1]) plate(t, 4.6, 1.15, arm, 2.9, 0, f * 0.33, f < 0 ? Math.PI : 0, { bg: null, fg: '#2B2233' });
    });
  }

  /* duel gate + queue */
  {
    const g = duel.g, padRings = [], slots = [];
    put(rb(48, 1.6, 30, 4), M.cream, 'queue_stage', g, 0, 0.8, 0); put(rb(48.8, 0.6, 30.8, 6), M.plum, 'queue_stage_trim', g, 0, 0.3, 0);
    put(rb(22, 0.8, 5, 4), M.cream, 'queue_stage_step', g, 0, 0.4, 16.6);
    for (const e of [-1, 1]) {
      const tmx = e < 0 ? M.mint : M.berry;
      put(rb(6, 26, 6, 4), tmx, 'gate_pillar', g, e * 15, 14.6, -9); for (const y of [5.5, 17]) put(rb(7, 1.6, 7, 5), M.white, 'gate_pillar_band', g, e * 15, y, -9);
      mesh(GUM, tmx, 'gate_pillar_cap', g, [s(e * 15), s(27.6), s(-9)], null, 0.95);
      put(C(0.25, 0.25, 7, 10), M.white, 'gate_flag_pole', g, e * 15, 37, -9); put(B(4.2, 2.6, 0.2), tmx, 'gate_pennant', g, e * 15 + e * 2.2, 39.2, -9);
      put(C(0.4, 0.4, 8, 12), M.gold, 'slot_board_post', g, e * 10, 30.8, -9);
      put(rb(3.4, 22, 1.6, 3), M.royal, 'gate_curtain', g, e * 10.6, 12.6, -9.4); put(rb(4, 1, 2.2, 6), M.gold, 'gate_curtain_tie', g, e * 10.6, 9, -9.4);
    }
    put(rb(38, 6, 7, 4), M.plum, 'gate_lintel', g, 0, 24, -9); put(rb(39, 1, 7.6, 6), M.gold, 'gate_lintel_trim', g, 0, 20.6, -9);
    put(C(5.4, 5.4, 1.6, 56), M.butter, 'gate_badge', g, 0, 24, -5.2, Math.PI / 2); put(TOR(5.4, 0.4, 8, 56), M.gold, 'gate_badge_rim', g, 0, 24, -4.4);
    plate('DUELS', 8.8, 3, g, 0, 24, -4.35, 0, { bg: null, fg: '#2B2233' });
    const portal = put(new THREE.PlaneGeometry(s(18), s(22)), canvasMat((c, W, H) => { const gr = c.createRadialGradient(W / 2, H * 0.55, 10, W / 2, H * 0.55, W * 0.7); gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.35, 'rgba(255,214,120,.95)'); gr.addColorStop(0.7, 'rgba(184,146,240,.75)'); gr.addColorStop(1, 'rgba(184,146,240,0)'); c.fillStyle = gr; c.fillRect(0, 0, W, H); }, 256, 320, 'gate_portal_tex'), 'gate_portal_plate', g, 0, 12.6, -9.2);
    portal.userData.noOutline = true; portal.visible = false;
    put(rb(28, 4.6, 1.4, 5), M.plum, 'slot_board', g, 0, 37, -9);
    for (let i = 0; i < 10; i++) { const m = put(C(0.95, 0.95, 0.5, 20), tm('slot_light_' + i, 0xFFFDF8, 0.5), 'slot_light', g, -11.25 + i * 2.5, 37, -8.2, Math.PI / 2); slots.push(m); }
    put(rb(0.5, 3.4, 0.6, 4), M.white, 'slot_divider', g, 0, 37, -8.2);
    for (const e of [-1, 1]) for (let i = 0; i < 5; i++) {
      const x = e * 6.5, z = -3 + i * 3.8;
      put(C(1.6, 1.8, 0.5, 28), M.white, 'queue_pad', g, x, 1.85, z);
      const ring = put(TOR(1.75, 0.28, 8, 32), tm('queue_pad_ring_' + e + i, 0xE8DCCB, 0.5), 'queue_pad_ring', g, x, 2.05, z, Math.PI / 2); padRings.push({ ring, team: e });
      put(C(0.9, 0.9, 0.08, 20), e < 0 ? M.mintL : M.berryL, 'queue_pad_paint', g, x, 2.12, z);
    }
    plate('MINT', 4.6, 1.5, g, -6.5, 1.65, 17.1, 0, { bg: '#5FD3AE', fg: '#FFFFFF', border: null }); plate('STRAWBERRY', 6.4, 1.5, g, 6.5, 1.65, 17.1, 0, { bg: '#F2687F', fg: '#FFFFFF', border: null });
    duel.set = (k) => {
      const n = k.startsWith('Waiting') ? [2, 1] : [5, 5], gold = k === 'Ready' || k === 'Match found';
      padRings.forEach((p, i) => { const idx = i % 5, on = idx < (p.team < 0 ? n[0] : n[1]); glow(p.ring, gold ? 0xFFD25E : on ? (p.team < 0 ? 0x5FD3AE : 0xF2687F) : 0xE8DCCB, on || gold ? 0.9 : 0); });
      slots.forEach((m, i) => { const team = i < 5 ? -1 : 1, idx = i % 5, on = idx < (team < 0 ? n[0] : n[1]); glow(m, gold ? 0xFFD25E : on ? (team < 0 ? 0x5FD3AE : 0xF2687F) : 0xFFFDF8, on || gold ? 0.8 : 0); });
      portal.visible = k === 'Match found';
    };
    late.push(() => { duel.set(duel.cur); [[-6.5, -3, 'mint'], [-6.5, 0.8, 'mint'], [6.5, -3, 'strawberry']].forEach(([x, z, t], i) => addAvatar(duel.g, x, 2.1, z, 0, t, i === 0 ? 'Donut' : null)); });
  }

  /* squishy box */
  {
    const g = box.g;
    put(C(11, 11.6, 1.4, 56), M.lilac, 'box_dais', g, 0, 0.7, 0); put(TOR(11.3, 0.45, 8, 64), M.gold, 'box_dais_trim', g, 0, 1.4, 0, Math.PI / 2);
    const bx = grp('mystery_box', g, 0, 1.4, -3);
    put(rb(10, 8, 10, 6), M.berry, 'box_body', bx, 0, 4, 0); put(B(2.2, 8.06, 10.12), M.butter, 'box_ribbon', bx, 0, 4, 0); put(B(10.12, 8.06, 2.2), M.butter, 'box_ribbon', bx, 0, 4, 0);
    const lid = grp('box_lid_hinge', bx, 0, 8, -5);
    put(rb(10.9, 2, 10.9, 6), M.berry, 'box_lid', lid, 0, 1, 5); put(B(2.3, 2.06, 11), M.butter, 'box_lid_ribbon', lid, 0, 1, 5); put(B(11, 2.06, 2.3), M.butter, 'box_lid_ribbon', lid, 0, 1, 5);
    for (const e of [-1, 1]) put(TOR(1.6, 0.6, 10, 24), M.butter, 'box_bow_loop', lid, e * 1.7, 3.1, 5, 0, 0, e * 0.7);
    put(SPH(0.9, 16, 12), M.butter, 'box_bow_knot', lid, 0, 2.6, 5);
    plate('?', 3.4, 3.4, bx, 0, 4.4, 5.06, 0, { bg: '#FFF9F1', fg: '#F2687F', round: 0.5, size: 300 });
    const ped = grp('reveal_pedestal', g, 0, 1.4, 6.6);
    put(C(2.6, 3.1, 2.6, 36), M.white, 'reveal_pedestal_body', ped, 0, 1.3, 0);
    const pring = put(TOR(2.8, 0.3, 8, 40), tm('reveal_ring', 0x5FD3AE, 0.5), 'reveal_ring', ped, 0, 2.62, 0, Math.PI / 2);
    const beam = put(C(2.4, 3.4, 18, 32), new THREE.MeshBasicMaterial({ name: 'reveal_beam', color: 0xFFE7A0, transparent: true, opacity: 0.32, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide }), 'reveal_beam', ped, 0, 11.6, 0); beam.userData.noOutline = true; beam.visible = false;
    const ob = grp('odds_board', g, -10, 1.4, 2.5, 0.55);
    for (const e of [-1, 1]) put(C(0.3, 0.3, 7, 12), M.gold, 'odds_post', ob, e * 3.4, 3.5, 0);
    put(rb(7.6, 5.8, 0.6, 5), M.cream, 'odds_board_panel', ob, 0, 5.4, 0);
    const odds = put(new THREE.PlaneGeometry(s(7), s(5.2)), canvasMat((c, W, H) => {
      c.fillStyle = '#2B2233'; c.font = '700 54px Fredoka, system-ui'; c.textAlign = 'left'; c.fillText('Box odds', 34, 70);
      [['Common', '#7C8A96', 0.9], ['Uncommon', '#3FAF7E', 0.6], ['Epic', '#9A63E8', 0.3], ['Exclusive', '#E8A23A', 0.12]].forEach(([n, col, w], i) => { const y = 120 + i * 70; c.fillStyle = col; c.beginPath(); c.arc(50, y, 14, 0, TAU); c.fill(); c.fillStyle = '#2B2233'; c.font = '600 34px Fredoka, system-ui'; c.fillText(n, 78, y + 12); c.fillStyle = '#EADFD1'; c.fillRect(250, y - 10, 220, 20); c.fillStyle = col; c.fillRect(250, y - 10, 220 * w, 20); });
      c.fillStyle = '#6E6274'; c.font = '500 26px Fredoka, system-ui'; c.fillText('% from live config', 34, 420);
    }, 512, 440, 'odds_tex'), 'sign_plate', ob, 0, 5.4, 0.32); odds.userData.noOutline = true;
    const rope = ropeLine(g, [[-5, 10.4], [-2.2, 12], [2.2, 12], [5, 10.4]], 3.4, M); rope.visible = false;
    let revealToy = null;
    box.set = (k) => { lid.rotation.x = k === 'Opening' ? -1.15 : 0; beam.visible = k === 'Opening'; rope.visible = k === 'Unavailable'; glow(pring, k === 'Opening' ? 0xFFD25E : k === 'Available' ? 0x5FD3AE : 0xB9B2AA, k === 'Unavailable' ? 0 : 0.9); if (revealToy) revealToy.visible = k === 'Opening'; };
    late.push(() => { revealToy = toyAt('Birdie', ped, 0, 2.7, 0, 2.6); box.set(box.cur); });
  }

  /* shop */
  {
    const g = shop.g;
    put(rb(30, 0.8, 18, 4), M.cream, 'shop_floor', g, 0, 0.4, 0);
    put(rb(28, 15, 1.6, 4), M.berryL, 'shop_backwall', g, 0, 8.3, -6.5); put(rb(28.6, 1.2, 2.4, 6), M.berry, 'shop_backwall_cap', g, 0, 16.2, -6.5);
    for (const y of [7, 11.5]) put(rb(24, 0.6, 2.6, 6), M.white, 'shop_shelf', g, 0, y, -5.2);
    const giftCols = [M.mint, M.butter, M.violet, M.sky, M.berry];
    for (let i = 0; i < 10; i++) { const y = i < 5 ? 7.3 : 11.8, x = -9.6 + (i % 5) * 4.8; put(rb(2.6, 2.4, 2, 6), giftCols[i % 5], 'shop_gift_box', g, x, y + 1.2, -5.2); put(B(0.5, 2.46, 2.06), M.white, 'shop_gift_ribbon', g, x, y + 1.2, -5.2); }
    put(rb(22, 4.4, 5, 4), M.wafer, 'shop_counter', g, 0, 3, 1);
    for (let i = -4; i <= 4; i++) put(rb(0.45, 3.4, 0.4, 4), M.waferD, 'shop_counter_groove', g, i * 2.3, 3, 3.55);
    put(rb(23.4, 0.8, 6, 6), M.white, 'shop_counter_top', g, 0, 5.6, 1);
    for (const e of [-1, 1]) put(C(0.45, 0.45, 13.4, 16), M.white, 'awning_post', g, e * 12.6, 7.4, 6.2);
    for (let i = 0; i < 10; i++) put(B(2.64, 0.5, 13), i % 2 ? M.mint : M.white, 'awning_stripe', g, -11.88 + i * 2.64, 15, -0.1, 0.28, 0, 0);
    for (let i = 0; i < 10; i++) put(pill(2.6, 1.6, 0.5, 2, 2), i % 2 ? M.mint : M.white, 'awning_scallop', g, -11.88 + i * 2.64, 13, 6.3);
    put(C(3.6, 3.6, 0.9, 40), M.gold, 'shop_coin_emblem', g, 0, 20.4, -6.5, Math.PI / 2); put(TOR(2.6, 0.3, 8, 40), mat('coin_inner', 0xF6CF63, 0.3, { metalness: 0.35 }), 'shop_coin_ring', g, 0, 20.4, -6);
    plate('SHOP', 7, 2.2, g, 0, 3.1, 3.62, 0, { bg: '#FFF9F1' });
    put(rb(10.4, 0.6, 4.4, 6), M.white, 'display_case_base', g, -5.4, 6.3, 1); const gc = put(B(10, 3.6, 4), M.glass, 'display_case_glass', g, -5.4, 8.4, 1); gc.userData.noShadow = true;
    for (const [i, h] of [[0, 1.4], [1, 1.2], [2, 1.5]]) put(C(1.2, 1.2, 0.3, 20), M.lilac, 'display_case_riser', g, -8.6 + i * 3.2, 6.75, 1);
    for (let i = 0; i < 6; i++) put(C(0.9, 0.9, 0.35, 24), M.gold, 'coin_stack', g, 7.6 + (i % 2) * 0.12, 6.1 + i * 0.36, 1.6);
    put(C(0.9, 0.9, 0.35, 24), M.gold, 'coin_single', g, 9.6, 6.1, 0.4, 0.3, 0, 0.2);
    const tt = grp('preview_turntable', g, 9, 0.8, 9.5);
    put(C(3, 3.3, 1.4, 40), M.white, 'turntable_base', tt, 0, 0.7, 0);
    const tring = put(TOR(3.1, 0.3, 8, 40), tm('turntable_ring', 0xFFD25E, 0.5), 'turntable_ring', tt, 0, 1.45, 0, Math.PI / 2);
    const lock = lockIcon(tt, 0, 7.2, 0, M, 0.8), chk = checkIcon(tt, 0, 7.4, 0, M, 0.8);
    shop.set = (k) => { glow(tring, k === 'Purchasable' ? 0xFFD25E : k === 'Owned' ? 0x5FD3AE : 0xB9B2AA, k === 'Locked' ? 0 : 0.9); lock.visible = k === 'Locked'; chk.visible = k === 'Owned'; };
    late.push(() => { [['Toast', 1.5], ['Banana', 1.2], ['Chocolate', 1.6]].forEach(([id, h], i) => toyAt(id, g, -8.6 + i * 3.2, 6.9, 1, h, 0.2)); toyAt('Butter', tt, 0, 1.4, 0, 2.4, 0.4); shop.set(shop.cur); addAvatar(g, 2, 0.8, 9.5, Math.PI, 'mint', null); });
  }

  /* collection */
  {
    const g = coll.g, R = 15;
    put(rb(38, 0.8, 26, 4), M.cream, 'collection_floor', g, 0, 0.4, -2);
    const bays = [];
    for (let k = 0; k < 7; k++) {
      const a = (-60 + k * 20) * (Math.PI / 180), bx = Math.sin(a) * R, bz = 3 - Math.cos(a) * R, bg = grp('collection_bay_' + k, g, bx, 0.8, bz, -a); bays.push(bg);
      put(rb(5.6, 15, 1.2, 4), M.lilac, 'bay_backboard', bg, 0, 7.5, -1.6); put(rb(6.2, 1.2, 2.2, 6), M.violet, 'bay_cap', bg, 0, 15.2, -1.4);
      for (const y of [4, 9.6]) put(rb(5.4, 0.6, 3.2, 6), M.white, 'bay_shelf', bg, 0, y, 0);
    }
    for (let k = 0; k < 8; k++) { const a = (-70 + k * 20) * (Math.PI / 180); put(C(0.5, 0.5, 15.6, 12), M.white, 'bay_divider', g, Math.sin(a) * (R + 1.5), 8.6, 3 - Math.cos(a) * (R + 1.5)); }
    const ks = grp('inventory_kiosk', g, 12, 0.8, 7, -0.7);
    put(rb(3.4, 4.6, 2.4, 5), M.violet, 'kiosk_body', ks, 0, 2.3, 0); put(rb(4.2, 0.5, 3, 6), M.white, 'kiosk_top', ks, 0, 4.7, 0, -0.35);
    plate('Collection', 3.8, 1.2, ks, 0, 4.98, 0.15, 0, { bg: '#FFF9F1' }).rotation.x = -Math.PI / 2 + 0.35 + Math.PI / 2 - Math.PI / 2;
    late.push(() => {
      CATALOG.forEach((c, i) => {
        const bg = bays[i >> 1], y = (i % 2 ? 9.6 : 4) + 0.3;
        const ped = put(C(1.3, 1.4, 0.7, 24), M.white, 'collection_pedestal', bg, 0, y + 0.35, 0.3); put(TOR(1.35, 0.18, 6, 28), mat('rim_' + c.rarity.toLowerCase(), new THREE.Color(RARITY[c.rarity]).getHex(), 0.5), 'collection_rarity_rim', bg, 0, y + 0.6, 0.3, Math.PI / 2);
        toyAt(c.id, bg, 0, y + 0.7, 0.3, 2.6);
      });
    });
  }

  /* quests */
  {
    const g = quests.g, cards = [];
    put(rb(22, 0.8, 11, 4), M.cream, 'quest_floor', g, 0, 0.4, 0);
    for (const e of [-1, 1]) put(C(0.7, 0.8, 16, 16), M.wafer, 'quest_post', g, e * 10.4, 8.8, -1.6);
    put(rb(19, 12, 1, 4), M.cork, 'quest_cork', g, 0, 9, -1.6);
    for (const y of [2.6, 15.4]) put(new THREE.CapsuleGeometry(s(0.75), s(19.4), 6, 16), M.berry, 'quest_frame', g, 0, y, -1.4, 0, 0, Math.PI / 2);
    for (const e of [-1, 1]) put(new THREE.CapsuleGeometry(s(0.75), s(12.8), 6, 16), M.berry, 'quest_frame', g, e * 10, 9, -1.4);
    for (const [x, y] of [[-10, 2.6], [10, 2.6], [-10, 15.4], [10, 15.4]]) put(SPH(1.05, 16, 12), M.white, 'quest_frame_knob', g, x, y, -1.4);
    put(rb(10, 3, 1, 5), M.butter, 'quest_header', g, 0, 17.4, -1.6); plate('QUESTS', 8.6, 2.4, g, 0, 17.4, -1.06, 0, { bg: null });
    const colCols = [0xD9F4EA, 0xFFF0C4, 0xFBDDE3], colInk = [0x5FD3AE, 0xFFC93C, 0xF2687F], heads = ['Daily', 'Weekly', 'Duels'];
    for (let c = 0; c < 3; c++) {
      const x = -6 + c * 6; plate(heads[c], 4.6, 1.3, g, x, 13.6, -1.0, 0, { bg: '#FFFDF8', border: null, fg: '#2B2233' });
      for (let k = 0; k < 3; k++) {
        const y = 11.1 - k * 3.2, card = put(rb(5, 2.7, 0.24, 8), tm('quest_card_' + c + k, colCols[c], 0.85), 'quest_card', g, x, y, -1.0, 0, 0, (r() - 0.5) * 0.08);
        put(SPH(0.32, 10, 8), M.red, 'quest_pin', g, x, y + 1.05, -0.8);
        put(B(3.8, 0.42, 0.1), M.seam, 'quest_bar_line', g, x, y - 0.6, -0.84);
        const fill = put(B(3.8, 0.44, 0.12), mat('quest_fill_' + c, colInk[c], 0.5), 'quest_bar_fill_line', g, x, y - 0.6, -0.82); fill.scale.x = [0.75, 0.4, 0.15][k]; fill.position.x = s(x - 1.9 * (1 - fill.scale.x));
        const stamp = put(C(0.75, 0.75, 0.12, 24), tm('quest_stamp_' + c + k, 0x5FD3AE, 0.5), 'quest_stamp', g, x + 1.7, y + 0.35, -0.8, Math.PI / 2); stamp.visible = false;
        cards.push({ card, fill, stamp, k, c, x });
      }
    }
    quests.set = (st0) => cards.forEach((q) => { const done = q.k === 0 && st0 !== 'Available'; q.stamp.visible = done; glow(q.stamp, st0 === 'Claimed' ? 0xB9B2AA : 0x5FD3AE, 0); q.fill.scale.x = done ? 1 : [0.75, 0.4, 0.15][q.k]; q.fill.position.x = s(q.x - 1.9 * (1 - q.fill.scale.x)); q.card.material.color.set(done && st0 === 'Claimed' ? 0xEEE8E0 : colCols[q.c]); });
  }

  /* daily reward */
  {
    const g = daily.g;
    put(C(7.2, 7.6, 1.2, 48), M.lilac, 'daily_dais', g, 0, 0.6, 0); put(TOR(7.4, 0.36, 8, 56), M.gold, 'daily_dais_trim', g, 0, 1.2, 0, Math.PI / 2);
    const gift = grp('daily_gift', g, 0, 1.2, 0);
    put(rb(6.6, 5, 6.6, 6), M.mint, 'gift_body', gift, 0, 2.5, 0); put(B(1.4, 5.04, 6.66), M.butter, 'gift_ribbon', gift, 0, 2.5, 0); put(B(6.66, 5.04, 1.4), M.butter, 'gift_ribbon', gift, 0, 2.5, 0);
    const lid = grp('gift_lid_hinge', gift, 0, 5, -3.3);
    put(rb(7.2, 1.5, 7.2, 6), M.mint, 'gift_lid', lid, 0, 0.75, 3.3); put(B(1.5, 1.54, 7.3), M.butter, 'gift_lid_ribbon', lid, 0, 0.75, 3.3);
    for (const e of [-1, 1]) put(TOR(1.1, 0.42, 8, 20), M.butter, 'gift_bow_loop', lid, e * 1.2, 2.2, 3.3, 0, 0, e * 0.7); put(SPH(0.6, 14, 10), M.butter, 'gift_bow_knot', lid, 0, 1.8, 3.3);
    const dring = put(TOR(5.6, 0.3, 8, 48), tm('daily_ring', 0xFFD25E, 0.5), 'daily_ring', g, 0, 1.32, 0, Math.PI / 2);
    const stamps = [];
    for (let d = 0; d < 7; d++) {
      const a = (-48 + d * 16) * (Math.PI / 180), x = Math.sin(a) * 10, z = -Math.cos(a) * 10 + 2;
      const tile = put(rb(2.6, 3.2, 0.6, 6), d === 3 ? M.butter : M.cream, 'calendar_tile', g, x, 4.4, z, 0, -a, 0);
      put(C(0.3, 0.3, 4, 10), M.white, 'calendar_post', g, x, 2, z);
      plate(String(d + 1), 1.2, 1.2, g, x + Math.sin(-a) * 0.32, 5, z + Math.cos(-a) * 0.32, -a, { bg: null, fg: '#2B2233' });
      if (d < 3) { const c = checkIcon(g, x + Math.sin(-a) * 0.5, 3.6, z + Math.cos(-a) * 0.5, M, 0.32); c.rotation.y = -a; stamps.push(c); }
    }
    const chk = checkIcon(g, 0, 11.5, 0, M, 0.9);
    const clock = grp('next_clock', g, 0, 10.8, 0); put(C(1.6, 1.6, 0.5, 32), M.white, 'clock_face', clock, 0, 0, 0, Math.PI / 2); put(TOR(1.6, 0.25, 8, 32), M.plum, 'clock_rim', clock); put(B(0.25, 1.2, 0.2), M.plum, 'clock_hand', clock, 0, 0.5, 0.3); put(B(0.9, 0.25, 0.2), M.plum, 'clock_hand', clock, 0.4, 0, 0.3);
    daily.set = (k) => { lid.rotation.x = k === 'Claimed' ? -1.2 : 0; chk.visible = k === 'Claimed'; clock.visible = k.startsWith('Next'); glow(dring, k === 'Ready to claim' ? 0xFFD25E : 0xB9B2AA, k === 'Ready to claim' ? 0.9 : 0); };
    late.push(() => daily.set(daily.cur));
  }

  /* squeeze zone */
  {
    const g = squeeze.g, meters = [];
    put(C(22.4, 23, 0.6, 80), M.mintL, 'squeeze_floor', g, 0, 0.3, 0); put(TOR(22.6, 0.45, 8, 96), M.white, 'squeeze_floor_rim', g, 0, 0.6, 0, Math.PI / 2);
    put(C(6, 6.8, 2.8, 48), M.white, 'statue_plinth', g, 0, 1.4, 0); put(TOR(6.4, 0.5, 8, 48), M.berry, 'statue_plinth_band', g, 0, 2.2, 0, Math.PI / 2);
    plate('Kitty Bread', 5, 1.2, g, 0, 1.6, 6.75, 0, { bg: '#FFF9F1' });
    const puffy = warpSphere(superF(s(3.8), s(0.75), s(3.8), 2, 4), 40, 20);
    for (let k = 0; k < 6; k++) {
      const a = (k / 6) * TAU + Math.PI / 6, x = Math.cos(a) * 14, z = Math.sin(a) * 14, mg = grp('foam_mat_' + (k + 1), g, x, 0.6, z, -a + Math.PI / 2);
      mesh(puffy, M.cream, 'foam_mat', mg, [0, s(0.7), 0]); put(TOR(3.75, 0.42, 8, 48), M.berry, 'foam_mat_rim', mg, 0, 0.7, 0, Math.PI / 2);
      put(C(2.1, 2.1, 0.08, 36), M.berryL, 'foam_mat_center_paint', mg, 0, 1.46, 0);
      put(C(0.4, 0.45, 5, 12), M.white, 'refill_post', mg, 0, 2.5, 5.2); put(rb(1.3, 3.4, 0.8, 5), M.plum, 'refill_meter', mg, 0, 4, 5.2);
      const fill = put(B(0.8, 2.8, 0.3), tm('refill_fill_' + k, 0x5FD3AE, 0.5), 'refill_fill', mg, 0, 4, 5.62); meters.push(fill);
      plate(String(k + 1), 1.1, 1.1, mg, 0, 6.3, 5.66, 0, { bg: '#FFF9F1', round: 0.5 });
    }
    squeeze.set = (k) => meters.forEach((f, i) => { const v = k === 'Ready' ? 1 : k === 'Refilling' ? [0.2, 0.55, 0.85, 0.35, 0.7, 0.1][i] : (i % 2 ? 1 : 0.3); f.scale.y = Math.max(0.05, v); f.position.y = s(4 - 1.4 * (1 - f.scale.y)); glow(f, v >= 1 ? 0x5FD3AE : 0xFFB45E, 0.85); });
    late.push(() => { toyAt('KittyBread', g, 0, 2.8, 0, 13, 0.25); squeeze.set(squeeze.cur); const a = Math.PI / 6; addAvatar(g, Math.cos(a) * 14, 1.9, Math.sin(a) * 14, -a - Math.PI / 2, 'strawberry', 'MochiFox'); });
  }

  /* grip gym */
  {
    const g = grip.g;
    put(rb(44, 0.8, 24, 4), M.lilac, 'grip_floor', g, 0, 0.4, 0);
    for (let i = 0; i < 5; i++) put(B(42, 0.05, 0.5), M.white, 'grip_floor_line', g, 0, 0.82, -9 + i * 4.5);
    const jp = grp('jelly_pad', g, -11, 0.8, 0);
    put(rb(12, 1.4, 12, 4), M.white, 'jelly_base', jp, 0, 0.7, 0); put(rb(8.6, 3, 8.6, 3), M.jellyCore, 'jelly_core', jp, 0, 2.6, 0);
    const shell = put(rb(10.2, 4, 10.2, 3), M.jelly, 'jelly_shell', jp, 0, 3.4, 0); shell.userData.noShadow = true;
    put(rb(5.4, 0.3, 1.2, 4), M.white, 'jelly_shine', jp, -1.8, 5.4, 2.8); put(rb(1.2, 0.3, 3.4, 4), M.white, 'jelly_shine', jp, -4, 5.3, 0.6);
    const mp = grp('marshmallow_pad', g, 11, 0.8, 0);
    put(rb(12, 1.4, 12, 4), M.white, 'mallow_base', mp, 0, 0.7, 0); mesh(warpSphere(superF(s(5), s(2.2), s(5), 2, 5), 48, 24), M.mallow, 'marshmallow_pad', mp, [0, s(3.6), 0]);
    put(TOR(4.1, 0.55, 10, 48), M.toast, 'mallow_toast_ring', mp, 0, 5.55, 0, Math.PI / 2); put(C(3.6, 3.6, 0.2, 40), mat('mallow_toast_center', 0xF0C890, 0.8), 'mallow_toast_top', mp, 0, 5.72, 0);
    for (const [p, n] of [[jp, 3], [mp, 5]]) for (let i = 0; i < n; i++) put(SPH(0.42, 12, 8), M.butter, 'level_pip', p, -((n - 1) * 1.1) / 2 + i * 1.1, 1.75, 5.3);
    plate('Jelly Pad', 5.4, 1, jp, 0, 0.7, 6.06, 0, { bg: null }); plate('Marshmallow Pad', 7, 1, mp, 0, 0.7, 6.06, 0, { bg: null });
    const rk = grp('grip_rank_tower', g, 0, 0.8, -7);
    put(C(0.7, 0.8, 1, 16), M.plum, 'rank_base', rk, 0, 0.5, 0);
    [0x9AA4AE, 0x5FD3AE, 0x8FD3F4, 0xB892F0, 0xFFD25E, 0xF2687F].forEach((c, i) => put(rb(3, 1.6, 1.2, 6), mat('rank_tier_' + i, c, 0.55), 'rank_tier', rk, 0, 1.8 + i * 1.8, 0));
    put(SPH(1.1, 16, 12), M.gold, 'rank_finial', rk, 0, 12.8, 0);
    const lockJ = lockIcon(jp, 0, 9.5, 0, M), lockM = lockIcon(mp, 0, 9.5, 0, M);
    const ropeJ = ropeLine(jp, [[-6.5, 6.8], [6.5, 6.8]], 3, M), ropeM = ropeLine(mp, [[-6.5, 6.8], [6.5, 6.8]], 3, M);
    grip.set = (k) => { const jl = k === 'Both locked', ml = k !== 'Both open'; lockJ.visible = ropeJ.visible = jl; lockM.visible = ropeM.visible = ml; };
    late.push(() => grip.set(grip.cur));
  }

  /* royal cushion */
  {
    const g = royal.g;
    put(C(12.4, 13, 1, 64), M.plum, 'royal_dais', g, 0, 0.5, 0); put(C(9.4, 9.8, 1, 64), M.royal, 'royal_dais_upper', g, 0, 1.5, 0);
    for (const [R, y] of [[12.7, 1], [9.6, 2]]) put(TOR(R, 0.32, 8, 72), M.gold, 'royal_dais_trim', g, 0, y, 0, Math.PI / 2);
    const cg = grp('royal_cushion', g, 0, 2, 0);
    put(rb(8.4, 2.8, 8.4, 3), M.royal, 'royal_cushion_body', cg, 0, 1.4, 0);
    for (const e of [-1, 1]) { put(rb(8.4, 0.4, 0.4, 6), M.gold, 'royal_piping', cg, 0, 1.4, e * 4.05); put(rb(0.4, 0.4, 8.4, 6), M.gold, 'royal_piping', cg, e * 4.05, 1.4, 0); }
    for (const [x, z] of [[0, 0], [2.2, 2.2], [-2.2, 2.2], [2.2, -2.2], [-2.2, -2.2]]) put(SPH(0.38, 12, 8), M.gold, 'royal_tuft', cg, x, 2.75, z);
    for (const [x, z] of [[1, 1], [-1, 1], [1, -1], [-1, -1]]) { put(new THREE.ConeGeometry(s(0.5), s(1.6), 10), M.gold, 'royal_tassel', cg, x * 4.2, 0.5, z * 4.2, Math.PI); put(SPH(0.4, 10, 8), M.gold, 'royal_tassel_knot', cg, x * 4.2, 1.4, z * 4.2); }
    for (const [x, z] of [[1, 1], [-1, 1], [1, -1], [-1, -1]]) { put(C(0.5, 0.55, 15, 16), M.gold, 'canopy_post', g, x * 7.4, 9.5, z * 7.4); put(rb(1.8, 12, 1.8, 3), M.royal, 'canopy_curtain', g, x * 7.4, 10, z * 7.4); put(rb(2.4, 0.8, 2.4, 6), M.gold, 'canopy_curtain_tie', g, x * 7.4, 8, z * 7.4); }
    mesh(new THREE.SphereGeometry(s(11), 48, 20, 0, TAU, 0, Math.PI / 2), M.lilac, 'canopy_dome', g, [0, s(17), 0], null, [1, 0.55, 1]);
    put(TOR(11, 0.5, 8, 72), M.gold, 'canopy_dome_rim', g, 0, 17, 0, Math.PI / 2);
    put(SPH(1.2, 16, 12), M.gold, 'canopy_finial', g, 0, 23.4, 0); put(new THREE.ConeGeometry(s(0.6), s(2.4), 12), M.gold, 'canopy_finial_tip', g, 0, 25.4, 0);
    const crown = grp('royal_crown', g, 0, 10.5, 0); put(C(1.6, 1.4, 1.2, 24, ), M.gold, 'crown_band', crown); for (let k = 0; k < 5; k++) { const a = (k / 5) * TAU; put(new THREE.ConeGeometry(s(0.45), s(1.4), 8), M.gold, 'crown_point', crown, Math.cos(a) * 1.5, 1.2, Math.sin(a) * 1.5); put(SPH(0.25, 8, 6), M.red, 'crown_gem', crown, Math.cos(a) * 1.5, 2, Math.sin(a) * 1.5); }
    const rring = put(TOR(9, 0.3, 8, 64), tm('royal_ring', 0xFFD25E, 0.5), 'royal_ring', g, 0, 2.1, 0, Math.PI / 2);
    const lk = lockIcon(g, 0, 10.5, 9, M, 1.1), rope = ropeLine(g, [[-9, 11.2], [-4.5, 13], [4.5, 13], [9, 11.2]], 3.4, M);
    royal.set = (k) => { lk.visible = rope.visible = k === 'Locked'; crown.visible = k !== 'Locked'; glow(rring, 0xFFD25E, k === 'Locked' ? 0 : k === 'In use' ? 1.4 : 0.8); cg.scale.set(k === 'In use' ? 1.08 : 1, k === 'In use' ? 0.72 : 1, k === 'In use' ? 1.08 : 1); };
    late.push(() => royal.set(royal.cur));
  }

  /* practice range */
  {
    const g = prac.g, targets = [];
    put(rb(38, 0.6, 42, 4), M.mintL, 'range_floor', g, 0, 0.3, -6);
    put(B(32, 0.08, 1.2), M.white, 'range_firing_line_paint', g, 0, 0.64, 9);
    for (const x of [-10, 0, 10]) flat(1.6, 2.4, M.white, 'range_throw_spot_paint', g, x, 12, 0.66);
    for (const x of [-10, 0, 10]) {
      const tg = grp('practice_target', g, x, 0.6, -16);
      put(C(2, 2.4, 0.7, 28), M.plum, 'target_base', tg, 0, 0.35, 0); put(C(0.35, 0.35, 6.5, 12), M.white, 'target_pole', tg, 0, 3.9, 0);
      const board = grp('target_board', tg, 0, 7.6, 0);
      [[3.1, M.white], [2.4, M.berry], [1.7, M.white], [1, M.red]].forEach(([R, m], i) => put(C(R, R, 0.5, 40), m, 'target_ring_disc', board, 0, 0, i * 0.12, Math.PI / 2));
      targets.push(board);
    }
    for (let row = 0; row < 3; row++) for (let i = 0; i < 6; i++) put(rb(6.4, 3.2, 3, 3), (i + row) % 2 ? M.cream : M.lilac, 'backstop_pillow', g, -16 + i * 6.4 + (row % 2) * 3.2 - 1.6, 1.6 + row * 3, -24);
    for (const e of [-1, 1]) put(rb(2, 10.6, 3.4, 5), M.berry, 'backstop_frame', g, e * 18.6, 5.3, -24);
    for (const e of [-1, 1]) ropeLine(g, [[e * 18, 10], [e * 18, -2], [e * 18, -14]], 3.2, M, 'range_side_rail');
    const sb = grp('range_board', g, -16, 0.6, 12, 0.5);
    for (const e of [-1, 1]) put(C(0.3, 0.3, 6, 12), M.white, 'range_board_post', sb, e * 3.2, 3, 0);
    put(rb(7.6, 4.2, 0.8, 5), M.plum, 'range_board_panel', sb, 0, 6.6, 0);
    plate('PRACTICE', 6.6, 1.5, sb, 0, 7.6, 0.45, 0, { bg: null, fg: '#FFD25E' }); plate('no duel coins', 6.6, 1.2, sb, 0, 5.8, 0.45, 0, { bg: null, fg: '#FFFFFF' });
    prac.set = (k) => { targets[1].rotation.x = k === 'Target hit' ? -0.45 : 0; };
    late.push(() => addAvatar(g, 0, 0.6, 12, Math.PI, 'mint', 'Toast'));
  }

  /* world kit: walls, pillars, hedges, lamps, trees, benches, lollipops */
  {
    const wall = [], cap = [], pil = [], gumA = [], shelf = [], winD = [], winF = [], blobs = [[], [], [], []];
    const side = (x0, z0, x1, z1, nx, nz) => {
      const L = Math.hypot(x1 - x0, z1 - z0), n = Math.round(L / 16), ry = -Math.atan2(z1 - z0, x1 - x0);
      for (let i = 0; i < n; i++) {
        const t = (i + 0.5) / n, x = x0 + (x1 - x0) * t, z = z0 + (z1 - z0) * t;
        wall.push(at(rb(16, 10, 3, 4), x, 5, z, 0, ry)); cap.push(at(rb(16.4, 1.4, 3.8, 6), x, 10.4, z, 0, ry));
        if (i % 3 === 1) { for (const y of [3.4, 6.8]) { shelf.push(at(B(13, 0.6, 2.6), x + nx * 2.6, y, z + nz * 2.6, 0, ry)); for (let k = 0; k < 5; k++) { const o = -5 + k * 2.5, bxx = x + Math.cos(ry) * o + nx * 2.6, bzz = z - Math.sin(ry) * o + nz * 2.6, sh = (k + i) % 3; blobs[(k + i + (y > 4 ? 1 : 0)) % 4].push(sh === 0 ? at(SPH(0.9, 12, 8), bxx, y + 1.2, bzz) : sh === 1 ? at(rb(1.8, 1.6, 1.6, 4), bxx, y + 1.1, bzz, 0, ry + 0.3) : at(GUM, bxx, y + 0.3, bzz, 0, 0, 0, 0.3)); } } }
        if (i % 3 === 2) { winD.push(at(C(3.4, 3.4, 0.3, 36), x + nx * 1.6, 5.8, z + nz * 1.6, nz ? Math.PI / 2 : 0, 0, nx ? Math.PI / 2 : 0)); winF.push(at(TOR(3.5, 0.45, 8, 36), x + nx * 1.7, 5.8, z + nz * 1.7, 0, Math.atan2(nx, nz))); }
      }
      for (let i = 0; i <= n; i++) { const t = i / n, x = x0 + (x1 - x0) * t, z = z0 + (z1 - z0) * t; pil.push(at(C(1.9, 2.1, 12.6, 20), x, 6.3, z)); gumA.push(at(GUM, x, 12.6, z, 0, 0, 0, 0.6)); }
    };
    side(-hx, -hz, hx, -hz, 0, 1); side(-hx, hz, hx, hz, 0, -1); side(-hx, -hz, -hx, hz, 1, 0); side(hx, -hz, hx, hz, -1, 0);
    put(bake(wall), M.cream, 'kit_wall_module', arch); put(bake(cap), M.berry, 'kit_wall_cap', arch); put(bake(pil), M.lilac, 'kit_wall_pillar', arch); put(bake(gumA), M.mint, 'kit_pillar_gumdrop', arch);
    put(bake(shelf), M.white, 'kit_wall_shelf', arch); put(bake(winD), M.sky2, 'kit_window_sky', arch); put(bake(winF), M.white, 'kit_window_frame', arch);
    [M.berry, M.butter, M.sky, M.violet].forEach((m, i) => blobs[i].length && put(bake(blobs[i]), m, 'kit_shelf_toy_blob', arch));
    // promenade hedges
    const hedge = [[], [], [], []], near = (a) => pathAngles.some((p) => Math.abs(Math.atan2(Math.sin(a - p), Math.cos(a - p))) < 0.24);
    for (let a = 0, i = 0; a < TAU; a += 0.115, i++) if (!near(a)) hedge[i % 4].push(at(GUM, Math.cos(a) * 35.6, 0, Math.sin(a) * 35.6, 0, 0, 0, 0.42 + (i % 3) * 0.05));
    [M.mint, M.berry, M.butter, M.violet].forEach((m, i) => put(bake(hedge[i]), m, 'kit_gumdrop_hedge', arch));
    // lamps, trees, benches at gaps between paths
    const sorted = [...pathAngles].sort((a, b) => a - b), mids = sorted.map((a, i) => { const b = sorted[(i + 1) % sorted.length] + (i === sorted.length - 1 ? TAU : 0); return (a + b) / 2; });
    const lampW = [], lampR = [], heads = [], trees = { stick: [], fluff: [[], []] }, bench = [], benchLeg = [];
    const segD = (px, pz, [p, q]) => { const ax = p.x / STUD, az = p.z / STUD, bx = q.x / STUD, bz = q.z / STUD, dx = bx - ax, dz = bz - az, u = Math.max(0, Math.min(1, ((px - ax) * dx + (pz - az) * dz) / (dx * dx + dz * dz || 1))); return Math.hypot(ax + dx * u - px, az + dz * u - pz); };
    const shifted = ([p, q], k) => { const f = q.clone().sub(p), d = f.length(), rt = f.normalize().cross(V3(0, 1, 0)).normalize().multiplyScalar(d * k); return [p.clone().add(rt), q.clone().add(rt)]; };
    const camNear = (x, z, [p, q], rad) => { const ax = p.x / STUD, az = p.z / STUD, dx = q.x / STUD - ax, dz = q.z / STUD - az, u = ((x - ax) * dx + (z - az) * dz) / (dx * dx + dz * dz || 1); return u > -0.05 && u <= 0.85 && segD(x, z, [p, q]) < rad; };
    const blocks = (x, z, rad) => stations.some((S0) => ['Front', '¾ view', 'Detail'].some((k) => [0, 0.17, 0.3].some((sh) => camNear(x, z, sh ? shifted(S0.cams[k], sh) : S0.cams[k], rad))));
    const OFFS = [0, 0.1, -0.1, 0.2, -0.2, 0.3, -0.3];
    const freeAngle = (a0, r, rad) => { const o = OFFS.find((o) => !blocks(Math.cos(a0 + o) * r, Math.sin(a0 + o) * r, rad)); return o === undefined ? null : a0 + o; };
    mids.forEach((a0, i) => {
      const a = freeAngle(a0, 41, i % 2 === 0 ? 8 : 7);
      if (a !== null) {
        const x = Math.cos(a) * 41, z = Math.sin(a) * 41;
        if (i % 2 === 0) cottonTree(trees, x, z, 1.05, (i / 2) % 2);
        else { for (let k = 0; k < 7; k++) (k % 2 ? lampR : lampW).push(at(C(0.55, 0.55, 2, 14), x, 1 + k * 2, z)); heads.push(at(SPH(1.5, 20, 14), x, 15.5, z)); lampW.push(at(C(1.6, 1.2, 0.8, 18), x, 14.2, z)); }
      }
      if (i % 2 === 0) {
        const ab = freeAngle(a0 + 0.2, 45, 7);
        if (ab !== null) { const bxx = Math.cos(ab) * 45, bzz = Math.sin(ab) * 45, bry = -ab + Math.PI / 2; bench.push(at(rb(9, 1.2, 3, 5), bxx, 2.2, bzz, 0, bry)); for (const e of [-1, 1]) benchLeg.push(at(rb(1, 1.8, 2.6, 5), bxx + Math.cos(bry) * e * 3, 0.9, bzz - Math.sin(bry) * e * 3, 0, bry)); }
      }
    });
    put(bake(lampW), M.white, 'kit_candy_lamp_pole', arch); put(bake(lampR), M.red, 'kit_candy_lamp_stripe', arch); put(bake(heads), M.glow, 'kit_candy_lamp_globe', arch);
    put(bake(trees.stick), M.stick, 'kit_cotton_tree_stick', arch); put(bake(trees.fluff[0]), M.pinkFluff, 'kit_cotton_tree_fluff', arch); put(bake(trees.fluff[1]), M.blueFluff, 'kit_cotton_tree_fluff', arch);
    put(bake(bench), M.wafer, 'kit_wafer_bench', arch); put(bake(benchLeg), M.waferD, 'kit_wafer_bench_leg', arch);
    for (const [x, z, ca, cb] of [[-hx + 12, -hz + 12, M.berry, M.mint], [hx - 12, -hz + 12, M.mint, M.butter], [-hx + 12, hz - 12, M.violet, M.berry], [hx - 12, hz - 12, M.butter, M.sky]]) lollipop(arch, x, z, 24, 7, ca, cb, M, 'kit_lollipop');
    // kit sample bay: one of each module type, shown on its own plinth
    const g = kit.g;
    put(rb(26, 0.8, 9, 4), M.cream, 'kit_sample_plinth', g, 0, 0.4, 2);
    put(rb(6, 7, 2, 4), M.cream, 'kit_sample_wall', g, -8, 4.3, 0); put(rb(6.3, 1, 2.5, 6), M.berry, 'kit_sample_cap', g, -8, 8.2, 0);
    mesh(GUM, M.mint, 'kit_sample_gumdrop', g, [s(0), s(0.8), s(2)], null, 0.55); mesh(GUM, M.berry, 'kit_sample_gumdrop', g, [s(3.4), s(0.8), s(3)], null, 0.42);
    put(rb(6, 1, 2.4, 5), M.wafer, 'kit_sample_bench', g, 9, 2, 2); for (const e of [-1, 1]) put(rb(0.8, 1.6, 2, 5), M.waferD, 'kit_sample_bench_leg', g, 9 + e * 2.4, 1.3, 2);
  }

  toonify(arch, { width: 1.8 });
  arch.traverse((o) => { if (o.isMesh && !o.userData.isOutline) { o.receiveShadow = true; o.castShadow = !o.userData.noShadow && !/paint|floor|tile_line|sign_plate/.test(o.name); } });

  /* annotations: footprints + avatar scale ring (not exported) */
  const dimM = new THREE.MeshBasicMaterial({ color: 0x2B2233, transparent: true, opacity: 0.6 });
  for (const S0 of stations) { if (S0.id === 'kit') continue; const g = new THREE.RingGeometry(s(S0.foot + 5.6), s(S0.foot + 6), 96); g.rotateX(-Math.PI / 2); const m = new THREE.Mesh(g, dimM); m.position.set(s(S0.x), s(0.2), s(S0.z)); m.name = 'FOOTPRINT_' + S0.id; annot.add(m); }

  function addAvatar(parent, x, y, z, ry, team, holdId) {
    const av = buildAvatar({ team, name: 'ScaleAvatar_' + avatars.length }), holder = grp('scale_avatar', parent, x, y, z, ry); holder.add(av.root);
    av.root.traverse((o) => { if (o.isMesh && !o.userData.isOutline) o.castShadow = true; });
    if (holdId) { const t = toyAt(holdId, av.grip, 0, 0, 0, 1.5); t.position.set(0, 0, -0.12); }
    const an = new Animator(av); an.hold = !!holdId; an.t = avatars.length * 0.9; avatars.push({ av, an, holder });
  }
  late.forEach((f) => f());
  addAvatar(spawn.g, 4, 0.7, 7, Math.PI, 'mint', 'KittyBread'); addAvatar(spawn.g, -6, 0.7, 3, -2.2, 'strawberry', null);

  const labels = stations.map((S0) => ({ t: S0.name, p: V3(s(S0.x), s(S0.top), s(S0.z)), id: S0.id }));
  return { root: A, annot, stations, avatars, labels };
}
