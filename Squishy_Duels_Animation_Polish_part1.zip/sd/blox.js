import { THREE, V3, mat, mesh, group, lathe, mergeGeos, rng, STUD } from './kit.js';
import { COVERS } from './arena.js';
import { toonify } from './toon.js';

const S = STUD, s = (v) => v * S;
export const BLOX = { L: 170, W: 120, DECK: 0.6, name: 'Pinewood Camp' };
const bake = (list) => mergeGeos(list.map((m) => { m.updateMatrix(); return m.geometry.clone().applyMatrix4(m.matrix); }));
const B = (w, h, d) => new THREE.BoxGeometry(s(w), s(h), s(d));
const C = (r0, r1, h, n = 20) => new THREE.CylinderGeometry(s(r0), s(r1), s(h), n);

export function buildBlox() {
  COVERS.length = 0;
  const { L, W, DECK } = BLOX, r = rng(21);
  const A = group('SD_ARENA_PinewoodCamp'), play = group('PLAYABLE', A), deco = group('OUT_OF_BOUNDS_DRESSING', A);
  const M = {
    grass: mat('grass', 0x6CC24A, 0.95), grass2: mat('grass_dark', 0x58AE3E, 0.95), plank: mat('plank_light', 0xD39A5E, 0.85), plank2: mat('plank_mid', 0xC48850, 0.85), beam: mat('plank_dark', 0x8E5A33, 0.85),
    log: mat('log_bark', 0x9A6236, 0.9), logEnd: mat('log_end', 0xE8C08A, 0.85), pine: mat('pine_leaves', 0x2F8F4E, 0.9), leaf: mat('oak_leaves', 0x4FB252, 0.9), trunk: mat('trunk', 0x7A4E2E, 0.9),
    rock: mat('rock', 0x9BA2AB, 0.9), white: mat('paint_white', 0xFFF8EE, 0.7), mint: mat('team_mint', 0x5FD3AE, 0.62), berry: mat('team_strawberry', 0xF2687F, 0.62),
    roof: mat('cabin_roof', 0x6E4632, 0.85), glass: mat('cabin_window', 0x9FD8F2, 0.4), stone: mat('chimney_stone', 0xA9A39B, 0.9), fire: mat('fire_core', 0xFFB43B, 0.5, { emissive: 0xFF8A1E, emissiveIntensity: 1.4 }), fire2: mat('fire_tip', 0xFFE27A, 0.5, { emissive: 0xFFD040, emissiveIntensity: 1.6 }),
    lamp: mat('lantern_glow', 0xFFF1C2, 0.5, { emissive: 0xFFD98A, emissiveIntensity: 1.5 }), iron: mat('iron', 0x3B3640, 0.6),
  };
  const box = (w, h, d, m, name, parent, x, y, z, ry = 0) => mesh(B(w, h, d), m, name, parent, [s(x), s(y + h / 2), s(z)], [0, ry, 0]);
  mesh(B(360, 2, 300), M.grass, 'floor_base', A, [0, s(-1), 0]);
  const patches = [];
  for (let i = 0; i < 70; i++) { const x = (r() - 0.5) * 330, z = (r() - 0.5) * 280; if (Math.abs(x) < L / 2 + 6 && Math.abs(z) < W / 2 + 6) continue; const m = new THREE.Mesh(B(6 + r() * 14, 0.08, 6 + r() * 14)); m.position.set(s(x), s(0.04), s(z)); m.rotation.y = r() * 3; patches.push(m); }
  mesh(bake(patches), M.grass2, 'grass_patch', deco);
  // plank deck court
  for (let k = 0; k < W / 4; k++) box(L, DECK, 3.92, k % 2 ? M.plank : M.plank2, 'deck_plank', play, 0, 0, -W / 2 + 2 + k * 4);
  for (const sz of [-1, 1]) box(L + 2, DECK + 0.2, 1.4, M.beam, 'deck_frame', play, 0, 0, sz * (W / 2 + 0.7));
  for (const sx of [-1, 1]) box(1.4, DECK + 0.2, W + 2.8, M.beam, 'deck_frame', play, sx * (L / 2 + 0.7), 0, 0);
  const T = DECK + 0.02;
  const paint = (w, d, x, z, m, n = 'paint_line') => box(w, 0.04, d, m, n, play, x, T, z);
  paint(2, W - 2, 0, 0, M.white, 'paint_center_line'); paint(0.8, W - 2, -2, 0, M.mint); paint(0.8, W - 2, 2, 0, M.berry);
  paint(L - 2, 0.8, 0, -W / 2 + 1.5, M.white); paint(L - 2, 0.8, 0, W / 2 - 1.5, M.white); paint(0.8, W - 2, -L / 2 + 1.5, 0, M.mint); paint(0.8, W - 2, L / 2 - 1.5, 0, M.berry);
  for (let i = 0; i < 24; i++) { const a = (i / 24) * Math.PI * 2; box(2.4, 0.04, 0.8, M.white, 'paint_circle', play, Math.cos(a) * 10, T, Math.sin(a) * 10, -a + Math.PI / 2); }
  const spawns = { A: [], B: [] };
  for (const sx of [-1, 1]) { paint(0.8, W - 2, sx * 68, 0, M.white); for (const z of [-40, -20, 0, 20, 40]) { box(4.4, 0.06, 4.4, sx < 0 ? M.mint : M.berry, 'paint_spawn', play, sx * 78, T, z, Math.PI / 4); (sx < 0 ? spawns.A : spawns.B).push(V3(sx * 78, DECK, z)); } }
  const bnd = mesh(new THREE.PlaneGeometry(s(W - 2), s(9)), new THREE.MeshStandardMaterial({ name: 'boundary_jelly', color: 0xffffff, transparent: true, opacity: 0.12, depthWrite: false, side: THREE.DoubleSide }), 'BOUNDARY_center_movement_assumed', play, [0, s(DECK + 4.5), 0], [0, Math.PI / 2, 0]);
  bnd.userData.noShadow = true; bnd.userData.noOutline = true;
  // fence
  const posts = [], rails = [];
  const fenceLine = (x0, z0, x1, z1) => { const len = Math.hypot(x1 - x0, z1 - z0), n = Math.round(len / 10), ry = -Math.atan2(z1 - z0, x1 - x0); for (let i = 0; i <= n; i++) { const m = new THREE.Mesh(B(1.2, 5, 1.2)); m.position.set(s(x0 + ((x1 - x0) * i) / n), s(2.5), s(z0 + ((z1 - z0) * i) / n)); posts.push(m); } for (const h of [1.8, 3.8]) { const m = new THREE.Mesh(B(len, 0.6, 0.5)); m.position.set(s((x0 + x1) / 2), s(h), s((z0 + z1) / 2)); m.rotation.y = ry; rails.push(m); } };
  const fx = L / 2 + 3, fz = W / 2 + 3;
  fenceLine(-fx, -fz, fx, -fz); fenceLine(-fx, fz, fx, fz); fenceLine(-fx, -fz, -fx, fz); fenceLine(fx, -fz, fx, fz);
  mesh(bake(posts), M.beam, 'fence_posts', play); mesh(bake(rails), M.plank2, 'fence_rails', play);
  // cover (mirrored)
  const logWall = (name, x, z) => {
    const g = group(name, play, [s(x), s(DECK), s(z)]);
    [1.2, 3.4, 5.6].forEach((y, i) => { const lg = mesh(C(1.2, 1.2, 14, 16), M.log, 'log', g, [0, s(y), s((i - 1) * 0.3)], [Math.PI / 2, 0, 0]); for (const e of [-1, 1]) mesh(C(1.05, 1.05, 0.2, 16), M.logEnd, 'log_end', lg, [0, s(e * 7.05), 0]); });
    for (const e of [-1, 1]) mesh(B(0.8, 7.4, 0.8), M.beam, 'log_stake', g, [s(1.6), s(3.7), s(e * 6)]);
    COVERS.push({ x, z, r: 8.5, h: 6.8, kind: 'Full cover · Log Wall 14×6.8×2.4', w: 2.4, d: 14 });
  };
  const crates = (name, x, z, ry) => {
    const g = group(name, play, [s(x), s(DECK), s(z)], [0, ry, 0]);
    for (const zz of [-3.1, 3.1]) { const c = mesh(B(6, 6, 6), M.plank, 'crate', g, [0, s(3), s(zz)]); for (const f of [-1, 1]) { mesh(B(0.5, 6.1, 6.1), M.beam, 'crate_frame', c, [s(f * 2.8), 0, 0]); mesh(B(6.1, 0.7, 0.4), M.beam, 'crate_brace', c, [0, 0, s(f * 3.02)], [0, 0, 0.78]); } }
    COVERS.push({ x, z, r: 7.5, h: 6, kind: 'Full cover · Crate Pair 6×6×12.2', w: 6, d: 12.2, ry });
  };
  const stump = (name, x, z) => {
    const g = group(name, play, [s(x), s(DECK), s(z)]);
    mesh(C(3, 3.3, 3.5, 18), M.log, 'stump', g, [0, s(1.75), 0]); mesh(C(2.7, 2.7, 0.15, 18), M.logEnd, 'stump_top', g, [0, s(3.56), 0]); mesh(C(1.6, 1.6, 0.17, 18), mat('stump_ring', 0xD8A46C, 0.85), 'stump_ring', g, [0, s(3.57), 0]);
    COVERS.push({ x, z, r: 4.5, h: 3.5, kind: 'Half cover · Stump Ø6×3.5 (lower body only)' });
  };
  const tower = (name, x, team) => {
    const g = group(name, play, [s(x), s(DECK), 0]);
    box(8, 6, 8, M.plank2, 'tower_base', g, 0, 0, 0);
    for (const a of [-1, 1]) for (const b of [-1, 1]) box(1.2, 15, 1.2, M.beam, 'tower_leg', g, a * 4.2, 0, b * 4.2);
    box(10, 0.8, 10, M.plank, 'tower_floor', g, 0, 10, 0);
    for (const a of [-1, 1]) { box(10, 1.6, 0.5, M.beam, 'tower_rail', g, 0, 10.8, a * 4.8); box(0.5, 1.6, 10, M.beam, 'tower_rail', g, a * 4.8, 10.8, 0); }
    const roof = mesh(new THREE.ConeGeometry(s(8.2), s(5), 4), team, 'tower_roof', g, [0, s(17.6), 0], [0, Math.PI / 4, 0]);
    box(1.4, 3, 0.3, team, 'tower_flag', g, 0, 20, 0);
    COVERS.push({ x, z: 0, r: 6.5, h: 6, kind: 'Full cover + landmark · Watchtower (8×6 solid base)' });
    return roof;
  };
  for (const sx of [-1, 1]) {
    const t = sx < 0 ? 'A' : 'B';
    logWall('log_wall_' + t + '_S', sx * 60, -28); logWall('log_wall_' + t + '_N', sx * 60, 28);
    crates('crates_' + t + '_S', sx * 30, -18, sx * 0.3); crates('crates_' + t + '_N', sx * 30, 18, -sx * 0.3);
    stump('stump_' + t + '_S', sx * 42, -46); stump('stump_' + t + '_N', sx * 42, 46); stump('stump_' + t + '_C', sx * 14, 0);
    tower('watchtower_' + t, sx * 46, sx < 0 ? M.mint : M.berry);
  }
  // forest ring
  const trunks = [], pines = [], oaks = [];
  const tree = (x, z) => {
    const k = 0.8 + r() * 0.6, ry = r() * Math.PI;
    if (r() < 0.62) { const t = new THREE.Mesh(B(2.2 * k, 7 * k, 2.2 * k)); t.position.set(s(x), s(3.5 * k), s(z)); trunks.push(t); [[11, 5, 5.5], [8, 4.5, 9.5], [5, 4, 13]].forEach(([w, h, y]) => { const m = new THREE.Mesh(B(w * k, h * k, w * k)); m.position.set(s(x), s(y * k), s(z)); m.rotation.y = ry + y * 0.3; pines.push(m); }); }
    else { const t = new THREE.Mesh(B(2.6 * k, 8 * k, 2.6 * k)); t.position.set(s(x), s(4 * k), s(z)); trunks.push(t); [[13, 9, 12, 0, 0], [7, 6, 15, 4, 3]].forEach(([w, h, y, ox, oz]) => { const m = new THREE.Mesh(B(w * k, h * k, w * k)); m.position.set(s(x + ox * k), s(y * k), s(z + oz * k)); m.rotation.y = ry; oaks.push(m); }); }
  };
  for (let i = 0; i < 95; i++) { const a = r() * Math.PI * 2, rr = 1 + r() * 0.55, x = Math.cos(a) * (L / 2 + 34) * rr, z = Math.sin(a) * (W / 2 + 30) * rr; if (Math.abs(x) < 26 && z < 0 && z > -110) continue; tree(x, z); }
  mesh(bake(trunks), M.trunk, 'tree_trunks', deco); mesh(bake(pines), M.pine, 'pine_leaves', deco); mesh(bake(oaks), M.leaf, 'oak_leaves', deco);
  const rocks = [], bushes = [];
  for (let i = 0; i < 40; i++) { const x = (r() - 0.5) * 300, z = (r() - 0.5) * 250; if (Math.abs(x) < L / 2 + 8 && Math.abs(z) < W / 2 + 8) continue; const k = 1 + r() * 2.5; const m = new THREE.Mesh(B(2.6 * k, 1.6 * k, 2 * k)); m.position.set(s(x), s(0.5 * k), s(z)); m.rotation.set(r() * 0.3, r() * 3, r() * 0.3); (i % 2 ? rocks : bushes).push(m); }
  mesh(bake(rocks), M.rock, 'rocks', deco); mesh(bake(bushes), M.leaf, 'bushes', deco);
  // log cabins
  const cabin = (x, z, ry) => {
    const g = group('log_cabin', deco, [s(x), 0, s(z)], [0, ry, 0]);
    box(28, 12, 18, M.log, 'cabin_walls', g, 0, 0, 0);
    for (let y = 1; y < 12; y += 2) mesh(C(0.9, 0.9, 28.6, 12), M.log, 'cabin_log', g, [0, s(y), s(9.05)], [0, 0, Math.PI / 2]);
    for (const e of [-1, 1]) for (let y = 1; y < 12; y += 2) mesh(C(0.95, 0.95, 0.3, 12), M.logEnd, 'cabin_log_end', g, [s(e * 14.2), s(y), s(9.05)], [0, 0, Math.PI / 2]);
    box(4.5, 8, 0.6, M.beam, 'cabin_door', g, 0, 0, 9.4);
    for (const e of [-1, 1]) { box(5, 4, 0.5, M.glass, 'cabin_window', g, e * 8.5, 5, 9.6); box(5.8, 0.7, 0.8, M.beam, 'cabin_sill', g, e * 8.5, 4.6, 9.7); }
    for (const e of [-1, 1]) mesh(B(30, 1.4, 12), M.roof, 'cabin_roof', g, [0, s(15.2), s(e * 4.6)], [e * 0.62, 0, 0]);
    box(28, 5.6, 12, M.log, 'cabin_gable', g, 0, 12, 0);
    box(3, 8, 3, M.stone, 'cabin_chimney', g, 9, 14, -3);
    box(6, 0.8, 4, M.beam, 'cabin_porch', g, 0, 0, 11.2);
  };
  cabin(-48, -W / 2 - 34, 0); cabin(52, -W / 2 - 40, -0.25); cabin(0, W / 2 + 52, Math.PI);
  // campfire + tripod + benches
  const fire = group('campfire', deco, [0, 0, s(-W / 2 - 22)]);
  for (let i = 0; i < 9; i++) { const a = (i / 9) * Math.PI * 2; mesh(B(1.8, 1.2, 1.4), M.rock, 'fire_stone', fire, [Math.cos(a) * s(3.2), s(0.6), Math.sin(a) * s(3.2)], [0, -a, 0]); }
  for (const a of [0.5, -0.5]) mesh(C(0.55, 0.55, 5.5, 10), M.log, 'fire_log', fire, [0, s(0.6), 0], [Math.PI / 2, a, 0]);
  const flames = group('flames', fire, [0, s(0.8), 0]);
  [[0, 0, 1.6, 4.2, M.fire], [0.8, 0.4, 1.1, 3.2, M.fire2], [-0.7, -0.3, 1.0, 2.8, M.fire2], [0.1, -0.7, 0.9, 2.4, M.fire]].forEach(([x, z, rr, h, m]) => mesh(new THREE.ConeGeometry(s(rr), s(h), 4), m, 'flame', flames, [s(x), s(h / 2), s(z)], [0, r() * 3, 0]));
  for (const a of [0, 2.1, 4.2]) { const leg = mesh(B(0.35, 9.5, 0.35), M.iron, 'tripod_leg', fire, [Math.cos(a) * s(1.6), s(4.4), Math.sin(a) * s(1.6)]); leg.rotation.set(Math.sin(a) * -0.32, 0, Math.cos(a) * 0.32); }
  mesh(C(1.1, 0.9, 1.4, 12), M.iron, 'cook_pot', fire, [0, s(5.6), 0]);
  for (const e of [-1, 1]) { const b = group('bench', fire, [s(e * 9), 0, s(2)], [0, e * 0.3, 0]); mesh(C(1, 1, 9, 12), M.log, 'bench_log', b, [0, s(1.4), 0], [Math.PI / 2, 0, Math.PI / 2]); }
  // scoreboard signs + lanterns
  for (const sx of [-1, 1]) {
    const g = group('camp_scoreboard_' + (sx < 0 ? 'A' : 'B'), deco, [s(sx * (L / 2 + 20)), 0, 0], [0, -sx * Math.PI / 2, 0]);
    for (const e of [-1, 1]) box(1.6, 18, 1.6, M.trunk, 'sign_post', g, e * 10, 0, 0);
    box(24, 9, 1.4, M.plank, 'sign_board', g, 0, 10, 0); box(25.5, 1.2, 1.8, M.beam, 'sign_cap', g, 0, 19.4, 0);
    for (const e of [-1, 1]) box(9, 5, 0.3, e < 0 ? M.mint : M.berry, 'sign_team_panel', g, e * 5.5, 12, 0.85);
  }
  const lampG = [];
  for (const [x, z] of [[-fx, -fz], [fx, -fz], [-fx, fz], [fx, fz], [0, -fz], [0, fz]]) { box(1, 9, 1, M.beam, 'lantern_post', deco, x, 0, z); box(2, 2.2, 2, M.iron, 'lantern_cage', deco, x, 9, z); lampG.push(box(1.4, 1.6, 1.4, M.lamp, 'lantern_glow', deco, x, 9.3, z)); }
  toonify(A, { width: 1.7 });
  // proxies + annotations
  const proxies = group('COLLISION_PROXIES'), pm = new THREE.MeshBasicMaterial({ color: 0x3A7BFF, transparent: true, opacity: 0.22, depthWrite: false }), pm2 = new THREE.MeshBasicMaterial({ color: 0xFFB020, transparent: true, opacity: 0.25, depthWrite: false });
  for (const c of COVERS) { const m = c.w ? new THREE.Mesh(B(c.w, c.h, c.d), pm) : new THREE.Mesh(C(c.r - 1.5, c.r - 1.5, c.h, 20), c.h > 5 ? pm : pm2); m.position.set(s(c.x), s(DECK + c.h / 2), s(c.z)); if (c.ry) m.rotation.y = c.ry; m.name = 'COLL_' + c.kind; proxies.add(m); }
  const annot = group('ANNOTATIONS');
  const labels = [
    { t: `${L} studs · ${(L * S).toFixed(1)} m plank court`, p: V3(0, s(2), s(-W / 2 - 6)) },
    { t: `${W} studs · ${(W * S).toFixed(1)} m`, p: V3(s(L / 2 + 8), s(2), 0) },
    { t: 'Watchtower (full-cover base, landmark)', p: V3(s(-46), s(22), 0) },
    { t: 'Log Wall · full cover 6.8 st', p: V3(s(-60), s(9), s(28)) },
    { t: 'Crate Pair · full cover 6 st', p: V3(s(-30), s(8), s(-18)) },
    { t: 'Stump · half cover 3.5 st', p: V3(s(-42), s(5.5), s(46)) },
    { t: 'Spawn → first cover 9.6 st ≈ 0.6 s', p: V3(s(-70), s(2.5), s(10)) },
  ];
  return { root: A, proxies, annot, labels, spawns, deckY: s(DECK), flames, lamps: lampG };
}
