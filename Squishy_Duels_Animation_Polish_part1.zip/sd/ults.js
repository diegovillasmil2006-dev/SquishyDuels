// Ultimate abilities — proposed balance (studs / seconds). Gameplay values need server validation and playtest.
export const ULTS = {
  Birdie: { name: 'Flock Volley', charge: 0.35, cooldown: 35, meter: 100, stats: [['Projectiles', '3 in a 24° fan'], ['Speed', '75 st/s each'], ['Hit rule', 'direct hit only, no splash'], ['Charge', '0.35 s'], ['Cooldown', '35 s']], counter: 'Gaps between birdies open past ~30 st, so strafing between lanes beats it at range.' },
  Donut: { name: 'Sprinkle Roller', charge: 0.45, cooldown: 38, meter: 100, stats: [['Lane', '6 st wide × 60 st'], ['Speed', '55 st/s rolling'], ['Hit rule', 'touch = out; 3 st tall'], ['Charge', '0.45 s'], ['Cooldown', '38 s']], counter: 'Jump over it or step out of the lane. The sprinkle trail is cosmetic.' },
  CloudBunny: { name: 'Rain Check', charge: 0.6, cooldown: 40, meter: 100, stats: [['Zone', '7 st radius, parks 2.2 s'], ['Drops', '5, direct hit each'], ['Telegraph', '0.45 s shadow per drop'], ['Charge', '0.6 s'], ['Cooldown', '40 s']], counter: 'Every drop casts a shadow first; walk out of the zone.' },
  CupcakeAxolotl: { name: 'Bubble Pop', charge: 0.5, cooldown: 36, meter: 100, stats: [['Speed', '40 st/s, bounces once'], ['Pop', 'on contact or after 1.2 s'], ['Splash', '6 st radius'], ['Charge', '0.5 s'], ['Cooldown', '36 s']], counter: 'Slow and very visible: back off or bait the early pop.' },
  Dragon: { name: 'Dragon Burst', charge: 0.8, cooldown: 45, meter: 100, stats: [['Telegraph', '0.9 s ground ring'], ['Radius', '8 st at impact'], ['Speed', '110 st/s head'], ['Charge', '0.8 s'], ['Cooldown', '45 s']], counter: 'The ring appears before launch; leave it and the burst whiffs.' },
};
export const THROW_STYLE = {
  KittyBread: ['overhand', 'Overhand fastball'], Toast: ['sidearm', 'Sidearm card-flick'], Banana: ['spiral', 'Football spiral'], Butter: ['skip', 'Skipping-stone slide'],
  Chocolate: ['sidearm', 'Sidearm frisbee'], Birdie: ['glide', 'Two-hand launch, glides'], Donut: ['sidearm', 'Sidearm wheel spin'], Dragon: ['shove', 'Two-hand chest shove'],
  MochiFox: ['sling', 'Slingshot stretch'], StrawberryFrog: ['bounce', 'Bounce pass'], BobaBear: ['lob', 'Underhand lob'], PancakePup: ['sidearm', 'Frisbee flick'],
  CloudBunny: ['lob', 'Floaty lob'], CupcakeAxolotl: ['lob', 'Wobble lob'],
};
export const INSPECT_NOTE = {
  KittyBread: 'Lift, head-tilt with ear flick, full turn to the tail, pat on the head.', Toast: 'Card flip front to back, tap on the crust.', Banana: 'Baton twirl, then the banana-phone gag.',
  Butter: 'Tilt to the melt, spreading slide, wrapper peek.', Chocolate: 'Snap test with foil glint, flip to the back squares.', Birdie: 'Hands open, Birdie hops, tweets, flaps.',
  Donut: 'Spin on the hand, then look through the hole.', Dragon: 'Raise and roar with an ember puff, turn to show spikes and tail.', MochiFox: 'Mochi stretch between hands, snap back, tail swish.',
  StrawberryFrog: 'Hops hand to hand, ribbit, eye-bump wiggle.', BobaBear: 'Pearl-rattle shake, straw sip.', PancakePup: 'Pancake flip in the air, plop catch, sniff.',
  CloudBunny: 'Floats out of your hands, drifts with ear flops, settles back.', CupcakeAxolotl: 'Slow turntable for the gills, peek with bubbles.',
};
