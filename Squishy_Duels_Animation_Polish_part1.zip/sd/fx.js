import { THREE, V3, rng, warpSphere, superF, lathe } from './kit.js';

/* ---------- synthesized SFX (Web Audio, no assets) ---------- */
export class SFX {
  constructor() { this.ctx = null; this.on = true; this.vol = 0.7; }
  ensure() {
    if (!this.ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      const c = (this.ctx = new AC());
      this.master = c.createGain(); this.master.gain.value = this.vol;
      const comp = c.createDynamicsCompressor(); comp.threshold.value = -14; comp.ratio.value = 4;
      this.master.connect(comp); comp.connect(c.destination);
      const len = c.sampleRate * 2, b = c.createBuffer(1, len, c.sampleRate), d = b.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
      this.noiseBuf = b;
    }
    if (this.ctx.state === 'suspended') this.ctx.resume();
    return this.ctx;
  }
  setVol(v) { this.vol = v; if (this.master) this.master.gain.value = v; }
  _env(g, t0, a, peak, d) { g.gain.cancelScheduledValues(t0); g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(Math.max(peak, 0.0002), t0 + a); g.gain.exponentialRampToValueAtTime(0.0001, t0 + a + d); }
  tone(type, f0, f1, dur, gain, delay = 0, attack = 0.006) {
    const c = this.ensure(); if (!c || !this.on) return;
    const t0 = c.currentTime + delay, o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.setValueAtTime(f0, t0); o.frequency.exponentialRampToValueAtTime(Math.max(f1, 1), t0 + dur);
    this._env(g, t0, attack, gain, dur); o.connect(g); g.connect(this.master); o.start(t0); o.stop(t0 + attack + dur + 0.05);
  }
  noise(filter, f0, f1, dur, gain, delay = 0, q = 1, attack = 0.005) {
    const c = this.ensure(); if (!c || !this.on) return;
    const t0 = c.currentTime + delay, s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
    s.buffer = this.noiseBuf; s.loop = true; f.type = filter; f.Q.value = q;
    f.frequency.setValueAtTime(f0, t0); f.frequency.exponentialRampToValueAtTime(Math.max(f1, 20), t0 + attack + dur);
    this._env(g, t0, attack, gain, dur); s.connect(f); f.connect(g); g.connect(this.master);
    s.start(t0, Math.random()); s.stop(t0 + attack + dur + 0.05);
  }
  squish(p = 1) { if (this.slime) return this.slime.squish(this.slime.type, p, 0, 1); this.noise('bandpass', 1100 * p, 300 * p, 0.26, 0.45, 0, 1.3, 0.015); this.tone('sine', 540 * p, 360 * p, 0.2, 0.08, 0.02); this.tone('sine', 150 * p, 85 * p, 0.22, 0.32); }
  release(p = 1) { if (this.slime) return this.slime.release(this.slime.type, 'palm', p, 0, 1); this.tone('sine', 210 * p, 330 * p, 0.28, 0.16, 0, 0.03); this.noise('lowpass', 900, 300, 0.22, 0.12, 0, 0.7, 0.03); }
  whoosh(d = 0.5) { this.noise('bandpass', 320, 1700, d * 0.55, 0.32, 0, 0.9, d * 0.4); this.noise('bandpass', 1700, 500, d * 0.5, 0.18, d * 0.45, 0.9, 0.01); }
  splat(p = 1) { this.noise('lowpass', 2200, 260, 0.2, 0.55); this.tone('sine', 170 * p, 48, 0.24, 0.7); this.tone('triangle', 900 * p, 1500 * p, 0.05, 0.08, 0.03); }
  sparkle(n = 4) { const notes = [1318, 1568, 1760, 2093, 2349, 2637]; for (let i = 0; i < n; i++) this.tone('triangle', notes[(Math.random() * notes.length) | 0], 0, 0.28, 0.06, i * 0.045, 0.004); }
  ding() { this.tone('triangle', 880, 870, 0.4, 0.12); this.tone('sine', 1320, 1310, 0.35, 0.07, 0.01); }
  pop() { this.tone('sine', 280, 900, 0.07, 0.22); }
  tick() { this.tone('square', 1800, 1700, 0.02, 0.03); }
  dash() { this.noise('bandpass', 1400, 380, 0.2, 0.38, 0, 0.8, 0.01); this.noise('highpass', 3200, 2400, 0.05, 0.1); }
  jump() { this.tone('sine', 260, 520, 0.12, 0.1); this.noise('bandpass', 900, 1800, 0.08, 0.1); }
  land(heavy) { this.tone('sine', 130, 45, 0.16, heavy ? 0.75 : 0.45); this.noise('lowpass', 600, 150, 0.14, heavy ? 0.35 : 0.2); }
  roar() {
    const c = this.ensure(); if (!c || !this.on) return;
    const t0 = c.currentTime, o = c.createOscillator(), f = c.createBiquadFilter(), g = c.createGain(), lfo = c.createOscillator(), lg = c.createGain();
    o.type = 'sawtooth'; o.frequency.setValueAtTime(85, t0); o.frequency.exponentialRampToValueAtTime(150, t0 + 0.7);
    f.type = 'lowpass'; f.frequency.setValueAtTime(500, t0); f.frequency.exponentialRampToValueAtTime(1400, t0 + 0.7);
    lfo.frequency.value = 23; lg.gain.value = 0.12; lfo.connect(lg); lg.connect(g.gain);
    this._env(g, t0, 0.15, 0.22, 0.6); o.connect(f); f.connect(g); g.connect(this.master);
    o.start(t0); lfo.start(t0); o.stop(t0 + 0.85); lfo.stop(t0 + 0.85);
    this.noise('bandpass', 400, 1200, 0.6, 0.2, 0, 1.2, 0.15);
  }
  boom() { this.noise('lowpass', 1100, 90, 0.85, 0.85); this.tone('sine', 75, 30, 0.75, 0.95); this.sparkle(3); }
  coin() { this.tone('square', 988, 980, 0.06, 0.05); this.tone('square', 1319, 1310, 0.18, 0.05, 0.06); }
  beep(hi) { this.tone('triangle', hi ? 1046 : 523, hi ? 1040 : 520, hi ? 0.4 : 0.15, 0.12); }
}

/* ---------- particles, ribbons, rings, splats ---------- */
const MAXP = 520;
function starShape(points = 5, r0 = 1, r1 = 0.46) { const s = new THREE.Shape(); for (let i = 0; i <= points * 2; i++) { const r = i % 2 ? r1 : r0, a = (i / (points * 2)) * Math.PI * 2 + Math.PI / 2; const x = Math.cos(a) * r, y = Math.sin(a) * r; i ? s.lineTo(x, y) : s.moveTo(x, y); } return s; }
function heartShape() { const s = new THREE.Shape(); s.moveTo(0, -0.9); s.bezierCurveTo(-0.3, -0.55, -1, -0.2, -1, 0.3); s.bezierCurveTo(-1, 0.85, -0.35, 1.05, 0, 0.55); s.bezierCurveTo(0.35, 1.05, 1, 0.85, 1, 0.3); s.bezierCurveTo(1, -0.2, 0.3, -0.55, 0, -0.9); return s; }
const chip = () => { const s = new THREE.Shape(), r = [1, 0.7, 0.95, 0.62, 0.9, 0.74]; r.forEach((k, i) => { const a = (i / r.length) * Math.PI * 2; i ? s.lineTo(Math.cos(a) * k, Math.sin(a) * k) : s.moveTo(Math.cos(a) * k, Math.sin(a) * k); }); const g = new THREE.ExtrudeGeometry(s, { depth: 0.16, bevelEnabled: false }); g.center(); return g; };
const ext = (s) => { const g = new THREE.ExtrudeGeometry(s, { depth: 0.25, bevelEnabled: true, bevelThickness: 0.14, bevelSize: 0.12, bevelSegments: 2, curveSegments: 8 }); g.center(); return g; };

export class FX {
  constructor(scene) {
    this.scene = scene;
    this.root = new THREE.Group(); this.root.name = '__fx'; scene.add(this.root);
    this.pools = {}; this.ribbons = []; this.rings = []; this.splats = []; this.shake = 0; this.shakeOn = true; this.quality = 1;
    const drop = lathe([[0, -1], [0.55, -0.7], [0.62, -0.25], [0.35, 0.4], [0, 1.1]], 12, 10);
    const petal = new THREE.SphereGeometry(1, 12, 8); petal.scale(1, 0.32, 0.72);
    const G = { sphere: new THREE.IcosahedronGeometry(1, 2), cube: warpSphere(superF(1, 1, 1, 4, 4), 12, 8), capsule: new THREE.CapsuleGeometry(0.38, 1.3, 3, 8), star: ext(starShape()), heart: ext(heartShape()), petal, drop, flake: chip(), coin: new THREE.CylinderGeometry(1, 1, 0.24, 20).rotateX(Math.PI / 2) };
    for (const k in G) this._pool(k, G[k], false);
    this._pool('spark', G.star, true); this._pool('ember', G.sphere, true); this._pool('glowdrop', drop, true);
    this.light = new THREE.PointLight(0xffd8a0, 0, 6, 1.6); this.light.name = 'fx_flash'; this.root.add(this.light); this.lightT = 0; this.lightDur = 0.2; this.lightPeak = 0;
    this._m = new THREE.Matrix4(); this._q = new THREE.Quaternion(); this._s = V3(); this._c = new THREE.Color();
    const r = rng(3);
    this.splatGeos = [0, 1, 2].map((k) => { const lumps = Array.from({ length: 7 }, () => ({ a: r() * Math.PI * 2, w: 0.25 + r() * 0.35 })); return warpSphere((d) => { const ang = Math.atan2(d.z, d.x); let b = 0; for (const l of lumps) { const dd = Math.atan2(Math.sin(ang - l.a), Math.cos(ang - l.a)); b += l.w * Math.exp(-Math.pow(dd / 0.28, 2)); } const p = d.clone(); p.x *= 1 + b; p.z *= 1 + b; p.y *= 0.14; return p; }, 48, 16); });
  }
  _pool(k, geo, basic) {
    const m = basic ? new THREE.MeshBasicMaterial({ color: 0xffffff, toneMapped: false }) : new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.55, metalness: 0 });
    const im = new THREE.InstancedMesh(geo, m, MAXP); im.name = 'fx_' + k; im.frustumCulled = false; im.count = 0; im.castShadow = false;
    im.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    im.setColorAt(0, new THREE.Color(1, 1, 1));
    this.root.add(im); this.pools[k] = { im, list: [] };
  }
  emit(shape, o) {
    const pool = this.pools[shape]; if (!pool || pool.list.length >= MAXP) return;
    const axis = V3(Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5).normalize();
    pool.list.push({ p: o.pos.clone(), v: o.vel ? o.vel.clone() : V3(), g: o.gravity ?? -6, drag: o.drag ?? 1.6, life: o.life ?? 0.8, age: 0, size: o.size ?? 0.03, axis, spin: o.spin ?? 6, q: new THREE.Quaternion().setFromAxisAngle(axis, Math.random() * 6), color: new THREE.Color(o.color ?? 0xffffff), stretch: o.stretch || 0, floor: o.floor ?? -1e9 });
  }
  burst(shape, pos, n, o = {}) {
    n = Math.round(n * this.quality);
    const cols = o.colors || [o.color ?? 0xffffff];
    for (let i = 0; i < n; i++) {
      let d = V3(Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5).normalize();
      if (o.normal) { if (d.dot(o.normal) < 0) d.reflect(o.normal); d.addScaledVector(o.normal, o.bias ?? 0.6).normalize(); }
      if (o.flat) { d.y = Math.abs(d.y) * 0.25; d.normalize(); }
      const sp = (o.speed ?? 2) * (0.45 + Math.random() * 0.75);
      this.emit(shape, { pos: pos.clone().addScaledVector(d, o.spread ?? 0), vel: d.multiplyScalar(sp), color: cols[i % cols.length], size: (o.size ?? 0.03) * (0.6 + Math.random() * 0.8), life: (o.life ?? 0.7) * (0.7 + Math.random() * 0.6), gravity: o.gravity, drag: o.drag, spin: o.spin, floor: o.floor });
    }
  }
  ribbon(o) { const r = new Ribbon(this.root, o); this.ribbons.push(r); return r; }
  ring(pos, o = {}) {
    const m = new THREE.Mesh(new THREE.RingGeometry(o.inner ?? 0.82, 1, 64), new THREE.MeshBasicMaterial({ color: o.color ?? 0xffffff, transparent: true, opacity: o.opacity ?? 0.8, depthWrite: false, side: THREE.DoubleSide, toneMapped: false }));
    m.name = 'fx_ring'; m.position.copy(pos);
    m.quaternion.setFromUnitVectors(V3(0, 0, 1), (o.normal || V3(0, 1, 0)).clone().normalize());
    m.renderOrder = 3; this.root.add(m);
    const r = { m, age: 0, life: o.life ?? 0.4, r0: o.r0 ?? 0.05, r1: o.r1 ?? 0.6, op: o.opacity ?? 0.8, pulse: o.pulse || 0 };
    m.scale.setScalar(r.r0); this.rings.push(r); return r;
  }
  splat(pos, normal, color, size = 0.2, life = 1.3) {
    const m = new THREE.Mesh(this.splatGeos[(Math.random() * 3) | 0], new THREE.MeshStandardMaterial({ color, roughness: 0.4 }));
    m.name = 'fx_splat'; m.position.copy(pos); m.quaternion.setFromUnitVectors(V3(0, 1, 0), normal.clone().normalize()); m.rotateY(Math.random() * 6);
    m.scale.setScalar(0.001); this.root.add(m); this.splats.push({ m, age: 0, life, size });
  }
  flash(pos, color = 0xffd8a0, peak = 6, dur = 0.22) { this.light.position.copy(pos); this.light.color.set(color); this.lightPeak = peak * this.quality; this.lightDur = dur; this.lightT = 0; }
  kick(a) { if (this.shakeOn) this.shake = Math.max(this.shake, a); }
  stats() { let p = 0; for (const k in this.pools) p += this.pools[k].list.length; return { particles: p, ribbons: this.ribbons.filter((r) => r.n > 1).length }; }
  clear() { for (const k in this.pools) { this.pools[k].list.length = 0; this.pools[k].im.count = 0; } this.ribbons.forEach((r) => r.dispose()); this.ribbons = []; this.rings.forEach((r) => { this.root.remove(r.m); r.m.geometry.dispose(); r.m.material.dispose(); }); this.rings = []; this.splats.forEach((s) => { this.root.remove(s.m); s.m.material.dispose(); }); this.splats = []; this.shake = 0; this.scene.position.set(0, 0, 0); }
  update(dt, camera, now) {
    for (const k in this.pools) {
      const { im, list } = this.pools[k];
      let n = 0;
      for (let i = list.length - 1; i >= 0; i--) {
        const q = list[i]; q.age += dt;
        if (q.age >= q.life) { list[i] = list[list.length - 1]; list.pop(); continue; }
      }
      for (const q of list) {
        q.v.y += q.g * dt; q.v.multiplyScalar(Math.exp(-q.drag * dt)); q.p.addScaledVector(q.v, dt);
        if (q.p.y < q.floor) { q.p.y = q.floor; q.v.y *= -0.35; q.v.x *= 0.6; q.v.z *= 0.6; }
        this._q.setFromAxisAngle(q.axis, q.spin * dt); q.q.premultiply(this._q);
        const t = q.age / q.life;
        const sc = q.size * (t < 0.12 ? 1.25 * Math.sin((t / 0.12) * Math.PI * 0.62) : t > 0.6 ? 1 - Math.pow((t - 0.6) / 0.4, 1.6) : 1);
        this._s.set(sc, sc, sc);
        this._m.compose(q.p, q.q, this._s); im.setMatrixAt(n, this._m); im.setColorAt(n, q.color); n++;
      }
      im.count = n; im.instanceMatrix.needsUpdate = true; if (im.instanceColor) im.instanceColor.needsUpdate = true;
    }
    for (let i = this.ribbons.length - 1; i >= 0; i--) { const r = this.ribbons[i]; r.update(now, camera); if (r.dead) { r.dispose(); this.ribbons.splice(i, 1); } }
    for (let i = this.rings.length - 1; i >= 0; i--) {
      const r = this.rings[i]; r.age += dt; const t = Math.min(1, r.age / r.life);
      if (r.pulse) { const s = 0.5 + 0.5 * Math.sin(r.age * r.pulse); r.m.scale.setScalar(r.r1 * (0.97 + 0.03 * s)); r.m.material.opacity = r.op * (0.55 + 0.45 * s) * (t > 0.85 ? (1 - t) / 0.15 : 1); }
      else { const e = 1 - Math.pow(1 - t, 3); r.m.scale.setScalar(r.r0 + (r.r1 - r.r0) * e); r.m.material.opacity = r.op * (1 - t); }
      if (t >= 1) { this.root.remove(r.m); r.m.geometry.dispose(); r.m.material.dispose(); this.rings.splice(i, 1); }
    }
    for (let i = this.splats.length - 1; i >= 0; i--) {
      const s = this.splats[i]; s.age += dt; const t = s.age;
      let k = t < 0.1 ? (t / 0.1) * 1.18 : t < 0.2 ? 1.18 - ((t - 0.1) / 0.1) * 0.18 : 1;
      if (t > s.life - 0.4) k *= Math.max(0, (s.life - t) / 0.4);
      s.m.scale.set(s.size * k, s.size * Math.max(k, 0.001), s.size * k);
      if (t >= s.life) { this.root.remove(s.m); s.m.material.dispose(); this.splats.splice(i, 1); }
    }
    if (this.lightT < this.lightDur) { this.lightT += dt; this.light.intensity = this.lightPeak * Math.pow(Math.max(0, 1 - this.lightT / this.lightDur), 2); } else this.light.intensity = 0;
    if (this.shake > 0.0005) { const a = this.shake; this.scene.position.set((Math.random() - 0.5) * a, (Math.random() - 0.5) * a, (Math.random() - 0.5) * a); this.shake *= Math.exp(-dt * 14); }
    else if (this.scene.position.lengthSq() > 0) { this.scene.position.set(0, 0, 0); this.shake = 0; }
  }
}

/* camera-facing ribbon trail with per-vertex alpha */
export class Ribbon {
  constructor(parent, o) {
    this.max = o.max ?? 48; this.w = o.width ?? 0.1; this.life = o.life ?? 0.35; this.a = new THREE.Color(o.a ?? 0xffffff); this.b = new THREE.Color(o.b ?? 0xffffff); this.op = o.opacity ?? 0.8; this.wavy = o.wavy || 0;
    this.pts = []; this.stopped = false; this.dead = false; this.n = 0;
    const g = new THREE.BufferGeometry();
    this.pos = new Float32Array(this.max * 2 * 3); this.col = new Float32Array(this.max * 2 * 4);
    g.setAttribute('position', new THREE.BufferAttribute(this.pos, 3).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('color', new THREE.BufferAttribute(this.col, 4).setUsage(THREE.DynamicDrawUsage));
    const idx = []; for (let i = 0; i < this.max - 1; i++) { const a = i * 2; idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2); } g.setIndex(idx);
    this.mesh = new THREE.Mesh(g, new THREE.MeshBasicMaterial({ vertexColors: true, transparent: true, depthWrite: false, side: THREE.DoubleSide, toneMapped: false }));
    this.mesh.name = 'fx_ribbon'; this.mesh.frustumCulled = false; this.mesh.renderOrder = 2; parent.add(this.mesh); this.parent = parent;
    this._t = V3(); this._c = V3(); this._s = V3(); this._col = new THREE.Color();
  }
  push(p, now) { const last = this.pts[0]; if (last && last.p.distanceToSquared(p) < 1e-6) return; this.pts.unshift({ p: p.clone(), t: now }); if (this.pts.length > this.max) this.pts.pop(); }
  stop() { this.stopped = true; }
  update(now, cam) {
    while (this.pts.length && now - this.pts[this.pts.length - 1].t > this.life) this.pts.pop();
    const n = (this.n = this.pts.length);
    if (this.stopped && n < 2) { this.dead = true; return; }
    for (let i = 0; i < n; i++) {
      const p = this.pts[i].p, a = Math.min(1, (now - this.pts[i].t) / this.life);
      const pa = this.pts[Math.max(0, i - 1)].p, pb = this.pts[Math.min(n - 1, i + 1)].p;
      this._t.subVectors(pa, pb); if (this._t.lengthSq() < 1e-10) this._t.set(1, 0, 0); this._t.normalize();
      this._c.subVectors(cam.position, p).normalize();
      this._s.crossVectors(this._t, this._c); if (this._s.lengthSq() < 1e-8) this._s.set(0, 1, 0); this._s.normalize();
      const head = Math.min(1, i / 2 + 0.35);
      const w = this.w * Math.pow(1 - a, 0.8) * head * 0.5;
      const off = this.wavy ? Math.sin(i * 0.9 + now * 18) * this.w * 0.35 * (1 - a) : 0;
      const cx = p.x + this._s.x * off, cy = p.y + this._s.y * off, cz = p.z + this._s.z * off;
      this.pos.set([cx + this._s.x * w, cy + this._s.y * w, cz + this._s.z * w, cx - this._s.x * w, cy - this._s.y * w, cz - this._s.z * w], i * 6);
      this._col.copy(this.a).lerp(this.b, a);
      const al = this.op * Math.pow(1 - a, 1.4);
      this.col.set([this._col.r, this._col.g, this._col.b, al, this._col.r, this._col.g, this._col.b, al], i * 8);
    }
    const g = this.mesh.geometry; g.attributes.position.needsUpdate = true; g.attributes.color.needsUpdate = true; g.setDrawRange(0, Math.max(0, n - 1) * 6);
  }
  dispose() { this.parent.remove(this.mesh); this.mesh.geometry.dispose(); this.mesh.material.dispose(); }
}
