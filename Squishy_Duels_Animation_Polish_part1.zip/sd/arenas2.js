import { THREE, V3, mat, mesh, group, warpSphere, superF, rng, STUD } from './kit.js';
import { COVERS } from './arena.js';
import { toonify } from './toon.js';
import { s, rb, pill, B, C, SPH, TOR, bake, at, put, grp, flat, plate, toyAt, palette, canvasMat } from './lobby.js';

const TAU = Math.PI * 2;
export const ARENAS2 = {
  pillow: { L: 176, W: 128, DECK: 0.5, name: 'Pillow Fort Park' },
  reef: { L: 184, W: 136, DECK: 0.4, name: 'Bubble Reef Court' },
  arcade: { L: 168, W: 124, DECK: 0.4, name: 'Arcade Toyworks' },
};
const l2w = (x, z, ry, lx, lz) => [x + Math.cos(ry) * lx + Math.sin(ry) * lz, z - Math.sin(ry) * lx + Math.cos(ry) * lz];
function starGeo(r0, r1, depth, n = 5) { const sh = new THREE.Shape(); for (let i = 0; i <= n * 2; i++) { const a = (i / (n * 2)) * TAU + Math.PI / 2, rr = i % 2 ? r1 : r0; i ? sh.lineTo(Math.cos(a) * rr, Math.sin(a) * rr) : sh.moveTo(Math.cos(a) * rr, Math.sin(a) * rr); } const g = new THREE.ExtrudeGeometry(sh, { depth, bevelEnabled: true, bevelThickness: depth * 0.4, bevelSize: depth * 0.4, bevelSegments: 2 }); g.translate(0, 0, -depth / 2); g.scale(STUD, STUD, STUD); return g; }
function heartGeo(k, depth) { const sh = new THREE.Shape(); sh.moveTo(0, -1 * k); sh.bezierCurveTo(1.4 * k, 0, 1.1 * k, 1.2 * k, 0, 0.55 * k); sh.bezierCurveTo(-1.1 * k, 1.2 * k, -1.4 * k, 0, 0, -1 * k); const g = new THREE.ExtrudeGeometry(sh, { depth, bevelEnabled: true, bevelThickness: depth * 0.4, bevelSize: depth * 0.4, bevelSegments: 2 }); g.translate(0, 0, -depth / 2); g.scale(STUD, STUD, STUD); return g; }

function court(play, cfg, halfA, halfB, lineM, M, spawnX) {
  const { L, W, DECK } = cfg, T = DECK + 0.02;
  const box = (w, h, d, m, n, x, y, z) => put(B(w, h, d), m, n, play, x, y + h / 2, z);
  box(L / 2, DECK, W, halfA, 'court_teamA', -L / 4, 0, 0); box(L / 2, DECK, W, halfB, 'court_teamB', L / 4, 0, 0);
  const ln = (w, d, x, z, m = lineM, n = 'court_line') => box(w, 0.05, d, m, n, x, T, z);
  ln(L, 1, 0, -W / 2 + 1.5); ln(L, 1, 0, W / 2 - 1.5); ln(1, W - 2, -L / 2 + 1.5, 0, M.mint); ln(1, W - 2, L / 2 - 1.5, 0, M.berry);
  ln(2.2, W - 2, 0, 0, lineM, 'center_line_visual'); ln(0.8, W - 2, -2, 0, M.mint, 'center_edge_mint'); ln(0.8, W - 2, 2, 0, M.berry, 'center_edge_strawberry');
  flat(10, 11.2, lineM, 'center_circle_line', play, 0, 0, T + 0.06);
  const spawns = { A: [], B: [] };
  for (const sx of [-1, 1]) {
    ln(0.8, W - 2, sx * (spawnX - 10), 0, lineM, 'spawn_zone_line');
    for (const z of [-40, -20, 0, 20, 40]) { const m = sx < 0 ? M.mint : M.berry; flat(1.9, 2.6, m, 'spawn_marker', play, sx * spawnX, z, T + 0.07); flat(0, 0.8, m, 'spawn_dot_marker', play, sx * spawnX, z, T + 0.07); (sx < 0 ? spawns.A : spawns.B).push(V3(sx * spawnX, DECK, z)); }
  }
  const bnd = put(new THREE.PlaneGeometry(s(W - 2), s(9)), new THREE.MeshStandardMaterial({ name: 'boundary_jelly', color: 0xffffff, transparent: true, opacity: 0.12, depthWrite: false, side: THREE.DoubleSide }), 'BOUNDARY_center_movement_assumed', play, 0, DECK + 4.5, 0, 0, Math.PI / 2, 0);
  bnd.userData.noShadow = true; bnd.userData.noOutline = true;
  return spawns;
}
function finish(A, cfg, spawns, labels, extraDims = []) {
  const { L, W, DECK } = cfg;
  A.traverse((o) => { if (o.isMesh && !o.userData.isOutline) { o.receiveShadow = true; o.castShadow = !o.userData.noShadow && !o.material.transparent && !/floor|paint|court_|line|marker|BOUNDARY|sign_plate/.test(o.name); } });
  const proxies = group('COLLISION_PROXIES'), pm = new THREE.MeshBasicMaterial({ color: 0x3A7BFF, transparent: true, opacity: 0.22, depthWrite: false }), pm2 = new THREE.MeshBasicMaterial({ color: 0xFFB020, transparent: true, opacity: 0.25, depthWrite: false });
  for (const c of COVERS) { const m = c.w ? new THREE.Mesh(B(c.w, c.h, c.d), c.h > 5 ? pm : pm2) : new THREE.Mesh(C(c.r - 1.5, c.r - 1.5, c.h, 24), c.h > 5 ? pm : pm2); m.position.set(s(c.x), s(DECK + c.h / 2), s(c.z)); if (c.ry) m.rotation.y = c.ry; m.name = 'COLL_' + c.kind; proxies.add(m); }
  const annot = group('ANNOTATIONS'), dimM = new THREE.MeshBasicMaterial({ color: 0x2B2233 });
  const dimLine = (x0, z0, x1, z1) => { const len = Math.hypot(x1 - x0, z1 - z0), ry = -Math.atan2(z1 - z0, x1 - x0); put(B(len, 0.15, 0.4), dimM, 'dim', annot, (x0 + x1) / 2, DECK + 0.3, (z0 + z1) / 2, 0, ry, 0); for (const [x, z] of [[x0, z0], [x1, z1]]) put(B(0.4, 0.15, 3), dimM, 'dim_tick', annot, x, DECK + 0.3, z, 0, ry, 0); };
  dimLine(-L / 2, -W / 2 - 4, L / 2, -W / 2 - 4); dimLine(L / 2 + 4, -W / 2, L / 2 + 4, W / 2); extraDims.forEach((d) => dimLine(...d));
  const lab = [{ t: `${L} studs · ${(L * STUD).toFixed(1)} m playable length`, p: V3(0, s(1), s(-W / 2 - 8)) }, { t: `${W} studs · ${(W * STUD).toFixed(1)} m width`, p: V3(s(L / 2 + 9), s(1), 0) }, ...labels.map(([t, x, y, z]) => ({ t, p: V3(s(x), s(y), s(z)) }))];
  return { root: A, proxies, annot, labels: lab, spawns, deckY: s(DECK) };
}

/* ======================= PILLOW FORT PARK ======================= */
export function buildPillow() {
  COVERS.length = 0;
  const cfg = ARENAS2.pillow, { L, W, DECK } = cfg, M = palette(), r = rng(31);
  const A = group('SD_ARENA_PillowFortPark'), art = group('ART', A), play = group('PLAYABLE', art), deco = group('OUT_OF_BOUNDS_DRESSING', art), toys = group('TOY_DISPLAYS', A);
  const P = { rug: mat('playroom_rug', 0xE6DAF2, 0.95), quiltA: mat('quilt_mint', 0xCDEFE2, 0.9), quiltB: mat('quilt_strawberry', 0xFAD6DE, 0.9), stitch: mat('quilt_stitch', 0xFFFFFF, 0.8), peri: mat('periwinkle_velvet', 0xA9B4F0, 0.85), periD: mat('periwinkle_deep', 0x8C98E0, 0.85), wood: mat('toy_wood', 0xD6A06A, 0.8), woodD: mat('toy_wood_dark', 0xB07A48, 0.8), pA: mat('pillow_mint_print', 0xA9E8D2, 0.85), pB: mat('pillow_berry_print', 0xF9B3C2, 0.85) };
  put(B(400, 2, 340), P.rug, 'floor_base', art, 0, -1, 0);
  const spawns = court(play, cfg, P.quiltA, P.quiltB, P.stitch, M, 80);
  { const st = [], bt = []; for (let x = -L / 2 + 8; x < L / 2; x += 8) for (let z = -W / 2 + 2; z < W / 2 - 2; z += 3.2) st.push(at(B(0.3, 0.04, 1.8), x, DECK + 0.03, z)); for (let z = -W / 2 + 8; z < W / 2; z += 8) for (let x = -L / 2 + 2; x < L / 2 - 2; x += 3.2) st.push(at(B(1.8, 0.04, 0.3), x, DECK + 0.03, z));
    for (let x = -L / 2 + 16; x < L / 2 - 4; x += 16) for (let z = -W / 2 + 16; z < W / 2 - 4; z += 16) if (Math.abs(x) > 4) bt.push(at(SPH(0.5, 10, 6), x, DECK + 0.1, z, 0, 0, 0, [1, 0.45, 1]));
    put(bake(st), P.stitch, 'quilt_stitch_line', play); put(bake(bt), M.white, 'quilt_button', play); }
  const bands = [];
  for (const sz of [-1, 1]) for (const sx of [-1, 1]) { put(new THREE.CapsuleGeometry(s(1.9), s(L / 2 - 6), 6, 20), (sz * sx) < 0 ? P.peri : M.cream, 'bolster_pillow', play, sx * L / 4, DECK + 1.9, sz * (W / 2 + 2.2), 0, 0, Math.PI / 2); for (let k = -2; k <= 2; k++) bands.push(at(TOR(1.95, 0.28, 8, 24), sx * L / 4 + k * 16, DECK + 1.9, sz * (W / 2 + 2.2), 0, Math.PI / 2)); }
  for (const sx of [-1, 1]) { put(new THREE.CapsuleGeometry(s(1.9), s(W - 4), 6, 20), sx < 0 ? M.mint : M.berry, 'bolster_pillow_end', play, sx * (L / 2 + 2.2), DECK + 1.9, 0, Math.PI / 2); for (let k = -3; k <= 3; k++) bands.push(at(TOR(1.95, 0.28, 8, 24), sx * (L / 2 + 2.2), DECK + 1.9, k * 16)); }
  put(bake(bands), M.lilac, 'bolster_band', play);
  const nubs = [];
  const pillowWall = (name, x, z, ry, team) => {
    const g = grp(name, play, x, DECK, z, ry), pm = team < 0 ? P.pA : P.pB;
    put(pill(13, 3.9, 4.8, 3, 3), M.cream, 'pillow', g, 0, 1.95, 0); put(pill(12.4, 3.7, 4.5, 3, 3), pm, 'pillow', g, 0.3, 5.2, 0, 0, 0.03, 0.025);
    for (const [lx, ly, w] of [[0, 1.95, 6.3], [0.3, 5.2, 6]]) { for (const e of [-1, 1]) { const [wx, wz] = l2w(x, z, ry, lx + e * w, 0); nubs.push(at(pill(1.8, 1.4, 2.4, 2, 2), wx, DECK + ly, wz, 0, ry)); } put(SPH(0.42, 10, 8), M.white, 'pillow_button', g, lx, ly, 2.3); put(SPH(0.42, 10, 8), M.white, 'pillow_button', g, lx, ly, -2.3); }
    COVERS.push({ x, z, r: 8, h: 7, kind: 'Full cover · Pillow Wall 13×7×4.8', ry, w: 13, d: 4.8 });
  };
  const fort = (name, x, team) => {
    const g = grp(name, play, x, DECK, 0, team < 0 ? 0 : Math.PI), pm = team < 0 ? P.pA : P.pB, tmx = team < 0 ? M.mint : M.berry;
    put(pill(4.8, 7.4, 17.4, 3, 3), M.cream, 'fort_cushion_back', g, -7, 3.7, 0);
    for (const e of [-1, 1]) { put(pill(11, 7, 4.8, 3, 3), pm, 'fort_cushion_side', g, -1.6, 3.5, e * 7.2); put(SPH(0.45, 10, 8), M.white, 'pillow_button', g, -1.6, 3.5, e * 9.65); }
    for (const e of [-1, 1]) { const sl = group('fort_blanket', g, [s(-1.6), s(10.2), s(e * 3.6)], [e * 0.72, 0, 0]); put(rb(14.4, 0.7, 9.6, 4), tmx, 'fort_blanket_panel', sl); for (const k of [-2.6, 2.6]) put(rb(14.5, 0.76, 1, 4), M.white, 'fort_blanket_stripe', sl, 0, 0, k); }
    put(new THREE.CapsuleGeometry(s(0.7), s(14.4), 4, 12), M.cream, 'fort_ridge_roll', g, -1.6, 13.4, 0, 0, 0, Math.PI / 2);
    put(C(0.22, 0.22, 7, 8), M.white, 'fort_flag_pole', g, 5.4, 15.4, 0); const fl = new THREE.Shape(); fl.moveTo(0, 0); fl.lineTo(4.2, -1.3); fl.lineTo(0, -2.6); fl.lineTo(0, 0);
    const fg = new THREE.ExtrudeGeometry(fl, { depth: 0.15, bevelEnabled: false }); fg.scale(STUD, STUD, STUD); mesh(fg, tmx, 'fort_pennant', g, [s(5.4), s(18.8), 0]);
    flat(0, 4.6, M.lilac, 'fort_rug_paint', g, -1, 0, 0.08, 40);
    COVERS.push({ x, z: 0, r: 10, h: 7.4, kind: 'Full cover + landmark · Pillow Fort (U-shape, opens toward center)' });
  };
  const beanbag = (name, x, z, m) => { const g = grp(name, play, x, DECK, z); mesh(warpSphere((d) => { const p = superF(s(3.4), s(1.9), s(3.4), 2, 2.2)(d); p.y = Math.max(p.y, -s(1.6)); return p; }, 40, 24), m, 'beanbag', g, [0, s(1.6), 0]); put(TOR(1.3, 0.28, 8, 28), M.white, 'beanbag_seam', g, 0, 3.4, 0, Math.PI / 2); COVERS.push({ x, z, r: 4.6, h: 3.5, kind: 'Half cover · Beanbag Ø6.8×3.5 (lower body only)' }); };
  const star = starGeo(1.3, 0.6, 0.2), heart = heartGeo(1.2, 0.2);
  const plushBlock = (name, x, z, m, ry, emb) => { const g = grp(name, play, x, DECK, z, ry); put(rb(4.4, 4.4, 4.4, 4), m, 'plush_block', g, 0, 2.2, 0); mesh(emb ? heart : star, M.white, 'plush_block_patch', g, [0, s(2.2), s(2.25)]); mesh(emb ? star : heart, M.butter, 'plush_block_patch', g, [s(2.25), s(2.2), 0], [0, Math.PI / 2, 0]); COVERS.push({ x, z, r: 4.4, h: 4.4, kind: 'Half cover · Plush Block 4.4³' }); };
  for (const sx of [-1, 1]) {
    const T = sx < 0 ? 'A' : 'B';
    fort('pillow_fort_' + T, sx * 60, sx);
    pillowWall('pillow_wall_' + T + '_fwd_S', sx * 26, -24, sx * 0.46, sx); pillowWall('pillow_wall_' + T + '_fwd_N', sx * 26, 24, -sx * 0.46, sx);
    pillowWall('pillow_wall_' + T + '_flank_S', sx * 46, -44, 0, sx); pillowWall('pillow_wall_' + T + '_flank_N', sx * 46, 44, 0, sx);
    pillowWall('pillow_wall_' + T + '_back_S', sx * 70, -30, Math.PI / 2, sx); pillowWall('pillow_wall_' + T + '_back_N', sx * 70, 30, Math.PI / 2, sx);
    beanbag('beanbag_' + T + '_C', sx * 14, 0, M.lilac); beanbag('beanbag_' + T + '_S', sx * 38, -12, M.butter); beanbag('beanbag_' + T + '_N', sx * 38, 12, M.sky);
    plushBlock('plush_block_' + T + '_S', sx * 52, -18, M.violet, 0.3, 0); plushBlock('plush_block_' + T + '_N', sx * 52, 18, M.sky, -0.3, 1); plushBlock('plush_block_' + T + '_far_S', sx * 20, -48, M.butter, 0.6, 1); plushBlock('plush_block_' + T + '_far_N', sx * 20, 48, M.violet, -0.6, 0);
  }
  put(bake(nubs), M.cream, 'pillow_corner', play);
  // giant sofa (north) with three giant squishies
  const sofa = grp('giant_sofa', deco, 0, 0, W / 2 + 40);
  put(rb(170, 13, 36, 4), P.peri, 'sofa_seat_base', sofa, 0, 6.5, 0); put(rb(170, 34, 12, 4), P.periD, 'sofa_back', sofa, 0, 17, 15); for (const e of [-1, 1]) put(rb(18, 24, 40, 4), P.peri, 'sofa_arm', sofa, e * 90, 12, 0);
  for (const k of [-1, 0, 1]) put(pill(54, 7, 31, 3, 3), M.cream, 'sofa_cushion', sofa, k * 55, 15.5, -1);
  for (const e of [-1, 1]) for (const k of [-1, 1]) put(C(2.4, 1.6, 4, 16), P.woodD, 'sofa_leg', sofa, e * 88, -1, k * 15);
  // toy shelf (south)
  const shelf = grp('giant_toy_shelf', deco, 0, 0, -(W / 2 + 34));
  put(rb(150, 2, 12, 6), P.wood, 'shelf_board', shelf, 0, 1, 0); for (const y of [14, 27, 40]) put(rb(150, 1.6, 12, 6), P.wood, 'shelf_board', shelf, 0, y, 0);
  for (const x of [-75, -25, 25, 75]) put(rb(2.4, 42, 12, 6), P.woodD, 'shelf_side', shelf, x, 21, 0); put(rb(150, 42, 1.2, 6), P.wood, 'shelf_back', shelf, 0, 21, -5.6);
  const bookC = [M.berry, M.sky, M.butter, M.violet, M.mint], books = bookC.map(() => []);
  for (const y of [2, 15.6, 28.6]) { let x = -72; let i = 0; while (x < 72) { const w = 2.2 + r() * 1.6, h = 7 + r() * 4; if (Math.abs(x) % 50 < 46) books[(i++) % 5].push(at(rb(w, h, 8, 8), x + w / 2, y + h / 2, 0, 0, 0, r() < 0.12 ? 0.18 : 0)); x += w + 0.25; } }
  bookC.forEach((m, i) => put(bake(books[i]), m, 'shelf_books', shelf));
  // string lights + hanging stars
  const wire = [], bulbs = [];
  for (const z of [-34, 0, 34]) { const x0 = -L / 2 - 26, x1 = L / 2 + 26; let prev = null; for (let i = 0; i <= 60; i++) { const t = i / 60, x = x0 + (x1 - x0) * t, y = 44 - 12 * Math.sin(Math.PI * t), p = [x, y, z]; if (prev) { const L2 = Math.hypot(x - prev[0], y - prev[1]); wire.push(at(B(L2, 0.15, 0.15), (x + prev[0]) / 2, (y + prev[1]) / 2, z, 0, 0, Math.atan2(y - prev[1], x - prev[0]))); } if (i % 3 === 0) bulbs.push(at(SPH(0.55, 10, 8), x, y - 0.6, z)); prev = p; } }
  put(bake(wire), M.dark, 'string_light_wire_line', deco); put(bake(bulbs), M.glow, 'string_light_bulb', deco);
  const starBig = starGeo(3.2, 1.4, 0.8);
  for (const [x, z, y] of [[-50, -34, 30], [0, 0, 26], [50, 34, 30], [-20, 34, 33], [30, -34, 33]]) { mesh(starBig, M.butter, 'hanging_star', deco, [s(x), s(y), s(z)], [0, r() * 3, 0]); put(B(0.12, 37 - y, 0.12), M.dark, 'hanging_star_string_line', deco, x, (y + 43) / 2, z); }
  const scal = []; for (let x = -L / 2 - 4; x <= L / 2 + 4; x += 5) for (const sz of [-1, 1]) scal.push(at(C(2, 2, 0.2, 20), x, 0.1, sz * (W / 2 + 6.5))); for (let z = -W / 2 - 4; z <= W / 2 + 4; z += 5) for (const sx of [-1, 1]) scal.push(at(C(2, 2, 0.2, 20), sx * (L / 2 + 6.5), 0.1, z));
  put(bake(scal), M.cream, 'rug_scallop_paint', deco);
  toonify(art, { width: 1.8 });
  [['CloudBunny', -55], ['MochiFox', 0], ['BobaBear', 55]].forEach(([id, x]) => toyAt(id, toys, x, 19, W / 2 + 39, 24, Math.PI));
  return finish(A, cfg, spawns, [['Pillow Fort (full cover, landmark)', -60, 18, 0], ['Pillow Wall · full cover 7 st', -26, 9, 24], ['Beanbag · half cover 3.5 st', -38, 6, 12], ['Plush Block · half cover 4.4 st', -52, 7, 18], ['Team A spawn ×5 (mint · ●)', -80, 2, -46], ['Team B spawn ×5 (strawberry · ◆)', 80, 2, -46], ['Center line: visual marking + assumed movement boundary', 0, 10, 30]], [[-80, 8, -70 + 3.4, 8]]);
}

/* ======================= BUBBLE REEF COURT ======================= */
export function buildReef() {
  COVERS.length = 0;
  const cfg = ARENAS2.reef, { L, W, DECK } = cfg, M = palette(), r = rng(41);
  const A = group('SD_ARENA_BubbleReefCourt'), art = group('ART', A), play = group('PLAYABLE', art), deco = group('OUT_OF_BOUNDS_DRESSING', art);
  const P = { sand: mat('reef_sand', 0xF3DFB4, 0.95), sandD: mat('reef_sand_ripple', 0xE8CF9C, 0.95), aqua: mat('court_aqua', 0xBDEDEE, 0.85), coral: mat('court_coral', 0xFFD6CC, 0.85), foam: mat('wave_white', 0xFFFFFF, 0.7), sponge: mat('sponge_yellow', 0xF9D35B, 0.9), pore: mat('sponge_pore', 0xD9A534, 0.9), shell: mat('clam_shell', 0xFFE3EC, 0.6), pearl: mat('pearl', 0xFFF6FA, 0.18), tongue: mat('clam_inner', 0xF8A8BD, 0.6), brain: mat('brain_coral', 0xF49AC1, 0.8), glassG: mat('sea_glass', 0x9FE3C9, 0.35), glassT: mat('sea_glass_top', 0xD2F5E8, 0.35), water: mat('aquarium_water', 0x6CC8EA, 0.3, { emissive: 0x2E8FB8, emissiveIntensity: 0.3 }), kelp: mat('kelp', 0x5DBB7A, 0.8), kelpD: mat('kelp_dark', 0x3E9C5F, 0.8), rock: mat('reef_rock', 0xB6A6C9, 0.9), rock2: mat('reef_rock_warm', 0xD8B9A6, 0.9), tubeO: mat('tube_coral_orange', 0xFFB070, 0.8), tubeL: mat('tube_coral_lilac', 0xC6A3F4, 0.8), bubble: mat('bubble', 0xEFFBFF, 0.2), tankGlass: mat('tank_glass', 0xCFF3FF, 0.1, { transparent: true, opacity: 0.18, depthWrite: false }) };
  put(B(400, 2, 360), P.sand, 'floor_base', art, 0, -1, 0);
  { const rp = []; for (let i = 0; i < 90; i++) { const x = (r() - 0.5) * 360, z = (r() - 0.5) * 320; if (Math.abs(x) < L / 2 + 6 && Math.abs(z) < W / 2 + 6) continue; rp.push(at(rb(10 + r() * 14, 0.12, 1.2, 4), x, 0.04, z, 0, r() * 0.4 - 0.2)); } put(bake(rp), P.sandD, 'sand_ripple_paint', deco); }
  const spawns = court(play, cfg, P.aqua, P.coral, P.foam, M, 84);
  { const wv = []; for (const sx of [-1, 1]) for (const x0 of [24, 46, 64]) { let prev = null; for (let z = -W / 2 + 6; z <= W / 2 - 6; z += 1.6) { const x = sx * (x0 + 2.2 * Math.sin(z * 0.16 + x0)); if (prev && Math.round(z / 1.6) % 2) { const dx = x - prev[0], dz = z - prev[1]; wv.push(at(B(0.6, 0.04, Math.hypot(dx, dz)), (x + prev[0]) / 2, DECK + 0.04, (z + prev[1]) / 2, 0, Math.atan2(dx, dz))); } prev = [x, z]; } } put(bake(wv), P.foam, 'wave_paint_line', play); }
  { const pc = [[], [], []]; let i = 0; const peb = (x, z) => pc[(i++) % 3].push(at(pill(3 + r(), 1.6 + r() * 0.6, 2.6 + r() * 0.6, 2, 2), x, DECK + 0.7, z, 0, r() * 3)); for (let x = -L / 2; x <= L / 2; x += 3.4) { peb(x, -W / 2 - 2); peb(x, W / 2 + 2); } for (let z = -W / 2; z <= W / 2; z += 3.4) { peb(-L / 2 - 2, z); peb(L / 2 + 2, z); } [M.stone, P.rock, P.rock2].forEach((m, k) => put(bake(pc[k]), m, 'pebble_border', play)); }
  const place = (fn, x, z, ry, ...rest) => { fn('A', x, z, ry, ...rest); fn('B', -x, -z, ry + Math.PI, ...rest); };
  const sponge = (T, x, z, ry, k) => {
    const g = grp('sponge_wall_' + T + '_' + k, play, x, DECK, z, ry);
    put(rb(12, 7, 4.2, 4), P.sponge, 'sponge_wall', g, 0, 3.5, 0); for (const [bx, w] of [[-3.6, 3.4], [1, 4.2], [4.6, 2.4]]) put(pill(w, 1.6, 3.6, 2, 2), P.sponge, 'sponge_top_lump', g, bx, 7, 0);
    const pores = []; for (let i = 0; i < 26; i++) { const f = i % 2 ? 1 : -1; pores.push(at(SPH(0.35 + r() * 0.35, 10, 6), (r() - 0.5) * 10.4, 0.9 + r() * 5.4, f * 2.12, 0, 0, 0, [1, 1, 0.4])); }
    put(bake(pores), P.pore, 'sponge_pore', g); COVERS.push({ x, z, r: 8, h: 7, kind: 'Full cover · Sponge Wall 12×7×4.2', ry, w: 12, d: 4.2 });
  };
  const shellGeo = warpSphere((d) => { const p = superF(s(7), s(2.6), s(6.2), 2, 2)(d); const a = Math.atan2(d.z, d.x); p.x *= 1 + 0.05 * Math.cos(16 * a); p.z *= 1 + 0.05 * Math.cos(16 * a); p.y = Math.min(p.y, 0); return p; }, 64, 24);
  const clam = (T, x, z, ry) => {
    const g = grp('giant_clam_' + T, play, x, DECK, z, ry);
    put(rb(15, 2.4, 13, 3), P.rock, 'clam_rock_base', g, 0, 1.2, 0); mesh(shellGeo, P.shell, 'clam_shell_bottom', g, [0, s(4.6), 0]);
    put(pill(10, 1.6, 9, 2, 2), P.tongue, 'clam_inner', g, 0.6, 4.7, 0); put(SPH(2.3, 28, 20), P.pearl, 'clam_pearl', g, 1, 6.6, 0);
    const hinge = group('clam_top_hinge', g, [s(-6.6), s(4.7), 0], [0, 0, 0.95]); const top = mesh(shellGeo, P.shell, 'clam_shell_top', hinge, [s(6.6), 0, 0]); top.scale.y = -1;
    COVERS.push({ x, z, r: 9, h: 8.6, kind: 'Full cover + landmark · Giant Clam 15×8.6×13', ry, w: 15, d: 13 });
  };
  const brainGeo = warpSphere((d) => { const p = superF(s(3.8), s(3.4), s(3.8), 2, 2)(d); const a = Math.atan2(d.z, d.x), b = Math.asin(Math.max(-1, Math.min(1, d.y))); p.multiplyScalar(1 + 0.04 * Math.sin(10 * a + 7 * b) * Math.max(0, d.y + 0.2)); p.y = Math.max(p.y, 0); return p; }, 56, 32);
  const brain = (T, x, z, ry, k) => { const g = grp('brain_coral_' + T + '_' + k, play, x, DECK, z, ry); mesh(brainGeo, P.brain, 'brain_coral', g); put(TOR(3.8, 0.45, 8, 40), P.rock2, 'brain_coral_base', g, 0, 0.3, 0, Math.PI / 2); COVERS.push({ x, z, r: 5, h: 3.4, kind: 'Half cover · Brain Coral Ø7.6×3.4 (lower body only)' }); };
  const pillar = (T, x, z, ry, k) => { const g = grp('sea_glass_pillar_' + T + '_' + k, play, x, DECK, z, ry); put(C(2.6, 3, 9, 6), P.glassG, 'sea_glass_pillar', g, 0, 4.5, 0); put(C(2.75, 2.6, 0.7, 6), P.glassT, 'sea_glass_cap', g, 0, 9.3, 0); for (let i = 0; i < 5; i++) { const a = r() * TAU; put(SPH(0.5, 10, 8), M.white, 'barnacle', g, Math.cos(a) * 2.75, 1 + r() * 6, Math.sin(a) * 2.75); } COVERS.push({ x, z, r: 4.5, h: 9.6, kind: 'Full cover · Sea-glass Pillar Ø6×9.6 (narrow)' }); };
  place(clam, -54, -10, 0);
  place(sponge, -28, -26, 0.5, 1); place(sponge, -62, 32, -0.25, 2); place(sponge, -24, 40, -0.65, 3);
  place(brain, -14, 6, 0, 1); place(brain, -40, -48, 0, 2); place(brain, -76, -12, 0, 3);
  place(pillar, -38, 14, 0, 1); place(pillar, -68, -38, 0, 2);
  // aquarium tanks (long sides) + reef end walls
  const kelp = [[], []], tubes = [[], []], rocks = [[], []], bub = [];
  for (const sz of [-1, 1]) {
    const zg = sz * (W / 2 + 12), zw = sz * (W / 2 + 33);
    put(B(L + 90, 36, 16), P.water, 'aquarium_water_backdrop', deco, 0, 18, zw); put(B(L + 90, 36, 0.5), P.tankGlass, 'aquarium_glass', deco, 0, 18, zg).userData.noShadow = true;
    for (const y of [0.9, 35.6]) put(rb(L + 92, 1.8, 3, 6), M.white, 'aquarium_rail', deco, 0, y, zg);
    for (let x = -(L + 90) / 2; x <= (L + 90) / 2 + 1; x += 34.5) put(B(2.4, 36, 3.2), M.white, 'aquarium_post', deco, x, 18, zg);
    for (let i = 0; i < 26; i++) { const x = -(L + 80) / 2 + i * ((L + 80) / 25) + (r() - 0.5) * 4, z = zg + sz * (5 + r() * 12), h = 10 + r() * 20; for (let k = 0; k < h / 2.4; k++) kelp[i % 2].push(at(rb(1.4, 2.6, 0.5, 4), x + Math.sin(k * 0.6 + i) * 0.8, 1.3 + k * 2.4, z, 0, i, Math.sin(k * 0.6 + i) * 0.25)); }
    for (let i = 0; i < 14; i++) { const x = (r() - 0.5) * (L + 70), z = zg + sz * (4 + r() * 13); for (let k = 0; k < 4; k++) tubes[i % 2].push(at(C(0.8, 1, 3 + r() * 5, 10), x + (r() - 0.5) * 3, 2.5, z + (r() - 0.5) * 3, (r() - 0.5) * 0.3, 0, (r() - 0.5) * 0.3)); rocks[i % 2].push(at(rb(5 + r() * 4, 3 + r() * 2, 4 + r() * 3, 3), x + 3, 1.4, z, 0, r() * 3)); }
    for (let i = 0; i < 40; i++) bub.push(at(SPH(0.25 + r() * 0.5, 10, 8), (r() - 0.5) * (L + 70), 3 + r() * 30, zg + sz * (2 + r() * 14)));
  }
  const fishC = [M.butter, mat('fish_orange', 0xFF9A4D, 0.6), M.sky, mat('fish_pink', 0xF68FB4, 0.6)], fishB = fishC.map(() => []), fishT = fishC.map(() => []), eyes = [];
  for (let i = 0; i < 18; i++) { const sz = i % 2 ? 1 : -1, x = (r() - 0.5) * (L + 50), y = 7 + r() * 22, z = sz * (W / 2 + 18 + r() * 9), f = r() < 0.5 ? 1 : -1, k = 1 + r() * 0.8, c = i % 4; fishB[c].push(at(pill(4 * k, 2.6 * k, 1.6 * k, 2, 2), x, y, z)); fishT[c].push(at(new THREE.ConeGeometry(s(1.3 * k), s(2 * k), 4), x - f * 2.6 * k, y, z, 0, 0, f * Math.PI / 2)); eyes.push(at(SPH(0.3 * k, 8, 6), x + f * 1.1 * k, y + 0.35 * k, z - sz * 0.75 * k)); }
  fishC.forEach((m, i) => { put(bake(fishB[i]), m, 'fish_body', deco); put(bake(fishT[i]), m, 'fish_tail', deco); }); put(bake(eyes), M.dark, 'fish_eye', deco);
  put(bake(kelp[0]), P.kelp, 'kelp', deco); put(bake(kelp[1]), P.kelpD, 'kelp', deco); put(bake(tubes[0]), P.tubeO, 'tube_coral', deco); put(bake(tubes[1]), P.tubeL, 'tube_coral', deco); put(bake(rocks[0]), P.rock, 'reef_rock', deco); put(bake(rocks[1]), P.rock2, 'reef_rock', deco); put(bake(bub), P.bubble, 'bubble', deco);
  for (const sx of [-1, 1]) {
    const g = grp('reef_end_' + (sx < 0 ? 'A' : 'B'), deco, sx * (L / 2 + 24), 0, 0), bl = [];
    for (let i = 0; i < 16; i++) bl.push(at(rb(10 + r() * 10, 6 + r() * 10, 10 + r() * 8, 3), (r() - 0.5) * 12, 3 + r() * 6, -W / 2 + (i / 15) * W, 0, r() * 3));
    put(bake(bl), P.rock, 'reef_wall_boulders', g);
    const port = grp('porthole_scoreboard', g, 0, 24, 0, -sx * Math.PI / 2);
    put(C(9, 9, 2, 48), M.plum, 'porthole_back', port, 0, 0, 0, Math.PI / 2); put(TOR(9, 1.2, 10, 48), M.gold, 'porthole_rim', port, 0, 0, 1);
    for (let k = 0; k < 8; k++) { const a = (k / 8) * TAU; put(SPH(0.7, 10, 8), M.gold, 'porthole_bolt', port, Math.cos(a) * 9, Math.sin(a) * 9, 2.1); }
    for (const e of [-1, 1]) put(B(5.4, 4, 0.2), e < 0 ? mat('screen_mint', 0x5FD3AE, 0.4, { emissive: 0x2E9C7C, emissiveIntensity: 0.9 }) : mat('screen_strawberry', 0xF2687F, 0.4, { emissive: 0xB83A52, emissiveIntensity: 0.9 }), 'porthole_team_panel', port, e * 3.2, 0, 1.15);
  }
  toonify(art, { width: 1.8 });
  return finish(A, cfg, spawns, [['Giant Clam (full cover, landmark)', -54, 16, -10], ['Sponge Wall · full cover 7 st', -28, 9.5, -26], ['Brain Coral · half cover 3.4 st', -14, 6, 6], ['Sea-glass Pillar · full cover 9.6 st', -38, 12, 14], ['Rotational symmetry: Team B = Team A turned 180°', 0, 12, -34], ['Team A spawn ×5 (mint · ●)', -84, 2, -46], ['Team B spawn ×5 (strawberry · ◆)', 84, 2, 46], ['Aquarium: decoration only, no swimming', 0, 20, W / 2 + 14]], [[-84, 4, -76 + 4.5, 4]]);
}

/* ======================= ARCADE TOYWORKS ======================= */
export function buildArcade() {
  COVERS.length = 0;
  const cfg = ARENAS2.arcade, { L, W, DECK } = cfg, M = palette(), r = rng(51);
  const A = group('SD_ARENA_ArcadeToyworks'), art = group('ART', A), play = group('PLAYABLE', art), deco = group('OUT_OF_BOUNDS_DRESSING', art), toys = group('TOY_DISPLAYS', A);
  const P = { carpet: mat('arcade_carpet', 0x45407A, 0.95), a1: mat('tile_mint_a', 0xA8E6D2, 0.7), a2: mat('tile_mint_b', 0xDDF6EE, 0.7), b1: mat('tile_berry_a', 0xF9B9C6, 0.7), b2: mat('tile_berry_b', 0xFDE3E9, 0.7), bS: mat('brick_sky', 0x7FC8F8, 0.5), bY: mat('brick_butter', 0xFFD25E, 0.5), bL: mat('brick_lilac', 0xB892F0, 0.5), bG: mat('brick_green', 0x8BE3A1, 0.5), screen: mat('cabinet_screen', 0x2A2342, 0.4, { emissive: 0x3A2E6E, emissiveIntensity: 0.9 }), marq: mat('marquee_glow', 0xFFF1C2, 0.5, { emissive: 0xFFD98A, emissiveIntensity: 1.3 }), bulb: mat('bulb_glow', 0xFFF6DC, 0.5, { emissive: 0xFFE7A0, emissiveIntensity: 1.6 }), belt: mat('conveyor_belt', 0x4A4560, 0.7), roller: mat('conveyor_roller', 0xC9C2BA, 0.45, { metalness: 0.3 }), wood: mat('toy_wood', 0xD6A06A, 0.8) };
  put(B(400, 2, 340), P.carpet, 'floor_base', art, 0, -1, 0);
  { const cf = [[], [], [], []]; for (let i = 0; i < 360; i++) { const x = (r() - 0.5) * 360, z = (r() - 0.5) * 300; if (Math.abs(x) < L / 2 + 5 && Math.abs(z) < W / 2 + 5) continue; cf[i % 4].push(at(B(1.4, 0.05, 1.4), x, 0.03, z, 0, r() * 3)); } [M.butter, M.mint, M.berry, M.sky].forEach((m, i) => put(bake(cf[i]), m, 'carpet_confetti_paint', deco)); }
  const spawns = court(play, cfg, P.a1, P.b1, M.white, M, 76);
  { const ca = [], cb = []; for (let x = -L / 2; x < L / 2; x += 8) for (let z = -W / 2; z < W / 2; z += 8) { const ix = Math.round((x + L / 2) / 8), iz = Math.round((z + W / 2) / 8); if ((ix + iz) % 2) { const d = Math.min(8, W / 2 - z); (x < 0 ? ca : cb).push(at(B(8, 0.04, d), x + 4, DECK + 0.01, z + d / 2)); } } put(bake(ca), P.a2, 'court_checker_paint', play); put(bake(cb), P.b2, 'court_checker_paint', play); }
  for (const sz of [-1, 1]) for (const sx of [-1, 1]) { put(rb(L / 2 - 1, 2.4, 2.6, 5), M.white, 'bumper_rail', play, sx * L / 4, DECK + 1.2, sz * (W / 2 + 1.6)); put(rb(L / 2 - 1.4, 0.7, 2.7, 6), sx < 0 ? M.mint : M.berry, 'bumper_stripe', play, sx * L / 4, DECK + 1.5, sz * (W / 2 + 1.6)); }
  for (const sx of [-1, 1]) { put(rb(2.6, 2.4, W + 5.8, 5), M.white, 'bumper_rail_end', play, sx * (L / 2 + 1.6), DECK + 1.2, 0); put(rb(2.7, 0.7, W + 5.4, 6), sx < 0 ? M.mint : M.berry, 'bumper_stripe', play, sx * (L / 2 + 1.6), DECK + 1.5, 0); }
  const studG = C(0.75, 0.75, 0.6, 16), brickG = rb(3.9, 2.25, 4, 8);
  const brickWall = (name, x, z, ry) => {
    const g = grp(name, play, x, DECK, z, ry), cols = [P.bS, P.bY, P.bL], studs = [];
    for (let c = 0; c < 3; c++) { const off = c === 1 ? 2 : 0, n = c === 1 ? 2 : 3; for (let i = 0; i < n; i++) { const bx = -4 + i * 4 + off; put(brickG, cols[c], 'toy_brick', g, bx, 1.15 + c * 2.3, 0); if (c === 2 || (c === 1 && false)) for (const [sx2, sz2] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) studs.push(at(studG, bx + sx2, 7.2, sz2)); } }
    for (const e of [-1, 1]) { put(brickG, P.bG, 'toy_brick', g, e * 6, 3.45, 0); }
    put(bake(studs), P.bL, 'toy_brick_stud', g); COVERS.push({ x, z, r: 8, h: 7.5, kind: 'Full cover · Brick Wall 12×7.5×4', ry, w: 12, d: 4 });
  };
  const screenM = canvasMat((c, W2, H2) => { c.fillStyle = '#2A2342'; c.fillRect(0, 0, W2, H2); const px = 16; const art2 = ['..XXXX..', '.XXXXXX.', 'XX.XX.XX', 'XXXXXXXX', 'XX....XX', '.XXXXXX.']; art2.forEach((row, y) => [...row].forEach((ch, x) => { if (ch === 'X') { c.fillStyle = '#FFD25E'; c.fillRect(64 + x * px, 30 + y * px, px - 2, px - 2); } })); c.fillStyle = '#5FD3AE'; c.font = '700 34px Fredoka, system-ui'; c.textAlign = 'center'; c.fillText('PLAY', W2 / 2, H2 - 20); }, 256, 192, 'cabinet_screen_tex');
  const cabinets = (name, x, z, ry, col) => {
    const g = grp(name, play, x, DECK, z, ry);
    for (const e of [-1, 1]) {
      const c = group('arcade_cabinet', g, [0, 0, s(e * 2.15)], [0, e < 0 ? Math.PI : 0, 0]);
      put(rb(5, 8.6, 4.2, 6), col, 'cabinet_body', c, 0, 4.3, 0); put(rb(5.3, 1.7, 1.6, 6), P.marq, 'cabinet_marquee', c, 0, 8.6, 1.3);
      const sc = put(new THREE.PlaneGeometry(s(3.8), s(2.9)), screenM, 'sign_plate', c, 0, 6.4, 2.16, -0.2, 0, 0); sc.userData.noOutline = true;
      put(rb(5.3, 0.9, 2.2, 6), M.plum, 'cabinet_controls', c, 0, 4.6, 2.6); put(C(0.16, 0.16, 1.1, 8), M.dark, 'joystick_shaft', c, -1.3, 5.5, 2.6); put(SPH(0.5, 12, 8), M.red, 'joystick_ball', c, -1.3, 6.1, 2.6);
      [M.butter, M.mint, M.sky].forEach((m, i) => put(C(0.35, 0.35, 0.3, 14), m, 'cabinet_button', c, 0.2 + i * 0.85, 5.1, 2.7));
    }
    COVERS.push({ x, z, r: 6.5, h: 9.4, kind: 'Full cover · Arcade Cabinet pair 5×9.4×8.6', ry, w: 5, d: 8.6 });
  };
  const blockG = rb(4.4, 4.4, 4.4, 5), star = starGeo(1.3, 0.6, 0.25), heart = heartGeo(1.2, 0.25);
  const toyBlock = (name, x, z, ry, col, k) => { const g = grp(name, play, x, DECK, z, ry); put(blockG, col, 'toy_block', g, 0, 2.2, 0); mesh(k ? heart : star, M.white, 'toy_block_emblem', g, [0, s(2.2), s(2.3)]); mesh(k ? star : heart, M.white, 'toy_block_emblem', g, [s(2.3), s(2.2), 0], [0, Math.PI / 2, 0]); const st = []; for (const [a, b] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) st.push(at(studG, a * 1.1, 4.7, b * 1.1)); put(bake(st), col, 'toy_block_stud', g); COVERS.push({ x, z, r: 4.4, h: 5, kind: 'Half cover · Toy Block 4.4³ (+studs)' }); };
  const prizeSpots = [];
  const claw = (name, x, team) => {
    const g = grp(name, play, x, DECK, 0, team < 0 ? Math.PI / 2 : -Math.PI / 2), tmx = team < 0 ? M.mint : M.berry;
    put(rb(10, 6, 10, 5), tmx, 'claw_base', g, 0, 3, 0); put(rb(3.4, 2.6, 0.6, 6), M.plum, 'claw_prize_chute', g, -2.6, 2.4, 5.05);
    const gl = put(B(9.2, 9, 9.2), M.glass, 'claw_glass', g, 0, 10.5, 0); gl.userData.noShadow = true;
    for (const [a, b] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) put(C(0.45, 0.45, 9, 12), M.white, 'claw_post', g, a * 4.6, 10.5, b * 4.6);
    put(rb(10.8, 3.4, 10.8, 5), M.plum, 'claw_top', g, 0, 16.7, 0); put(rb(11, 1.2, 11, 6), P.marq, 'claw_marquee_band', g, 0, 16.7, 0);
    const bl = []; for (let i = 0; i < 24; i++) { const t = i / 24, side = (t * 4) | 0, u = (t * 4) % 1 - 0.5, px = [u * 10.6, 5.5, -u * 10.6, -5.5][side], pz = [5.5, u * 10.6, -5.5, -u * 10.6][side]; bl.push(at(SPH(0.42, 10, 8), px, 18.6, pz)); } put(bake(bl), P.bulb, 'claw_bulbs', g);
    put(C(0.18, 0.18, 3.4, 8), M.white, 'claw_cable', g, 1, 13.3, 0.5); put(SPH(0.7, 14, 10), M.gold, 'claw_hub', g, 1, 11.4, 0.5);
    for (let k = 0; k < 3; k++) { const a = (k / 3) * TAU; put(rb(0.3, 2.2, 0.3, 6), M.gold, 'claw_prong', g, 1 + Math.cos(a) * 0.7, 10.4, 0.5 + Math.sin(a) * 0.7, Math.sin(a) * 0.5, 0, -Math.cos(a) * 0.5); }
    for (const f of [1, -1]) plate('TOYWORKS', 9, 1.6, g, 0, 16.7, f * 5.56, f < 0 ? Math.PI : 0, { bg: null, fg: '#2B2233' });
    prizeSpots.push(g); COVERS.push({ x, z: 0, r: 8.5, h: 18.4, kind: 'Full cover + landmark · Claw Machine 10×18.4×10', w: 10, d: 10 });
  };
  for (const sx of [-1, 1]) {
    const T = sx < 0 ? 'A' : 'B';
    claw('claw_machine_' + T, sx * 62, sx);
    brickWall('brick_wall_' + T + '_fwd_S', sx * 24, -28, sx * 0.3); brickWall('brick_wall_' + T + '_fwd_N', sx * 24, 28, -sx * 0.3);
    brickWall('brick_wall_' + T + '_flank_S', sx * 48, -46, 0); brickWall('brick_wall_' + T + '_flank_N', sx * 48, 46, 0);
    cabinets('arcade_cabinets_' + T + '_S', sx * 40, -14, 0, sx < 0 ? M.sky : M.violet); cabinets('arcade_cabinets_' + T + '_N', sx * 40, 14, 0, sx < 0 ? M.violet : M.sky);
    toyBlock('toy_block_' + T + '_C', sx * 14, 0, 0.4, M.butter, 0); toyBlock('toy_block_' + T + '_S', sx * 66, -32, 0.2, M.sky, 1); toyBlock('toy_block_' + T + '_N', sx * 66, 32, -0.2, M.violet, 0); toyBlock('toy_block_' + T + '_mid', sx * 30, 0, 0.8, M.berryL, 1);
  }
  // conveyor (north), prize counter (south), gumball machines, end marquees
  const cv = grp('toy_conveyor', deco, 0, 0, W / 2 + 18), roll = [], legs = [], boxes = [[], [], []];
  put(rb(L + 30, 1.2, 8, 6), P.belt, 'conveyor_belt', cv, 0, 6, 0); for (const e of [-1, 1]) put(rb(L + 32, 1.8, 1, 6), M.white, 'conveyor_frame', cv, 0, 6, e * 4.4);
  for (let x = -(L + 28) / 2; x <= (L + 28) / 2; x += 4) roll.push(at(C(0.7, 0.7, 9.4, 12), x, 5.1, 0, Math.PI / 2)); for (let x = -(L + 20) / 2; x <= (L + 20) / 2; x += 24) for (const e of [-1, 1]) legs.push(at(rb(1.4, 5, 1.4, 5), x, 2.5, e * 3.6));
  for (let x = -(L + 10) / 2, i = 0; x <= (L + 10) / 2; x += 13, i++) boxes[i % 3].push(at(rb(5 + (i % 2), 4 + (i % 3), 5, 5), x, 8.6 + (i % 3) * 0.5, 0, 0, (i % 4) * 0.25));
  put(bake(roll), P.roller, 'conveyor_roller', cv); put(bake(legs), M.plum, 'conveyor_leg', cv); [M.berry, M.sky, M.butter].forEach((m, i) => put(bake(boxes[i]), m, 'conveyor_toy_box', cv));
  const pcn = grp('prize_counter', deco, 0, 0, -(W / 2 + 20));
  put(rb(90, 6, 7, 4), M.lilac, 'prize_counter_body', pcn, 0, 3, 0); put(rb(92, 0.8, 8, 6), M.white, 'prize_counter_top', pcn, 0, 6.4, 0); const pg = put(B(88, 4, 6), M.glass, 'prize_counter_glass', pcn, 0, 8.8, 0); pg.userData.noShadow = true;
  put(rb(100, 24, 3, 4), P.wood, 'prize_wall', pcn, 0, 12, -8); for (const y of [8, 15, 22]) put(rb(98, 1, 4, 6), M.white, 'prize_shelf', pcn, 0, y, -6.2);
  const pl = [[], [], [], []]; for (const y of [8.5, 15.5]) for (let x = -46; x <= 46; x += 4.2) pl[((x + 46) / 4.2 + y) % 4 | 0].push(at(pill(2.8, 3, 2.6, 2, 2.4), x, y + 1.6, -6.2)); [M.berry, M.mint, M.butter, M.violet].forEach((m, i) => put(bake(pl[i]), m, 'prize_plush_blob', pcn));
  plate('PRIZES', 14, 3.6, pcn, 0, 26.2, -6.4, 0, { bg: '#FFD25E' });
  for (const [x, z] of [[-L / 2 - 16, -W / 2 - 10], [L / 2 + 16, -W / 2 - 10], [-L / 2 - 16, W / 2 + 4], [L / 2 + 16, W / 2 + 4]]) {
    const g = grp('gumball_machine', deco, x, 0, z);
    put(C(2.2, 3.2, 7, 24), M.red, 'gumball_stand', g, 0, 3.5, 0); put(rb(5, 3, 5, 5), M.red, 'gumball_coin_box', g, 0, 8.4, 0); put(B(1, 0.6, 0.2), M.gold, 'gumball_coin_slot', g, 0, 8.8, 2.55);
    const gb = []; for (let i = 0; i < 30; i++) { const a = r() * TAU, rr = r() * 3, y = 11.2 + r() * 3.6; gb.push(at(SPH(0.75, 10, 8), Math.cos(a) * rr, y, Math.sin(a) * rr)); } [M.mint, M.butter, M.sky].forEach((m, i) => put(bake(gb.filter((_, k) => k % 3 === i)), m, 'gumballs', g));
    const gl2 = put(SPH(4.4, 28, 20), M.glass, 'gumball_globe', g, 0, 13.6, 0); gl2.userData.noShadow = true; put(C(1.8, 2.4, 1.2, 20), M.red, 'gumball_cap', g, 0, 18.2, 0);
  }
  for (const sx of [-1, 1]) {
    const g = grp('toyworks_marquee_' + (sx < 0 ? 'A' : 'B'), deco, sx * (L / 2 + 22), 0, 0, -sx * Math.PI / 2);
    for (const e of [-1, 1]) put(rb(4, 26, 4, 5), M.plum, 'marquee_post', g, e * 22, 13, 0);
    put(rb(50, 9, 3.4, 5), M.plum, 'marquee_board', g, 0, 26, 0); plate('TOYWORKS', 34, 5.6, g, 0, 26.4, 1.75, 0, { bg: null, fg: '#FFD25E' });
    const bl = []; for (let i = 0; i <= 24; i++) for (const y of [21.8, 30.2]) bl.push(at(SPH(0.5, 10, 8), -24 + i * 2, y, 1.6)); put(bake(bl), P.bulb, 'marquee_bulbs', g);
    for (const e of [-1, 1]) put(B(7, 4, 0.3), e < 0 ? mat('screen_mint', 0x5FD3AE, 0.4, { emissive: 0x2E9C7C, emissiveIntensity: 0.9 }) : mat('screen_strawberry', 0xF2687F, 0.4, { emissive: 0xB83A52, emissiveIntensity: 0.9 }), 'marquee_team_panel', g, e * 18, 17, 2.1);
  }
  toonify(art, { width: 1.8 }); A.updateMatrixWorld(true);
  const prizes = ['Donut', 'Birdie', 'StrawberryFrog', 'PancakePup', 'CupcakeAxolotl', 'Banana'];
  prizeSpots.forEach((g, gi) => { const w = new THREE.Vector3(); prizes.forEach((id, i) => { const lx = -2.6 + (i % 3) * 2.6, lz = -2.2 + ((i / 3) | 0) * 3, p = g.localToWorld(w.set(s(lx), s(6), s(lz))); const t = toyAt(id, toys, 0, 0, 0, 2.2, i + gi); t.position.copy(p); }); });
  return finish(A, cfg, spawns, [['Claw Machine (full cover, landmark)', -62, 21, 0], ['Brick Wall · full cover 7.5 st', -24, 10, 28], ['Arcade Cabinets · full cover 9.4 st', -40, 12, 14], ['Toy Block · half cover 5 st', -14, 7, 0], ['Team A spawn ×5 (mint · ●)', -76, 2, -46], ['Team B spawn ×5 (strawberry · ◆)', 76, 2, -46], ['Conveyor + prize counter: decorative only', 0, 14, W / 2 + 18]], [[-76, 6, -66 + 3, 6]]);
}
