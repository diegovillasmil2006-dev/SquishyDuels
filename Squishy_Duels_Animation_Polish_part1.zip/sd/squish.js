import { THREE, V3 } from './kit.js';

/* Soft-body kneading for the held / inspected squishy.
   Per-vertex memory: finger trails and lumps hold, then slow-rise. Live brushes (fingertip, two thumbs, palms) push dents
   with a raised rim, dragging smears material along, dragging off the edge stretches it like taffy, then it snaps back.
   Thumb crunch (matched to uploads/Video Project 2.mp4): both thumbs press the front face and slide together in a
   kneading rhythm; a ridge squeezes out between them, the top folds down, the ends swell and curl toward you.
   Wax coat (default): ~400 surface cells carry stress. Bending and pressing load them; when one gives it cracks: a crackle
   cluster plays, crack lines are revealed in the shader around it, flakes can pop off, and that patch wears (crunchy → soft).
   Per-vertex springs (jelly wobbles, foam settles), volume bulge, recomputed normals, crease/pore/crack shading.
   Sound layers at the bottom of this file: wax crackle (default) and the earlier slime engine. */

const MAXB = 4;
const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
const sm = (x) => { x = clamp(x, 0, 1); return x * x * (3 - 2 * x); };
const ease = (t) => 0.5 - 0.5 * Math.cos(Math.PI * clamp(t, 0, 1));
const R = Math.random, rr = (a, b) => a + (b - a) * R(), pick = (a) => a[(R() * a.length) | 0];
const gauss = () => { let u = 0; while (!u) u = R(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * R()); };
const _v = new THREE.Vector3(), _w = new THREE.Vector3(), _u = new THREE.Vector3();
const hash = (x, y, z) => { const s = Math.sin(x * 127.1 + y * 311.7 + z * 74.7) * 43758.5453; return s - Math.floor(s); };
function vnoise(x, y, z) {
  const ix = Math.floor(x), iy = Math.floor(y), iz = Math.floor(z);
  let fx = x - ix, fy = y - iy, fz = z - iz; fx *= fx * (3 - 2 * fx); fy *= fy * (3 - 2 * fy); fz *= fz * (3 - 2 * fz);
  const h = (a, b, c) => hash(ix + a, iy + b, iz + c), l = (a, b, t) => a + (b - a) * t;
  return l(l(l(h(0, 0, 0), h(1, 0, 0), fx), l(h(0, 1, 0), h(1, 1, 0), fx), fy), l(l(h(0, 0, 1), h(1, 0, 1), fx), l(h(0, 1, 1), h(1, 1, 1), fx), fy), fz);
}

export const FEELS = {
  foam: { label: 'Slow-rise foam', note: 'Lumps and finger trails hold, then creep back over ~2 s. Drag off the edge to stretch it.', rise: 1.9, fast: 0.12, k: 300, c: 20, beta: 0.7, gamma: 2, smear: 0.62, pull: 0.36, pullR: 0.17, neck: 0.6, plastic: 0.08, crease: 0.04, pore: 0.07, poreF: 105, gloss: 0, jig: [140, 10], wob: 0.55, lump: 0.32 },
  mochi: { label: 'Stretchy mochi', note: 'Stretches furthest and keeps a little of every pull.', rise: 2.7, fast: 0.05, k: 190, c: 11, beta: 1, gamma: 2.3, smear: 0.95, pull: 0.62, pullR: 0.2, neck: 0.85, plastic: 0.22, crease: 0.12, pore: 0, poreF: 1, gloss: 0.1, jig: [110, 8], wob: 0.85, lump: 0.18 },
  jelly: { label: 'Jelly bounce', note: 'Springs straight back and wobbles.', rise: 0.4, fast: 0.8, k: 520, c: 7, beta: 1.05, gamma: 2.7, smear: 0.45, pull: 0.3, pullR: 0.17, neck: 0.45, plastic: 0, crease: 0, pore: 0, poreF: 1, gloss: 0.14, jig: [300, 4.5], wob: 1.3, lump: 0.08 },
  plush: { label: 'Plush stuffing', note: 'Soft dents with folds, a gentle stretch, medium recovery.', rise: 1.1, fast: 0.32, k: 320, c: 22, beta: 0.7, gamma: 1.8, smear: 0.42, pull: 0.3, pullR: 0.19, neck: 0.5, plastic: 0.06, crease: 0.12, pore: 0.04, poreF: 190, gloss: 0, jig: [170, 10], wob: 0.6, lump: 0.28 },
};
export const TOY_FEEL = { KittyBread: 'foam', Toast: 'foam', Banana: 'foam', Butter: 'foam', Chocolate: 'foam', Donut: 'foam', BobaBear: 'foam', PancakePup: 'foam', MochiFox: 'mochi', StrawberryFrog: 'jelly', CupcakeAxolotl: 'jelly', Birdie: 'plush', CloudBunny: 'plush', Dragon: 'plush' };
export const feelOf = (id) => FEELS[TOY_FEEL[id] || 'foam'];

/* Wax coat per material. Visual: cell = crack cell size (× max dimension), th = stress a cell takes before it cracks,
   wear = coat lost per crack, gloss = wax shine. Audio (see the wax layer below): crackle ring modes + gains, ring time,
   foam body under each crackle, snap/grit amounts, low-pass, micro-crackle haze and body-bed centre frequencies. */
export const WAX = {
  foam: { label: 'Crunchy wax coat', note: 'Wax-dipped like your butter clip: every bend cracks it with a dry crackle. Keep kneading and it wears soft.', cell: 0.075, th: 1.45, wear: 0.05, gloss: 0.6,
    modes: [2700, 4300, 7000], mg: [1, 0.7, 0.55], spread: 0.14, tau: 0.0017, body: [300, 900], bodyG: 0.5, snap: 0.45, grit: 0.3, lp: 6500, fizzF: 4200, bodyF: 600, gain: 1 },
  mochi: { label: 'Glossy wax coat', note: 'A thin, shiny shell: finer cracks, crisper and a little higher than the butter.', cell: 0.06, th: 2.6, wear: 0.045, gloss: 0.9,
    modes: [3100, 5000, 8000], mg: [1, 0.75, 0.6], spread: 0.12, tau: 0.0015, body: [380, 1000], bodyG: 0.38, snap: 0.55, grit: 0.25, lp: 7500, fizzF: 5200, bodyF: 720, gain: 0.95 },
  jelly: { label: 'Candy-glass shell', note: 'A brittle candy shell over jelly: bigger shards, bright glassy ticks, then it wobbles.', cell: 0.095, th: 2.8, wear: 0.065, gloss: 1,
    modes: [3600, 5800, 9000], mg: [1, 0.8, 0.6], spread: 0.1, tau: 0.0026, body: [450, 1100], bodyG: 0.28, snap: 0.6, grit: 0.15, lp: 9000, fizzF: 6000, bodyF: 820, gain: 0.85 },
  plush: { label: 'Soft wax coat', note: 'Wax over fuzz: a muffled, lower crunch that wears soft quickly.', cell: 0.07, th: 2.4, wear: 0.06, gloss: 0.35,
    modes: [2100, 3500, 5600], mg: [1, 0.65, 0.45], spread: 0.16, tau: 0.0015, body: [240, 700], bodyG: 0.65, snap: 0.32, grit: 0.4, lp: 5200, fizzF: 3400, bodyF: 500, gain: 0.95 },
};

/* ---------- shading patch ---------- */
const VS_DECL = `attribute vec3 aRest;
attribute float aPress;
attribute float aCrack;
varying vec3 vSqRest;
varying float vSqPress;
varying float vSqCrack;`;
const FS_DECL = `uniform vec4 uSqC[${MAXB}];
uniform vec4 uSqU[${MAXB}];
uniform vec4 uSqK;
uniform vec4 uWax;
varying vec3 vSqRest;
varying float vSqPress;
varying float vSqCrack;
float sqH(vec3 p) { p = fract(p * 0.3183099 + 0.1); p *= 17.0; return fract(p.x * p.y * p.z * (p.x + p.y + p.z)); }
float sqN(vec3 x) {
  vec3 i = floor(x); vec3 f = fract(x); f = f * f * (3.0 - 2.0 * f);
  return mix(mix(mix(sqH(i), sqH(i + vec3(1.0, 0.0, 0.0)), f.x), mix(sqH(i + vec3(0.0, 1.0, 0.0)), sqH(i + vec3(1.0, 1.0, 0.0)), f.x), f.y),
             mix(mix(sqH(i + vec3(0.0, 0.0, 1.0)), sqH(i + vec3(1.0, 0.0, 1.0)), f.x), mix(sqH(i + vec3(0.0, 1.0, 1.0)), sqH(i + vec3(1.0, 1.0, 1.0)), f.x), f.y), f.z);
}
vec3 sqShade(vec3 col) {
  float sh = 1.0 - vSqPress * 0.16; float hi = 0.0;
  if (uSqK.z > 0.0) {
    float n = sqN(vSqRest * uSqK.y) * 0.62 + sqN(vSqRest * uSqK.y * 2.13 + 3.7) * 0.38;
    sh -= smoothstep(0.58, 0.76, n) * uSqK.z * (0.5 + 1.1 * vSqPress);
  }
  for (int i = 0; i < ${MAXB}; i++) {
    vec4 sc = uSqC[i]; vec4 su = uSqU[i];
    if (su.w <= 0.003) continue;
    vec3 v = vSqRest - sc.xyz; float h = dot(v, su.xyz); vec3 t = v - h * su.xyz;
    float rr = length(t) / sc.w; float hz = h / sc.w; float fall = exp(-hz * hz * 0.35);
    sh -= su.w * 0.07 * exp(-rr * rr) * fall;
    if (uSqK.x > 0.0 && rr > 0.3) {
      vec3 ax = normalize(cross(su.xyz, abs(su.y) < 0.9 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0)));
      vec3 bx = cross(su.xyz, ax);
      float ang = atan(dot(t, bx), dot(t, ax));
      float wv = sqN(vec3(cos(ang) * 1.6 + float(i) * 5.3, sin(ang) * 1.6, rr * 1.4)) * 2.4;
      float rays = pow(abs(sin(ang * 4.0 + wv)), 9.0);
      float ring = smoothstep(0.42, 0.9, rr) * (1.0 - smoothstep(1.2, 2.1, rr)) * fall;
      sh -= su.w * uSqK.x * 2.2 * rays * ring;
    }
    hi += su.w * uSqK.w * smoothstep(0.85, 1.25, rr) * (1.0 - smoothstep(1.25, 1.85, rr)) * fall;
  }
  return col * clamp(sh, 0.5, 1.0) + vec3(hi);
}
vec3 sqGloss(vec3 n, vec3 vp) {
  if (uWax.z <= 0.0 || uWax.w <= 0.0) return vec3(0.0);
  vec3 V = normalize(vp), L = normalize(vec3(-0.35, 0.75, 0.55)), Hh = normalize(L + V);
  float s = smoothstep(0.86, 0.9, pow(max(dot(n, Hh), 0.0), 9.0)), rim = pow(1.0 - max(dot(n, V), 0.0), 3.0);
  return vec3(1.0, 0.98, 0.93) * (s * 0.32 + rim * 0.07) * uWax.w;
}`;

/* ---------- soft body ---------- */
export class SoftSquish {
  constructor(toy, { audio = null, squisher = null, pan = 0.6 } = {}) {
    this.toy = toy; this.audio = audio; this.squisher = squisher; this.panK = pan;
    this.type = TOY_FEEL[toy.meta.id] || 'foam'; const F = (this.F = FEELS[this.type]); this.W = WAX[this.type]; this.pitch = toy.meta.squeeze.pitch;
    this.U = {
      uSqC: { value: Array.from({ length: MAXB }, () => new THREE.Vector4(0, 0, 0, 1)) },
      uSqU: { value: Array.from({ length: MAXB }, () => new THREE.Vector4()) },
      uSqK: { value: new THREE.Vector4(F.crease, F.poreF, F.pore, F.gloss) },
      uWax: { value: new THREE.Vector4(1, 0, 1, this.W.gloss) },
    };
    this.mats = new Map(); this.parts = []; this.byMesh = new Map();
    const sq = toy.squash, box = new THREE.Box3(), v = V3(), list = [], faceM = new Set();
    for (const g of [...(toy.faceN || []), ...(toy.faceS || [])]) g.traverse((o) => { if (o.isMesh) faceM.add(o); });
    toy.root.traverse((o) => { const p = o.geometry && o.geometry.attributes && o.geometry.attributes.position; if (o.isMesh && !o.isInstancedMesh && !o.userData.isOutline && p && !p.isInterleavedBufferAttribute && p.itemSize === 3) list.push(o); });
    let big = null;
    for (const o of list) {
      const M = new THREE.Matrix4(); let ok = false;
      for (let p = o; p; p = p.parent) { if (p === sq) { ok = true; break; } p.updateMatrix(); M.premultiply(p.matrix); }
      if (!ok) continue;
      const g0 = o.geometry, g = g0.clone();
      if (!g.attributes.normal) g.computeVertexNormals();
      const P = g.attributes.position, N = g.attributes.normal, n = P.count;
      const L = new THREE.Matrix3().setFromMatrix4(M), Li = L.clone().invert(), NM = Li.clone().transpose();
      const rest = Float32Array.from(P.array), restN = Float32Array.from(N.array), rs = new Float32Array(n * 3), rn = new Float32Array(n * 3);
      for (let i = 0; i < n; i++) { v.fromArray(rest, i * 3).applyMatrix4(M); v.toArray(rs, i * 3); box.expandByPoint(v); v.fromArray(restN, i * 3).applyMatrix3(NM).normalize(); v.toArray(rn, i * 3); }
      const A = new THREE.BufferAttribute(new Float32Array(n), 1), Cb = new THREE.BufferAttribute(new Float32Array(n), 1);
      g.setAttribute('aRest', new THREE.BufferAttribute(rs, 3)); g.setAttribute('aPress', A); g.setAttribute('aCrack', Cb);
      P.setUsage(THREE.DynamicDrawUsage); N.setUsage(THREE.DynamicDrawUsage); A.setUsage(THREE.DynamicDrawUsage); Cb.setUsage(THREE.DynamicDrawUsage);
      g.computeBoundingSphere(); if (g.boundingSphere) g.boundingSphere.radius *= 2; g.boundingBox = null;
      o.userData.softOrig = g0; o.geometry = g; o.frustumCulled = false;
      const ol = o.children.find((c) => c.userData.isOutline);
      let on0 = null, ON = null;
      if (ol && ol.geometry.attributes.normal && ol.geometry.attributes.normal.count === n) { const og = new THREE.BufferGeometry(); on0 = Float32Array.from(ol.geometry.attributes.normal.array); ON = new THREE.BufferAttribute(on0.slice(), 3); ON.setUsage(THREE.DynamicDrawUsage); og.setAttribute('position', P); og.setAttribute('normal', ON); if (g.index) og.setIndex(g.index); ol.geometry = og; ol.frustumCulled = false; }
      if (!Array.isArray(o.material)) o.material = this._mat(o.material);
      const pt = { o, P, N, A, C: Cb, Cr: Cb.array, on0, ON, wax: !faceM.has(o), rest, restN, rs, rn, n, idx: g.index ? g.index.array : null, li: Li.elements.slice(), ns: 1, aw: null,
        X: new Float32Array(n * 3), V: new Float32Array(n * 3), M: new Float32Array(n * 3), Ag: new Float32Array(n).fill(1e9), J: new Float32Array(n), Nr: new Float32Array(n * 3), Nd: new Float32Array(n * 3) };
      this._normals(pt, rest, pt.Nr);
      let dot = 0; for (let i = 0; i < n * 3; i++) dot += pt.Nr[i] * restN[i]; pt.ns = dot < 0 ? -1 : 1;
      this.parts.push(pt); this.byMesh.set(o, pt);
      if (!big || n > big.n) big = pt;
    }
    this.box = box; this.size = box.getSize(V3()); this.ctr = box.getCenter(V3());
    const s = this.size; this.maxDim = Math.max(s.x, s.y, s.z, 1e-6); this.minDim = Math.max(Math.min(s.x, s.y, s.z), 1e-6);
    this.rF = 0.15 * this.maxDim; this.dF = Math.min(0.95 * this.rF, 0.42 * this.minDim);
    this.cap = 1.1 * this.rF; this.maxPull = F.pull * this.maxDim; this.rP = F.pullR * this.maxDim; this.eps = 2e-4 * this.maxDim;
    this.U.uWax.value.x = 1 / (this.W.cell * this.maxDim);
    const fq = 1 / (0.55 * this.rF);
    for (const pt of this.parts) for (let i = 0; i < pt.n; i++) { const i3 = i * 3; pt.J[i] = 1 - F.lump * 0.5 + F.lump * vnoise(pt.rs[i3] * fq, pt.rs[i3 + 1] * fq, pt.rs[i3 + 2] * fq); }
    this.body = big; this.frontPart = big; this.area = 1;
    if (big) {
      big.aw = new Float32Array(big.n); let area = 0; const r = big.rs, idx = big.idx, m = idx ? idx.length : big.n - (big.n % 3);
      for (let t = 0; t < m; t += 3) {
        const a = idx ? idx[t] : t, b = idx ? idx[t + 1] : t + 1, c = idx ? idx[t + 2] : t + 2;
        _v.set(r[b * 3] - r[a * 3], r[b * 3 + 1] - r[a * 3 + 1], r[b * 3 + 2] - r[a * 3 + 2]); _w.set(r[c * 3] - r[a * 3], r[c * 3 + 1] - r[a * 3 + 1], r[c * 3 + 2] - r[a * 3 + 2]);
        const ar = _v.cross(_w).length() * 0.5; area += ar; big.aw[a] += ar / 3; big.aw[b] += ar / 3; big.aw[c] += ar / 3;
      }
      this.area = Math.max(area, 1e-6);
    }
    this.dentVol = Math.PI * this.rF * this.rF * this.dF * 0.5;
    const fb = new THREE.Box3();
    for (const g of toy.faceN || []) g.traverse((o) => { const pt = this.byMesh.get(o); if (pt) for (let i = 0; i < pt.n; i += 5) fb.expandByPoint(v.fromArray(pt.rs, i * 3)); });
    this.faceC = fb.isEmpty() ? V3(this.ctr.x, this.ctr.y + s.y * 0.15, box.max.z) : fb.getCenter(V3());
    this.faceR = fb.isEmpty() ? s.x * 0.3 : Math.max(fb.getSize(V3()).length() * 0.5, s.x * 0.18);
    this.B = Array.from({ length: MAXB }, () => ({ kind: 'finger', live: false, on: false, c: V3(), u: V3(), r: 1, T: 1, ir2: 1, iT2: 1, d: 0, v: 0, dMax: 1, pw: 1, beta: 0.5, t: 0, amt: 1, tr: [] }));
    this.lb = new Float64Array(MAXB * 12);
    this.finger = null; this.palmL = this.palmR = this.topC = null; this.slideAcc = 0;
    this.pull = { on: false, g: V3(), u: V3(), v: V3(), L: 0, last: 0, speed: 0, t: 0 };
    this.crunch = { on: false, t: 0, k: -1, P: 0, tg: 0, bA: null, bB: null, ju: 0, jv: 0, mx: this.ctr.x, g0: 1, shift: 0 };
    this.j = 0; this.jv = 0; this.jAxis = 0; this.active = false; this.idleT = 0; this.since = 9;
    this.faceSquish = false; this.palmC = 0; this.palmD = 0; this.holding = false; this.infl = 0; this.rate = 0;
    this.cells = []; this._ev = []; this.cracks = 0; this.waxLeft = 1; this.local = 1; this.strainRate = 0; this.shine = 0; this.onCrack = null; this.coatOn = true;
    this._inv = new THREE.Matrix4(); this._ray = new THREE.Ray();
    this._cells();
    if (audio) audio.warm(this.type);
  }
  get pulling() { return this.pull.on; }
  _mat(m) {
    if (!m) return m;
    if (this.mats.has(m)) return this.mats.get(m);
    const c = m.clone(), U = this.U; c.userData = { std: m.userData && m.userData.std, softOf: m };
    c.onBeforeCompile = (sh) => {
      sh.uniforms.uSqC = U.uSqC; sh.uniforms.uSqU = U.uSqU; sh.uniforms.uSqK = U.uSqK; sh.uniforms.uWax = U.uWax;
      sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\n' + VS_DECL).replace('#include <begin_vertex>', '#include <begin_vertex>\n\tvSqRest = aRest; vSqPress = aPress; vSqCrack = aCrack;');
      sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\n' + FS_DECL).replace('#include <color_fragment>', '#include <color_fragment>\n\tdiffuseColor.rgb = sqShade(diffuseColor.rgb);')
        .replace(/#include <(opaque|output)_fragment>/, (k) => 'outgoingLight += sqGloss(normal, vViewPosition);\n\t' + k);
    };
    c.customProgramCacheKey = () => 'sd-soft-4';
    this.mats.set(m, c); return c;
  }
  _normals(pt, pos, out) {
    out.fill(0); const idx = pt.idx, m = idx ? idx.length : pt.n - (pt.n % 3);
    for (let t = 0; t < m; t += 3) {
      const a = (idx ? idx[t] : t) * 3, b = (idx ? idx[t + 1] : t + 1) * 3, c = (idx ? idx[t + 2] : t + 2) * 3;
      const ex = pos[b] - pos[a], ey = pos[b + 1] - pos[a + 1], ez = pos[b + 2] - pos[a + 2], fx = pos[c] - pos[a], fy = pos[c + 1] - pos[a + 1], fz = pos[c + 2] - pos[a + 2];
      const nx = ey * fz - ez * fy, ny = ez * fx - ex * fz, nz = ex * fy - ey * fx;
      out[a] += nx; out[a + 1] += ny; out[a + 2] += nz; out[b] += nx; out[b + 1] += ny; out[b + 2] += nz; out[c] += nx; out[c + 1] += ny; out[c + 2] += nz;
    }
    for (let i = 0; i < out.length; i += 3) { const l = Math.hypot(out[i], out[i + 1], out[i + 2]) || 1; out[i] /= l; out[i + 1] /= l; out[i + 2] /= l; }
  }

  /* ---- wax cells: Poisson-disk samples over the coat, each with neighbours (crack cascades) and a vertex footprint (crack reveal) ---- */
  _cells() {
    const dc = 0.085 * this.maxDim, inv = 1 / dc, dc2 = dc * dc, K = (x, y, z) => ((x + 1024) * 2048 + (y + 1024)) * 2048 + (z + 1024);
    const grid = new Map(), cells = (this.cells = []), MAXC = 480;
    for (const pt of this.parts) {
      if (!pt.wax || cells.length >= MAXC) continue;
      const order = new Int32Array(pt.n); for (let i = 0; i < pt.n; i++) order[i] = i;
      for (let i = pt.n - 1; i > 0; i--) { const j = (R() * (i + 1)) | 0, t = order[i]; order[i] = order[j]; order[j] = t; }
      for (const i of order) {
        const x = pt.rs[i * 3], y = pt.rs[i * 3 + 1], z = pt.rs[i * 3 + 2], gx = Math.floor(x * inv), gy = Math.floor(y * inv), gz = Math.floor(z * inv);
        let ok = true;
        for (let a = -1; a <= 1 && ok; a++) for (let b = -1; b <= 1 && ok; b++) for (let e = -1; e <= 1 && ok; e++) {
          const L = grid.get(K(gx + a, gy + b, gz + e)); if (L) for (const c of L) if ((c.x - x) ** 2 + (c.y - y) ** 2 + (c.z - z) ** 2 < dc2) { ok = false; break; }
        }
        if (!ok) continue;
        const c = { pt, i, x, y, z, nx: pt.restN[i * 3], ny: pt.restN[i * 3 + 1], nz: pt.restN[i * 3 + 2], m: 0, s: 0, th: this.W.th * Math.exp(0.35 * gauss()), I: 1, nb: [], v: [] };
        cells.push(c); const k = K(gx, gy, gz); (grid.get(k) || grid.set(k, []).get(k)).push(c);
        if (cells.length >= MAXC) break;
      }
    }
    const nb2 = (2 * dc) ** 2;
    for (let a = 0; a < cells.length; a++) for (let b = a + 1; b < cells.length; b++) { const p = cells[a], q = cells[b]; if ((p.x - q.x) ** 2 + (p.y - q.y) ** 2 + (p.z - q.z) ** 2 < nb2) { p.nb.push(b); q.nb.push(a); } }
    const rc = 1.7 * dc, rc2 = rc * rc, ir = 1 / rc, g2 = new Map();
    cells.forEach((c, k) => { const key = K(Math.floor(c.x * ir), Math.floor(c.y * ir), Math.floor(c.z * ir)); (g2.get(key) || g2.set(key, []).get(key)).push(k); });
    for (const pt of this.parts) {
      if (!pt.wax) continue;
      const tmp = new Map();
      for (let i = 0; i < pt.n; i++) {
        const x = pt.rs[i * 3], y = pt.rs[i * 3 + 1], z = pt.rs[i * 3 + 2], gx = Math.floor(x * ir), gy = Math.floor(y * ir), gz = Math.floor(z * ir);
        for (let a = -1; a <= 1; a++) for (let b = -1; b <= 1; b++) for (let e = -1; e <= 1; e++) {
          const L = g2.get(K(gx + a, gy + b, gz + e)); if (!L) continue;
          for (const k of L) { const c = cells[k], d2 = (c.x - x) ** 2 + (c.y - y) ** 2 + (c.z - z) ** 2; if (d2 < rc2) { const q = 1 - d2 / rc2; let en = tmp.get(k); if (!en) tmp.set(k, (en = { idx: [], w: [] })); en.idx.push(i); en.w.push(q * q); } }
        }
      }
      for (const [k, en] of tmp) cells[k].v.push({ pt, idx: Int32Array.from(en.idx), w: Float32Array.from(en.w) });
    }
  }
  _damage(c, E) {
    const a = 0.14 * E;
    for (const L of c.v) { const Cr = L.pt.Cr, idx = L.idx, w = L.w; for (let k = 0; k < idx.length; k++) { const i = idx[k], v = Cr[i] + a * w[k]; Cr[i] = v > 1 ? 1 : v; } L.pt.C.needsUpdate = true; }
  }
  /* stress → crack: bending (normal swing) and pressing (displacement change) load each cell; past its threshold it cracks,
     drops most of its stress, loads its neighbours (cascades = crackle bursts) and wears. Returns this frame's total strain. */
  _wax(dt) {
    const cells = this.cells, W = this.W, iRF = 1 / this.rF, ev = this._ev, relax = Math.exp(-dt * 1.4);
    let sum = 0, Is = 0; ev.length = 0;
    for (let k = 0; k < cells.length; k++) {
      const c = cells[k], pt = c.pt, i3 = c.i * 3, N = pt.N.array, X = pt.X;
      const nx = N[i3], ny = N[i3 + 1], nz = N[i3 + 2], ang = Math.sqrt(Math.max(0, 2 - 2 * (nx * c.nx + ny * c.ny + nz * c.nz)));
      const m = Math.sqrt(X[i3] * X[i3] + X[i3 + 1] * X[i3 + 1] + X[i3 + 2] * X[i3 + 2]), st = ang * 1.3 + Math.abs(m - c.m) * iRF;
      c.nx = nx; c.ny = ny; c.nz = nz; c.m = m; sum += st; Is += c.I;
      c.s = c.s * relax + st * (0.3 + 0.7 * c.I);
      if (c.s > c.th) ev.push(k);
    }
    this.waxLeft = cells.length ? Is / cells.length : 1;
    if (ev.length) {
      ev.sort((a, b) => cells[b].s / cells[b].th - cells[a].s / cells[a].th);
      for (let q = 0; q < ev.length; q++) {
        const c = cells[ev[q]], E = clamp((c.s / c.th) * Math.exp(0.45 * gauss()), 0.3, 3) * (0.45 + 0.55 * c.I);
        c.s = Math.max(0, c.s - c.th * rr(0.75, 1)); c.th = W.th * Math.exp(0.35 * gauss());
        if (q >= 6) continue;
        this.local += (c.I - this.local) * 0.04; c.I = Math.max(0, c.I - W.wear * E); this.cracks++;
        for (const j of c.nb) { const o = cells[j]; o.s += o.th * 0.07 * R() * o.I; }
        if (this.audio && this.audio.crack) this.audio.crack(this.type, E, this._pan(c), c.I);
        if (this.onCrack) this.onCrack(c, E);
      }
    }
    return sum;
  }
  cellWorld(c, pos, nrm) {
    const o = c.pt.o; o.updateWorldMatrix(true, false);
    pos.fromArray(c.pt.P.array, c.i * 3).applyMatrix4(o.matrixWorld);
    if (nrm) nrm.fromArray(c.pt.N.array, c.i * 3).transformDirection(o.matrixWorld);
    return pos;
  }
  rewax() {
    for (const pt of this.parts) if (pt.wax) { pt.Cr.fill(0); pt.C.needsUpdate = true; }
    for (const c of this.cells) { c.I = 1; c.s = 0; }
    this.cracks = 0; this.waxLeft = 1; this.local = 1; this.shine = 1; this._wake();
  }

  /* ---- brushes ---- */
  _slot() { let best = null; for (const b of this.B) { if (!b.live) return b; if (!b.on && (!best || b.d < best.d)) best = b; } return best || this.B[0]; }
  _set(kind, p, u, r, T, dMax, o = {}) {
    const b = this._slot();
    Object.assign(b, { kind, live: true, on: true, r, T, ir2: 1 / (r * r), iT2: 1 / (T * T), dMax, pw: o.pw ?? 1, beta: o.beta ?? this.F.beta, t: 0, d: o.d ?? 0, v: 0, amt: 1 });
    b.tr.length = 0; b.c.copy(p); b.u.copy(u).normalize(); this._wake(); return b;
  }
  _wake() { this.active = true; this.idleT = 0; }
  _pan(c) { return clamp((c.x - this.ctr.x) / (this.size.x * 0.5), -1, 1) * this.panK; }
  _axis(u) { const x = Math.abs(u.x), y = Math.abs(u.y), z = Math.abs(u.z); return x > y && x > z ? 0 : y > z ? 1 : 2; }
  kick(v, axis) { this.jv += v * 20; this.jAxis = axis; this._wake(); }

  fingerDown(h) {
    if (this.finger || this.pull.on) this.fingerUp(true);
    const b = this._set('finger', h.p, _u.copy(h.n).negate(), this.rF, this.rF * 1.4, this.dF);
    this.finger = b; this.slideAcc = 0;
    this.kick(0.022, this._axis(b.u)); if (this.squisher) this.squisher.kick(-0.6);
    if (this.audio) this.audio.press(this.type, 'finger', this.pitch, this._pan(b.c), 1);
    return b;
  }
  /* knead: slide the fingertip to a new surface point; the path is stamped into the memory field with smear */
  fingerMove(h) {
    if (this.pull.on) return null;
    const b = this.finger; if (!b) return this.fingerDown(h);
    const nu = h.n.clone().negate(), dist = h.p.distanceTo(b.c);
    if (dist < 1e-7) return b;
    if (dist < this.rF * 3.5) b.tr.push({ a: b.c.clone(), b: h.p.clone(), ua: b.u.clone(), ub: nu });
    b.c.copy(h.p); b.u.copy(nu); this._wake();
    this.slideAcc += dist;
    if (this.slideAcc > this.rF * 0.7) { this.slideAcc = 0; if (this.audio) this.audio.squish(this.type, this.pitch, this._pan(b.c), 0.42, true); }
    return b;
  }
  /* stretch: once the cursor leaves the silhouette the grabbed surface follows it, like taffy, until release or it slips */
  pullTo(rayW) {
    const pl = this.pull;
    if (!pl.on) {
      const b = this.finger; if (!b) return;
      pl.on = true; pl.g.copy(b.c); pl.u.copy(b.u); pl.v.set(0, 0, 0); pl.L = pl.last = pl.speed = pl.t = 0;
      b.on = false; b.tr.length = 0; this.finger = null;
      if (this.squisher) this.squisher.kick(-0.3);
    }
    const sq = this.toy.squash; sq.updateWorldMatrix(true, false);
    const r = this._ray.copy(rayW).applyMatrix4(this._inv.copy(sq.matrixWorld).invert()), dn = r.direction;
    const t = _v.copy(pl.g).sub(r.origin).dot(dn), hit = _w.copy(r.origin).addScaledVector(dn, t), vv = hit.sub(pl.g);
    const L = vv.length(), mx = this.maxPull;
    if (L > mx * 1.75) { this._pullEnd(false, true); return; }
    const Ls = mx * Math.tanh(L / mx); if (L > 1e-9) vv.multiplyScalar(Ls / L);
    pl.v.copy(vv); pl.L = Ls; this._wake();
  }
  fingerUp(silent) {
    if (this.pull.on) { this._pullEnd(silent, false); return; }
    const b = this.finger; if (!b) return; b.on = false; b.tr.length = 0; this.finger = null;
    const a = clamp(b.d / b.dMax, 0.25, 1), p = this._pan(b.c);
    this.kick(-0.016, this._axis(b.u)); if (this.squisher) this.squisher.kick(0.7);
    if (this.audio && !silent) { this.audio.release(this.type, 'finger', this.pitch, p, a); this.audio.air(this.type, this.F.rise, p, a * 0.6); }
  }
  _pullEnd(silent, slipped) {
    const pl = this.pull; if (!pl.on) return;
    const a = clamp(pl.L / this.maxPull, 0, 1);
    if (this.F.plastic > 0 && a > 0.05) this._plastic(this.F.plastic);
    pl.on = false; pl.L = 0; pl.v.set(0, 0, 0);
    this.kick(-0.05 * a - 0.012, this._axis(pl.u)); if (this.squisher) this.squisher.kick(1.2 * a);
    if (this.audio && !silent) { this.audio.snap(this.type, this.pitch, this._pan(pl.g), a, slipped); this.audio.air(this.type, this.F.rise, this._pan(pl.g), 0.4 * a); }
    this._wake();
  }
  _plastic(k) {
    const pl = this.pull, rise = this.F.rise, gx = pl.g.x, gy = pl.g.y, gz = pl.g.z, vx = pl.v.x * k, vy = pl.v.y * k, vz = pl.v.z * k;
    const rp = this.rP * (1 + 0.5 * pl.L / this.maxPull), irp2 = 1 / (rp * rp);
    for (const pt of this.parts) {
      const { rs, n, M, Ag } = pt;
      for (let i = 0; i < n; i++) {
        const i3 = i * 3, dx = rs[i3] - gx, dy = rs[i3 + 1] - gy, dz = rs[i3 + 2] - gz, w = Math.exp(-(dx * dx + dy * dy + dz * dz) * irp2);
        if (w < 0.02) continue;
        const R2 = Ag[i] >= rise ? 0 : 1 - sm(Ag[i] / rise);
        M[i3] = M[i3] * R2 + vx * w; M[i3 + 1] = M[i3 + 1] * R2 + vy * w; M[i3 + 2] = M[i3 + 2] * R2 + vz * w; Ag[i] = 0;
      }
    }
  }
  palms(on) {
    if (on) {
      if (this.palmL) return;
      const s = this.size, b = this.box, cy = this.ctr.y, cz = this.ctr.z, r = 0.5 * Math.min(s.y, s.z), T = 0.55 * s.x, dm = Math.min(0.3 * s.x, (1 - this.toy.meta.squeeze.depth) * 0.55 * s.x), o = { beta: this.F.beta * 0.35, pw: 1.5 };
      this.palmL = this._set('palm', _v.set(b.min.x, cy, cz), _w.set(1, 0, 0), r, T, dm, o);
      this.palmR = this._set('palm', _v.set(b.max.x, cy, cz), _w.set(-1, 0, 0), r, T, dm, o);
      this.holding = true; this.kick(0.05, 0); if (this.squisher) this.squisher.kick(-0.6);
      if (this.audio) this.audio.press(this.type, 'palm', this.pitch, 0, 1);
    } else {
      if (!this.palmL) return;
      const a = clamp(this.palmC, 0.3, 1);
      this.palmL.on = this.palmR.on = false; this.palmL = this.palmR = null; this.holding = false;
      this.kick(-0.045, 0); if (this.squisher) this.squisher.kick(0.8);
      if (this.audio) { this.audio.release(this.type, 'palm', this.pitch, 0, a); this.audio.air(this.type, this.F.rise, 0, a); }
    }
  }
  top(on) {
    if (on) {
      if (this.topC) return;
      const s = this.size;
      this.topC = this._set('palm', _v.set(this.ctr.x, this.box.max.y, this.ctr.z), _w.set(0, -1, 0), 0.42 * Math.max(s.x, s.z), 0.6 * s.y, 0.2 * s.y, { beta: this.F.beta * 0.35, pw: 1.5 });
      this.holding = true; this.kick(0.03, 1);
      if (this.audio) this.audio.press(this.type, 'palm', this.pitch, 0, 1);
    } else {
      if (!this.topC) return;
      const a = clamp(this.palmC, 0.3, 1);
      this.topC.on = false; this.topC = null; this.holding = false; this.kick(-0.03, 1);
      if (this.audio) { this.audio.release(this.type, 'palm', this.pitch, 0, a); this.audio.air(this.type, this.F.rise, 0, a); }
    }
  }
  /* two-thumb crunch (the reference clip): hold = press in, slide together, ease off, press again (0.56 s cycle) */
  thumbs(on) {
    const C = this.crunch;
    if (on) {
      if (C.on) return;
      if (this.finger || this.pull.on) this.fingerUp(true);
      const s = this.size, rT = 0.11 * this.maxDim, d = Math.min(0.9 * rT, 0.3 * this.minDim), o = { beta: this.F.beta * 0.6 };
      C.on = true; C.t = 0; C.k = -1; C.ju = C.jv = 0; C.mx = this.ctr.x; C.g0 = 0.48 * 0.36 * s.x; C.shift = 0.2 * 0.36 * s.x;
      const A = this.frontPoint(-0.48, 0.12), B = this.frontPoint(0.48, 0.12);
      C.bA = this._set('thumb', A.p, _u.copy(A.n).negate(), rT, rT * 1.35, d, o);
      C.bB = this._set('thumb', B.p, _u.copy(B.n).negate(), rT, rT * 1.35, d, o);
      C.bA.amt = C.bB.amt = 0.3;
      this.kick(0.035, 2); if (this.squisher) this.squisher.kick(-0.5);
      if (this.audio) this.audio.press(this.type, 'thumb', this.pitch, 0, 1);
    } else {
      if (!C.on) return;
      C.on = false; if (C.bA) C.bA.on = false; if (C.bB) C.bB.on = false; C.bA = C.bB = null;
      this.kick(-0.03, 2); if (this.squisher) this.squisher.kick(0.6);
      if (this.audio) { this.audio.release(this.type, 'thumb', this.pitch, 0, 0.8); this.audio.air(this.type, this.F.rise, 0, 0.8); }
      this._wake();
    }
  }
  _crunchStep(dt) {
    const C = this.crunch;
    if (C.on) {
      C.t += dt; const per = 0.56, k = Math.floor(C.t / per), ph = C.t / per - k;
      if (k !== C.k) { C.k = k; C.ju = k ? rr(-0.06, 0.06) : 0; C.jv = k ? rr(-0.08, 0.08) : 0; }
      const lo = k ? 0.42 : 0;
      C.tg = ph < 0.5 ? lo + (1 - lo) * ease(ph / 0.5) : ph < 0.7 ? 1 : 1 - 0.58 * ease((ph - 0.7) / 0.3);
      C.P += (C.tg - C.P) * Math.min(1, dt * 22);
      const u = 0.48 - 0.2 * C.P, w = 0.12 + C.jv;
      for (const [b, sg] of [[C.bA, -1], [C.bB, 1]]) {
        if (!b) continue;
        const h = this.frontPoint(sg * u + C.ju, w), nu = _u.copy(h.n).negate();
        if (b.c.distanceToSquared(h.p) > 1e-12) b.tr.push({ a: b.c.clone(), b: h.p.clone(), ua: b.u.clone(), ub: nu.clone() });
        b.c.copy(h.p); b.u.copy(nu); b.amt = 0.3 + 0.7 * C.P;
      }
      this._wake();
    } else if (C.P > 0) { C.P -= C.P * Math.min(1, (dt * 1.6) / Math.max(0.3, this.F.rise)); if (C.P < 1e-3) C.P = 0; }
  }
  thumbTip(k, target) { const b = k ? this.crunch.bB : this.crunch.bA; if (!b) return null; target.copy(b.c).addScaledVector(b.u, b.d); return this.toy.squash.localToWorld(target); }
  /* rest-space hit from a raycast on the deformed mesh */
  restHit(hit) {
    const pt = this.byMesh.get(hit.object); if (!pt || !hit.face) return null;
    const P = pt.P.array, { a, b, c } = hit.face, pl = hit.object.worldToLocal(hit.point.clone());
    const bc = THREE.Triangle.getBarycoord(pl, V3().fromArray(P, a * 3), V3().fromArray(P, b * 3), V3().fromArray(P, c * 3), V3());
    if (!bc) return null;
    const p = V3(), n = V3(), rs = pt.rs, rn = pt.rn;
    for (const [i, w] of [[a, bc.x], [b, bc.y], [c, bc.z]]) { p.x += rs[i * 3] * w; p.y += rs[i * 3 + 1] * w; p.z += rs[i * 3 + 2] * w; n.x += rn[i * 3] * w; n.y += rn[i * 3 + 1] * w; n.z += rn[i * 3 + 2] * w; }
    if (n.lengthSq() < 1e-8) return null;
    return { p, n: n.normalize() };
  }
  /* scripted pokes: nearest front-facing body vertex to (u,v) in [-1,1] */
  frontPoint(u = 0, w = 0) {
    const pt = this.frontPart, s = this.size, tx = this.ctr.x + u * 0.36 * s.x, ty = this.ctr.y + w * 0.32 * s.y;
    let bi = -1, bd = Infinity;
    for (let i = 0; i < pt.n; i++) { if (pt.rn[i * 3 + 2] < 0.55) continue; const dx = pt.rs[i * 3] - tx, dy = pt.rs[i * 3 + 1] - ty, d = dx * dx + dy * dy; if (d < bd) { bd = d; bi = i; } }
    if (bi < 0) return { p: V3(this.ctr.x, this.ctr.y, this.box.max.z), n: V3(0, 0, 1) };
    return { p: V3().fromArray(pt.rs, bi * 3), n: V3().fromArray(pt.rn, bi * 3) };
  }
  fingerTip(target) {
    const pl = this.pull, f = this.finger;
    if (pl.on) target.copy(pl.g).add(pl.v);
    else if (f) target.copy(f.c).addScaledVector(f.u, f.d);
    else target.copy(this.ctr);
    return this.toy.squash.localToWorld(target);
  }

  /* ---- memory field ---- */
  _write(cx, cy, cz, ux, uy, uz, b, ddx, ddy, ddz) {
    const F = this.F, rise = F.rise, val0 = b.d * (1 - F.fast), ir2 = b.ir2, iT2 = b.iT2, p15 = b.pw !== 1, be = b.beta, cap = this.cap, cap2 = cap * cap;
    const mv = ddx !== 0 || ddy !== 0 || ddz !== 0;
    if (mv) { const dd = ddx * ux + ddy * uy + ddz * uz; ddx = (ddx - dd * ux) * F.smear; ddy = (ddy - dd * uy) * F.smear; ddz = (ddz - dd * uz) * F.smear; }
    for (const pt of this.parts) {
      const { rs, n, M, Ag, J } = pt;
      for (let i = 0; i < n; i++) {
        const i3 = i * 3, vx = rs[i3] - cx, vy = rs[i3 + 1] - cy, vz = rs[i3 + 2] - cz, hh = vx * ux + vy * uy + vz * uz, ha = hh > 0 ? hh : hh * 0.25, q = ha * ha * iT2;
        if (q > 6) continue;
        const tx = vx - hh * ux, ty = vy - hh * uy, tz = vz - hh * uz, s = (tx * tx + ty * ty + tz * tz) * ir2;
        if (s > 6) continue;
        const val = val0 * Math.exp(-(p15 ? s * Math.sqrt(s) : s) - q) * Math.max(0, 1 - be * s) * J[i];
        const a = Ag[i], R2 = a >= rise ? 0 : 1 - sm(a / rise);
        let mx = M[i3] * R2, my = M[i3 + 1] * R2, mz = M[i3 + 2] * R2;
        const cur = mx * ux + my * uy + mz * uz, es = mv ? Math.exp(-s * 0.7 - q) : 0;
        if ((val <= 1e-9 || val <= cur * 0.85) && es < 0.03) continue;
        if (val > cur) { const e = val - cur; mx += ux * e; my += uy * e; mz += uz * e; }
        if (es >= 0.03) { mx += ddx * es; my += ddy * es; mz += ddz * es; }
        const l2 = mx * mx + my * my + mz * mz; if (l2 > cap2) { const k = cap / Math.sqrt(l2); mx *= k; my *= k; mz *= k; }
        M[i3] = mx; M[i3 + 1] = my; M[i3 + 2] = mz; Ag[i] = 0;
      }
    }
  }
  _stroke(s, b) {
    const dx = s.b.x - s.a.x, dy = s.b.y - s.a.y, dz = s.b.z - s.a.z, len = Math.hypot(dx, dy, dz), steps = Math.max(1, Math.ceil(len / (this.rF * 0.28)));
    for (let k = 1; k <= steps; k++) {
      const t = k / steps; _u.copy(s.ua).lerp(s.ub, t).normalize();
      this._write(s.a.x + dx * t, s.a.y + dy * t, s.a.z + dz * t, _u.x, _u.y, _u.z, b, dx / steps, dy / steps, dz / steps);
    }
  }

  /* ---- per frame (call after the Squisher update: jiggle multiplies its scale) ---- */
  update(dt) {
    if (!this.active || dt <= 0 || !this.body) return;
    const F = this.F, rise = F.rise, Lb = this.lb, pl = this.pull, pOn = pl.on, Cn = this.crunch;
    const wax = (this.coatOn = !this.audio || this.audio.mode !== 'slime');
    this._crunchStep(dt);
    let pressed = pOn || Cn.on, palmMax = 0, palmD = 0, nl = 0;
    for (let q = 0; q < MAXB; q++) {
      const b = this.B[q], C4 = this.U.uSqC.value[q], U4 = this.U.uSqU.value[q];
      if (!b.live) { U4.w = 0; continue; }
      b.t += dt;
      let tg = 0;
      if (b.on) { pressed = true; const fi = b.kind !== 'palm', dl = fi ? 0.035 : 0.03; if (b.t > dl) tg = b.dMax * b.amt * sm((b.t - dl) / (fi ? 0.09 : 0.16)) * (0.86 + 0.14 * sm((b.t - dl) / 1.2)); }
      const ns = Math.max(1, Math.ceil(dt * 240)), h = dt / ns;
      for (let i = 0; i < ns; i++) { b.v += (650 * (tg - b.d) - 50 * b.v) * h; b.d += b.v * h; }
      if (!b.on && b.d < b.dMax * 0.01 && Math.abs(b.v) < b.dMax * 0.3) { b.live = false; b.d = b.v = 0; b.tr.length = 0; U4.w = 0; continue; }
      if (b.kind === 'palm') { palmMax = Math.max(palmMax, b.d / b.dMax); palmD = Math.max(palmD, b.d); }
      if (b.on && b.d > 1e-7) { if (b.tr.length) { for (const s of b.tr) this._stroke(s, b); b.tr.length = 0; } else this._write(b.c.x, b.c.y, b.c.z, b.u.x, b.u.y, b.u.z, b, 0, 0, 0); }
      else b.tr.length = 0;
      const o = nl * 12; Lb[o] = b.c.x; Lb[o + 1] = b.c.y; Lb[o + 2] = b.c.z; Lb[o + 3] = b.u.x; Lb[o + 4] = b.u.y; Lb[o + 5] = b.u.z; Lb[o + 6] = b.ir2; Lb[o + 7] = b.iT2; Lb[o + 8] = b.d; Lb[o + 9] = b.beta; Lb[o + 10] = b.pw; nl++;
      C4.set(b.c.x, b.c.y, b.c.z, b.r); U4.set(b.u.x, b.u.y, b.u.z, clamp(b.d / (b.kind === 'palm' ? b.dMax * 1.25 : b.dMax), 0, 1));
    }
    let gx = 0, gy = 0, gz = 0, pvx = 0, pvy = 0, pvz = 0, ihx = 0, ihy = 0, ihz = 0, irp2 = 0, nkK = 0;
    if (pOn) {
      pl.t += dt; gx = pl.g.x; gy = pl.g.y; gz = pl.g.z; pvx = pl.v.x; pvy = pl.v.y; pvz = pl.v.z;
      const Lp = Math.max(pl.L, 1e-9), rp = this.rP * (1 + 0.5 * pl.L / this.maxPull);
      ihx = pvx / Lp; ihy = pvy / Lp; ihz = pvz / Lp; irp2 = 1 / (rp * rp); nkK = F.neck * 2 * Math.min(1, pl.L / rp);
      pl.speed += (Math.abs(pl.L - pl.last) / dt - pl.speed) * Math.min(1, dt * 12); pl.last = pl.L;
    }
    /* pinch field: compress between the thumbs, ridge out toward the camera, fold the top down, swell + curl the ends */
    const PP = Cn.P, pin = PP > 1e-4, sz = this.size, pcy = this.ctr.y, pcz = this.ctr.z;
    let pmx = 0, pg0 = 1, psh = 0, piF = 0, piHy = 0, piHz = 0, piW2 = 0, phR = 0, pdip = 0, pbz = 0, pby = 0, peb = 0, pW2g = 1;
    if (pin) {
      pmx = Cn.mx; pg0 = Cn.g0; psh = Cn.shift * PP; piF = 1 / (0.35 * sz.x); piHy = 2 / sz.y; piHz = 2 / sz.z; piW2 = 2 / sz.x;
      phR = 0.3 * sz.z * PP; pdip = 0.16 * sz.y * PP; pbz = 0.14 * sz.z * PP; pby = 0.06 * sz.y * PP; peb = 0.08 * PP; pW2g = 1 / Math.max(1e-6, sz.x * 0.5 - pg0);
    }
    const k = F.k, c = F.c, ns = Math.max(1, Math.ceil(dt * 90)), h = dt / ns, infl = this.infl, iF = 1 / (0.25 * this.dF), iD = 1 / this.dF, eps = this.eps, eV = eps * 20;
    let vol = 0, rate = 0, moving = false, mem = false;
    for (const pt of this.parts) {
      const { rs, rn, rest, restN, n, li, M, Ag, X, V, J, aw } = pt, Pa = pt.P.array, Aa = pt.A.array;
      for (let i = 0; i < n; i++) {
        const i3 = i * 3, px = rs[i3], py = rs[i3 + 1], pz = rs[i3 + 2];
        let tx = 0, ty = 0, tz = 0, a = Ag[i];
        if (a < rise) {
          a += dt; Ag[i] = a;
          if (a < rise) { const R2 = 1 - sm(a / rise); tx = M[i3] * R2; ty = M[i3 + 1] * R2; tz = M[i3 + 2] * R2; mem = true; }
          else M[i3] = M[i3 + 1] = M[i3 + 2] = 0;
        }
        if (pin) {
          const s = px - pmx, as = s < 0 ? -s : s, yN = (py - pcy) * piHy, zN = (pz - pcz) * piHz, fr = sm((zN + 0.4) / 1.4);
          let dx;
          if (as < pg0) { dx = (-psh * s) / pg0; const qq = 1 - (as / pg0) * (as / pg0); tz += phR * qq * qq * (0.3 + 0.7 * fr) * Math.exp(-(yN - 0.1) * (yN - 0.1) * 1.5); ty -= pdip * qq * sm((yN + 0.1) / 1.1) * (0.4 + 0.6 * fr); }
          else { const oo = (as - pg0) * piF, e = peb * sm((as - pg0) * pW2g); dx = -(s < 0 ? -1 : 1) * psh * Math.exp(-oo * oo); ty += (py - pcy) * e; tz += (pz - pcz) * e; }
          const wy = Math.exp(-(yN - 0.1) * (yN - 0.1) * 1.2); tx += dx * (0.6 + 0.4 * fr) * (0.35 + 0.65 * wy);
          const e2 = s * piW2, ee = e2 * e2; tz += pbz * ee; ty += pby * ee;
        }
        for (let q = 0; q < nl; q++) {
          const o = q * 12, ux = Lb[o + 3], uy = Lb[o + 4], uz = Lb[o + 5];
          const vx = px - Lb[o], vy = py - Lb[o + 1], vz = pz - Lb[o + 2], hh = vx * ux + vy * uy + vz * uz, ha = hh > 0 ? hh : hh * 0.25, q2 = ha * ha * Lb[o + 7];
          if (q2 > 7) continue;
          const sx = vx - hh * ux, sy = vy - hh * uy, sz2 = vz - hh * uz, s = (sx * sx + sy * sy + sz2 * sz2) * Lb[o + 6];
          if (s > 7) continue;
          const val = Lb[o + 8] * Math.exp(-(Lb[o + 10] === 1 ? s : s * Math.sqrt(s)) - q2) * (1 - Lb[o + 9] * s) * J[i];
          if (val > 0) { const pr = tx * ux + ty * uy + tz * uz; if (val > pr) { const e = val - pr; tx += ux * e; ty += uy * e; tz += uz * e; } }
          else { tx += ux * val; ty += uy * val; tz += uz * val; }
        }
        if (pOn) {
          const dx = px - gx, dy = py - gy, dz = pz - gz, w = Math.exp(-(dx * dx + dy * dy + dz * dz) * irp2), al = dx * ihx + dy * ihy + dz * ihz, nk = nkK * w * (1 - w), ww = w + 0.08 * (1 - w);
          tx += pvx * ww - (dx - ihx * al) * nk; ty += pvy * ww - (dy - ihy * al) * nk; tz += pvz * ww - (dz - ihz * al) * nk;
        }
        let x = X[i3], y = X[i3 + 1], z = X[i3 + 2], vx = V[i3], vy = V[i3 + 1], vz = V[i3 + 2];
        for (let si = 0; si < ns; si++) { vx += (k * (tx - x) - c * vx) * h; vy += (k * (ty - y) - c * vy) * h; vz += (k * (tz - z) - c * vz) * h; x += vx * h; y += vy * h; z += vz * h; }
        X[i3] = x; X[i3 + 1] = y; X[i3 + 2] = z; V[i3] = vx; V[i3 + 1] = vy; V[i3 + 2] = vz;
        if (!moving && (Math.abs(tx - x) + Math.abs(ty - y) + Math.abs(tz - z) > eps || Math.abs(vx) + Math.abs(vy) + Math.abs(vz) > eV)) moving = true;
        const nx = rn[i3], ny = rn[i3 + 1], nz = rn[i3 + 2];
        if (aw) { const dn = -(x * nx + y * ny + z * nz); if (dn > 0) vol += dn * aw[i]; rate += Math.abs(vx * nx + vy * ny + vz * nz) * aw[i]; }
        const mag = Math.sqrt(x * x + y * y + z * z), fr = infl * (1 - Math.min(1, mag * iF));
        const dx = x + nx * fr, dy = y + ny * fr, dz = z + nz * fr;
        Pa[i3] = rest[i3] + li[0] * dx + li[3] * dy + li[6] * dz;
        Pa[i3 + 1] = rest[i3 + 1] + li[1] * dx + li[4] * dy + li[7] * dz;
        Pa[i3 + 2] = rest[i3 + 2] + li[2] * dx + li[5] * dy + li[8] * dz;
        Aa[i] = Math.min(1, mag * iD);
      }
      this._normals(pt, Pa, pt.Nd);
      const Na = pt.N.array, Nd = pt.Nd, Nr = pt.Nr, sg = pt.ns;
      for (let i = 0; i < n * 3; i += 3) {
        const ax = restN[i] + sg * (Nd[i] - Nr[i]), ay = restN[i + 1] + sg * (Nd[i + 1] - Nr[i + 1]), az = restN[i + 2] + sg * (Nd[i + 2] - Nr[i + 2]), l = 1 / (Math.hypot(ax, ay, az) || 1);
        Na[i] = ax * l; Na[i + 1] = ay * l; Na[i + 2] = az * l;
      }
      if (pt.ON) { const o0 = pt.on0, oa = pt.ON.array; for (let i = 0; i < n * 3; i += 3) { const ax = o0[i] + Na[i] - restN[i], ay = o0[i + 1] + Na[i + 1] - restN[i + 1], az = o0[i + 2] + Na[i + 2] - restN[i + 2], l = 1 / (Math.hypot(ax, ay, az) || 1); oa[i] = ax * l; oa[i + 1] = ay * l; oa[i + 2] = az * l; } pt.ON.needsUpdate = true; }
      pt.P.needsUpdate = pt.N.needsUpdate = pt.A.needsUpdate = true;
    }
    this.infl += ((F.gamma * vol) / this.area - this.infl) * Math.min(1, dt * 30);
    this.rate = rate / this.dentVol;
    const nj = Math.max(1, Math.ceil(dt * 240)), hj = dt / nj;
    for (let i = 0; i < nj; i++) { this.jv += (-F.jig[0] * this.j - F.jig[1] * this.jv) * hj; this.j += this.jv * hj; }
    this.palmC = palmMax; this.palmD = palmD; this.since = pressed ? 0 : this.since + dt;
    let fs = palmMax > (this.faceSquish ? 0.18 : 0.3);
    const f = this.finger;
    if (f && f.d > f.dMax * 0.4 && (this.type === 'jelly' || f.c.distanceTo(this.faceC) < this.faceR * 1.5)) fs = true;
    if (pOn && pl.L > this.maxPull * 0.3) fs = true;
    if (PP > 0.3) fs = true;
    this.faceSquish = fs;
    if (this.squisher) this.squisher.lockFace = fs;
    if (fs && this.toy.setFace && this.toy.face !== 'squish') this.toy.setFace('squish');
    const j = this.j * F.wob, s = this.toy.squash.scale;
    if (Math.abs(j) > 1e-5) { const a = 1 - j, b = 1 + j * 0.5; if (this.jAxis === 0) { s.x *= a; s.y *= b; s.z *= b; } else if (this.jAxis === 1) { s.y *= a; s.x *= b; s.z *= b; } else { s.z *= a; s.x *= b; s.y *= b; } }
    const strain = wax && this.cells.length ? this._wax(dt) : 0;
    this.shine = Math.max(0, this.shine - dt * 1.1);
    const UW = this.U.uWax.value; UW.z = wax ? 1 : 0; UW.w = this.W.gloss * (1 + 2.5 * this.shine);
    if (this.audio) {
      const pc = pOn ? pl.g : f ? f.c : null, pan = pc ? this._pan(pc) : 0;
      if (wax) {
        this.strainRate = strain / dt / (this.cells.length || 1); const drive = Math.min(1, this.strainRate / 3);
        this.audio.waxFrame(this.type, drive, pressed ? Math.max(palmMax, PP, f ? f.d / f.dMax : 0) : 0, this.waxLeft, pan, dt);
      } else {
        const act = Math.min(1, Math.pow(this.rate / 9, 0.75));
        this.audio.knead(this.type, pressed ? act : act * 0.55, pressed ? Math.max(palmMax, PP, f ? f.d / f.dMax : 0) : 0, pan, dt, this.pitch);
        if (pOn) this.audio.stretch(this.type, Math.min(1, pl.speed / (this.maxPull * 2.2)), pl.L / this.maxPull, pan, dt, this.pitch);
      }
    }
    if (nl === 0 && !pOn && !Cn.on && PP <= 0 && !mem && !moving && this.shine <= 0 && Math.abs(this.j) < 1e-4 && Math.abs(this.jv) < 1e-3 && Math.abs(this.infl) < eps) {
      this.idleT += dt; if (this.idleT > 0.12) this._rest();
    } else this.idleT = 0;
  }
  _rest() {
    for (const pt of this.parts) { if (pt.ON) { pt.ON.array.set(pt.on0); pt.ON.needsUpdate = true; } pt.P.array.set(pt.rest); pt.N.array.set(pt.restN); pt.A.array.fill(0); pt.X.fill(0); pt.V.fill(0); pt.M.fill(0); pt.Ag.fill(1e9); pt.P.needsUpdate = pt.N.needsUpdate = pt.A.needsUpdate = true; }
    for (const c of this.cells) { const r = c.pt.restN, i3 = c.i * 3; c.nx = r[i3]; c.ny = r[i3 + 1]; c.nz = r[i3 + 2]; c.m = 0; c.s *= 0.5; }
    for (const u of this.U.uSqU.value) u.w = 0;
    this.U.uWax.value.w = this.W.gloss;
    this.active = false; this.j = this.jv = 0; this.infl = 0; this.rate = 0; this.faceSquish = false;
    if (this.squisher) this.squisher.lockFace = false;
    if (this.audio && this.audio.quiet) this.audio.quiet();
  }
  dispose() {
    for (const pt of this.parts) pt.o.geometry.dispose();
    for (const m of this.mats.values()) m.dispose();
    if (this.audio && this.audio.quiet) this.audio.quiet();
  }
}

/* ---------- wax crackle layer (default) ----------
   Measured from uploads/Video Project 2.mp4 (wax-coated butter squishy, two-thumb pinch, 2.58–4.3 s): dry, sharp crackles,
   ~90 onsets/s while kneading, ~33 bursts/s of 1–6, each ringing ~4 ms, broadband 0.5–8 kHz with peaks near 2.8 / 4.5 / 7.3 kHz,
   a fine micro-crackle haze between them and a low-mid foam body (400–800 Hz) under the strokes. The synth below was tuned
   offline against that clip (spectrogram + onset/band statistics, shots/wax-compare4.png).
   Crackle grain = 1–3 micro-impulses through 3–4 damped modes + a snap + optional grit + a short foam-body ring.
   Bursts and timing come from the soft body's crack model; the haze and body are looped beds whose level follows strain. */
function wring(d, sr, i0, f, tau, g, ph) { if (i0 < 0 || i0 >= d.length) return; const n = Math.min(d.length - i0, Math.ceil(tau * sr * 7)), dec = Math.exp(-1 / (tau * sr)), w = (2 * Math.PI * f) / sr; let e = g; for (let k = 0; k < n; k++) { d[i0 + k] += e * Math.sin(w * k + ph); e *= dec; } }
function wsnap(d, sr, i0, a) { const n = Math.round(sr * 0.0006), dec = Math.exp(-1 / (sr * 0.00013)); let e = a, p = 0; for (let k = 0; k < n && i0 + k < d.length; k++) { const w = R() * 2 - 1; d[i0 + k] += e * (w - p); p = w; e *= dec; } }
function wgrit(d, sr, i0, a, fc, len) { const n = Math.round(sr * len), F = 2 * Math.sin((Math.PI * fc) / sr), dec = Math.exp(-1 / (sr * len * 0.35)); let lo = 0, bd = 0, e = a; for (let k = 0; k < n && i0 + k < d.length; k++) { const x = (R() * 2 - 1) * e, hi = x - lo - bd * 0.8; bd += F * hi; lo += F * bd; d[i0 + k] += bd; e *= dec; } }
function wfinish(d, sr, lpf, hpf = 90, tail = true) {
  let x1 = 0, y1 = 0, l1 = 0, l2 = 0, m = 1e-9; const a = Math.exp((-2 * Math.PI * hpf) / sr), b = 1 - Math.exp((-2 * Math.PI * lpf) / sr);
  for (let i = 0; i < d.length; i++) { const y = a * (y1 + d[i] - x1); x1 = d[i]; y1 = y; l1 += b * (y - l1); l2 += b * (l1 - l2); d[i] = l2; m = Math.max(m, Math.abs(l2)); }
  const F = Math.floor(sr * 0.003); for (let i = 0; i < d.length; i++) d[i] *= (tail ? Math.min(1, (d.length - 1 - i) / F) : 1) / m;
  return d;
}
function crackBuf(sr, W, b) {
  const d = new Float32Array(Math.ceil(sr * 0.03)), sh = Math.pow(2, (b - 0.5) * 1.8), modes = [];
  W.modes.forEach((f, k) => { if (R() < 0.8) modes.push([f * sh * Math.exp(gauss() * W.spread), W.mg[k]]); });
  modes.push([1200 * Math.pow(7, R()) * sh, 0.8]);
  const nI = 1 + (R() < 0.5 ? 1 : 0) + (R() < 0.22 ? 1 : 0); let t = Math.floor(sr * 0.0003);
  for (let q = 0; q < nI; q++) {
    const a = q ? rr(0.25, 0.8) : 1, sg = R() < 0.5 ? -1 : 1;
    for (const [f, g] of modes) wring(d, sr, t, f, clamp(W.tau * Math.sqrt(2800 / f) * rr(0.7, 1.35), 0.0004, 0.006), a * sg * g * rr(0.3, 1), R() * 6.283);
    wsnap(d, sr, t, a * W.snap * (0.5 + b)); t += Math.round(sr * rr(0.00008, 0.0012));
  }
  if (R() < 0.85) wring(d, sr, Math.floor(sr * rr(0.0002, 0.0008)), rr(W.body[0], W.body[1]), rr(0.0014, 0.0026), W.bodyG * rr(0.4, 1.1) * (1.25 - 0.7 * b) * (R() < 0.5 ? -1 : 1), R() * 6.283);
  if (R() < 0.6) wgrit(d, sr, Math.floor(sr * rr(0, 0.0008)), W.grit * rr(0.3, 1), rr(2200, 6000), rr(0.0012, 0.004));
  return wfinish(d, sr, W.lp * (0.8 + 0.4 * b));
}
function fizzBuf(sr, W, len) {
  const d = new Float32Array(Math.ceil(sr * len));
  for (let t = 0; t < len - 0.004; t += -Math.log(1 - R()) / 1400) { const f = W.fizzF * 0.36 * Math.pow(7, R()), A = Math.pow(10, -clamp(14 * Math.exp(0.45 * gauss()), 0, 40) / 20); wring(d, sr, Math.floor(t * sr), f, rr(0.00015, 0.0005), A * (R() < 0.5 ? -1 : 1), R() * 6.28); }
  let lo = 0, bd = 0; const F = 2 * Math.sin((Math.PI * W.fizzF) / sr);
  for (let i = 0; i < d.length; i++) { const x = (R() * 2 - 1) * 0.06, hi = x - lo - bd * 1.4; bd += F * hi; lo += F * bd; d[i] += bd; }
  return wfinish(d, sr, W.lp * 1.3, 900, false);
}
function bodyBuf(sr, W, len) {
  const d = new Float32Array(Math.ceil(sr * len)); let lo = 0, bd = 0; const F = 2 * Math.sin((Math.PI * W.bodyF) / sr);
  for (let i = 0; i < d.length; i++) { const x = R() * 2 - 1, hi = x - lo - bd * 1.4; bd += F * hi; lo += F * bd; d[i] = bd; }
  for (let t = 0; t < len - 0.01; t += -Math.log(1 - R()) / 120) wring(d, sr, Math.floor(t * sr), rr(W.body[0] * 0.85, W.body[1]), rr(0.002, 0.005), rr(2, 6) * (R() < 0.5 ? -1 : 1), R() * 6);
  return wfinish(d, sr, 2200, 110, false);
}
function tapBuf(sr, W) {
  const d = new Float32Array(Math.ceil(sr * 0.08));
  wring(d, sr, 0, rr(150, 230), rr(0.008, 0.014), 1, 0); wring(d, sr, 0, rr(900, 1500), rr(0.0012, 0.002), 0.35, R() * 6);
  wring(d, sr, Math.floor(sr * 0.0004), W.modes[0] * rr(0.8, 1.2), 0.0008, 0.18, R() * 6); wsnap(d, sr, 0, 0.15);
  return wfinish(d, sr, 4000, 50);
}
export const WAX_GEN = { crackBuf, fizzBuf, bodyBuf, tapBuf };
/* sound flavours on top of the wax engine: soft = muffled foam squeeze (crackle grains low-passed into soft pops, mostly body),
   light = a thin dull crust, crunch = the full wax crackle matched to the clip. keep = share of cracks that sound, n = max grains per burst,
   g = burst gain, fz / bd = haze / body bed gain. */
export const FLAV = {
  soft: { label: 'Soft squish', keep: 0.4, n: 2, g: 0.75, fz: 0.3, bd: 1.6, w: (W) => ({ ...W, lp: W.lp * 0.3, snap: W.snap * 0.15, grit: W.grit * 0.25, bodyG: W.bodyG * 2.2, tau: W.tau * 1.9, spread: W.spread * 1.3, modes: W.modes.map((f) => f * 0.5), fizzF: W.fizzF * 0.45 }) },
  light: { label: 'Light crunch', keep: 0.6, n: 4, g: 0.6, fz: 0.55, bd: 1.25, w: (W) => ({ ...W, lp: W.lp * 0.6, snap: W.snap * 0.5, grit: W.grit * 0.6, bodyG: W.bodyG * 1.4, tau: W.tau * 1.2, modes: W.modes.map((f) => f * 0.8), fizzF: W.fizzF * 0.75 }) },
  crunch: { label: 'Wax crunch', keep: 1, n: 7, g: 1, fz: 1, bd: 1, w: (W) => W },
};

/* ---------- slime ASMR layer (alternative) ----------
   Every squish sound is built from bubbles: damped sines whose pitch rises as the air pocket collapses (the classic
   liquid-sound model), so it reads wet and gooey instead of hissy. Clicks = small pockets popping, blorps = big ones,
   squelch = a burst of pockets forced out through the goo, peel = tacky strands letting go of the finger.
   Banks are rendered once per slime type, then played as randomised grains driven by the soft body. */
export const SLIME = {
  foam: { f: [800, 3200], visc: 1.5, rise: 0.25, rate: 46, blorp: [150, 330], sq: [1300, 560], pulse: [70, 24], tack: 0.55, gain: 1 },
  mochi: { f: [1000, 3800], visc: 1.15, rise: 0.35, rate: 60, blorp: [190, 420], sq: [1500, 650], pulse: [85, 28], tack: 1, gain: 0.95 },
  jelly: { f: [1000, 4500], visc: 0.75, rise: 0.5, rate: 70, blorp: [230, 540], sq: [1700, 760], pulse: [100, 34], tack: 0.35, gain: 0.9 },
  plush: { f: [1300, 5200], visc: 2.1, rise: 0.2, rate: 95, blorp: [140, 300], sq: [1100, 480], pulse: [60, 22], tack: 0.5, gain: 0.9 },
};
const poisson = (l) => { if (l <= 0) return 0; const L = Math.exp(-l); let k = 0, q = R(); while (q > L && k < 12) { k++; q *= R(); } return k; };
const tauOf = (f, visc) => Math.max(0.0009, 1 / (visc * (0.043 * f + 0.0014 * Math.pow(f, 1.5))));
function bub(d, sr, i0, f, tau, rise, a, click = 0, h2 = 0) {
  if (i0 < 0 || i0 >= d.length) return;
  const n = Math.min(d.length - i0, Math.ceil(tau * sr * 7)), dec = Math.exp(-1 / (tau * sr)), att = Math.max(2, Math.round(sr * 0.00035));
  const w0 = (2 * Math.PI * f) / sr, kr = rise / (tau * sr), km = 2.5 * tau * sr;
  let e = a, ph = 0;
  for (let k = 0; k < n; k++) {
    const s = Math.sin(ph);
    d[i0 + k] += e * (k < att ? k / att : 1) * (h2 ? s + h2 * Math.sin(2 * ph) : s);
    e *= dec; ph += w0 * Math.max(0.2, 1 + kr * (k < km ? k : km));
  }
  if (click) {
    const m = Math.min(d.length - i0, Math.round(sr * 0.0015)), cd = Math.exp(-1 / (sr * 0.00022));
    let ce = click * a, lp = 0;
    for (let k = 0; k < m; k++) { const w = R() * 2 - 1; lp += 0.45 * (w - lp); d[i0 + k] += ce * (w - lp); ce *= cd; }
  }
}
function norm(d, sr, pk = 0.9) {
  let x1 = 0, y1 = 0, m = 1e-9;
  for (let i = 0; i < d.length; i++) { const y = d[i] - x1 + 0.997 * y1; x1 = d[i]; y1 = y; d[i] = y; m = Math.max(m, Math.abs(y)); }
  const g = pk / m, F = Math.max(1, Math.floor(sr * 0.004));
  for (let i = 0; i < d.length; i++) d[i] *= g * Math.min(1, (d.length - 1 - i) / F);
  return d;
}
const buf = (sr, s) => new Float32Array(Math.ceil(sr * s));
function clickBuf(sr, S) {
  const d = buf(sr, 0.06), f = S.f[0] * Math.pow(S.f[1] / S.f[0], R());
  bub(d, sr, 0, f, tauOf(f, S.visc) * rr(0.8, 1.4), S.rise * rr(0.6, 1.4), 1, rr(0.1, 0.45));
  if (R() < 0.35) { const f2 = f * rr(0.7, 1.5); bub(d, sr, Math.floor(sr * rr(0.003, 0.012)), f2, tauOf(f2, S.visc), S.rise * rr(0.6, 1.4), rr(0.35, 0.8), rr(0, 0.3)); }
  return norm(d, sr);
}
function blorpBuf(sr, S) {
  const d = buf(sr, 0.24), f = rr(S.blorp[0], S.blorp[1]);
  bub(d, sr, Math.floor(sr * 0.001), f, rr(0.026, 0.045) / Math.sqrt(S.visc), rr(0.25, 0.45) * (0.7 + S.rise), 1, 0.2, 0.2);
  if (R() < 0.4) { const f2 = f * rr(1.7, 2.6); bub(d, sr, Math.floor(sr * rr(0.03, 0.07)), f2, tauOf(f2, S.visc) * 1.5, S.rise * 1.2, rr(0.3, 0.55), 0.2); }
  return norm(d, sr);
}
function squelchBuf(sr, S) {
  const D = 0.42, d = buf(sr, D), hold = rr(0.05, 0.11), dk = rr(0.07, 0.12), f0 = S.sq[0] * rr(0.85, 1.15), f1 = S.sq[1] * rr(0.85, 1.15);
  const env = (t) => (1 - Math.exp(-t / 0.006)) * (t < hold ? 1 : Math.exp(-(t - hold) / dk)), cont = (t) => f1 + (f0 - f1) * Math.exp(-t / 0.07);
  for (let t = rr(0, 0.004); t < D - 0.03; ) {
    const e = env(t); if (t > hold && e < 0.02) break;
    const f = cont(t) * rr(0.75, 1.3);
    bub(d, sr, Math.floor(t * sr), f, tauOf(f, S.visc) * rr(1, 1.8), S.rise * rr(0.5, 1.2), e * rr(0.45, 1), rr(0, 0.25));
    t += rr(0.55, 1.45) / (S.pulse[1] + (S.pulse[0] - S.pulse[1]) * Math.min(1, e * 1.2));
  }
  for (let t = 0; t < D - 0.02; t += -Math.log(1 - R()) / (S.rate * 5)) {
    const e = env(t); if (R() > e) continue;
    const f = S.f[0] * Math.pow((S.f[1] * 1.3) / S.f[0], R());
    bub(d, sr, Math.floor(t * sr), f, tauOf(f, S.visc), S.rise, e * rr(0.12, 0.4), rr(0.2, 0.6));
  }
  bub(d, sr, 0, rr(85, 120), 0.04, -0.2, 0.22);
  let lo = 0, bd = 0;
  for (let i = 0; i < d.length; i++) {
    const t = i / sr, fc = Math.min(0.9, 2 * Math.sin((Math.PI * cont(t) * 1.5) / sr)), x = (R() * 2 - 1) * env(t) * 0.08;
    lo += fc * bd; const hi = x - lo - 0.4 * bd; bd += fc * hi; d[i] += bd;
  }
  return norm(d, sr);
}
function peelBuf(sr, S) {
  const d = buf(sr, 0.34), L = rr(0.05, 0.1) * (0.6 + 0.6 * S.tack), N = Math.max(2, Math.round(rr(6, 11) * (0.35 + S.tack)));
  for (let i = 0; i < N; i++) {
    const u = i / N, t = L * (1 - (1 - u) * (1 - u)) + rr(0, 0.002), f = rr(2200, 6500);
    bub(d, sr, Math.floor(t * sr), f, tauOf(f, S.visc) * rr(0.8, 1.5), S.rise, (0.25 + 0.75 * u) * rr(0.45, 1) * 0.55, 0.5);
  }
  const tp = L + rr(0.004, 0.018), f = rr(650, 1300), fb = rr(S.blorp[0] * 1.2, S.blorp[1] * 1.3);
  bub(d, sr, Math.floor(tp * sr), f, tauOf(f, S.visc * 0.7) * 1.5, 0.6 + S.rise, 1, 0.3);
  bub(d, sr, Math.floor((tp + rr(0.01, 0.03)) * sr), fb, 0.022, 0.3 + S.rise * 0.4, 0.45, 0.1, 0.15);
  return norm(d, sr);
}
function tickBuf(sr, S) { const d = buf(sr, 0.02), f = rr(2000, 7000); bub(d, sr, 0, f, tauOf(f, S.visc) * rr(0.7, 1.3), S.rise, 1, rr(0.4, 0.9)); return norm(d, sr); }
export const SLIME_GEN = { clickBuf, blorpBuf, squelchBuf, peelBuf, tickBuf };

/* mode 'wax' (default) = crackle engine driven by the crack model; mode 'slime' = the bubble-grain slime engine */
export class SquishAudio {
  constructor(sfx) { this.sfx = sfx; this.banks = {}; this.wbanks = {}; this.bus = null; this.loops = null; this.type = 'foam'; this.mode = 'wax'; this.flav = 'soft'; sfx.slime = this; }
  _c() { const c = this.sfx.ensure(); return c && this.sfx.on ? c : null; }
  _live() { const c = this.sfx.ctx; return c && this.sfx.on && c.state === 'running' ? c : null; }
  warm(type) {
    this.type = SLIME[type] ? type : 'foam';
    const c = this.sfx.ctx; if (!c) return;
    (window.requestIdleCallback || setTimeout)(() => { if (!this.sfx.ctx) return; if (this.mode === 'wax') this._wbank(this.sfx.ctx, type); else this._bank(this.sfx.ctx, type); });
  }
  _bank(c, type) {
    const k = SLIME[type] ? type : 'foam'; if (this.banks[k]) return this.banks[k];
    const S = SLIME[k], sr = c.sampleRate, mk = (fn, n) => Array.from({ length: n }, () => { const d = fn(sr, S), b = c.createBuffer(1, d.length, sr); b.copyToChannel(d, 0); return b; });
    return (this.banks[k] = { S, click: mk(clickBuf, 28), blorp: mk(blorpBuf, 8), squelch: mk(squelchBuf, 6), peel: mk(peelBuf, 6), tick: mk(tickBuf, 12) });
  }
  _wbank(c, type) {
    const fl = FLAV[this.flav] ? this.flav : 'crunch', k = (WAX[type] ? type : 'foam') + ':' + fl; if (this.wbanks[k]) return this.wbanks[k];
    const W = FLAV[fl].w(WAX[k.split(':')[0]]), sr = c.sampleRate, mk = (d) => { const b = c.createBuffer(1, d.length, sr); b.copyToChannel(d, 0); return b; };
    return (this.wbanks[k] = { W, grains: Array.from({ length: 48 }, (_, i) => mk(crackBuf(sr, W, i / 47))), fizz: mk(fizzBuf(sr, W, 2)), body: mk(bodyBuf(sr, W, 2)), tap: Array.from({ length: 5 }, () => mk(tapBuf(sr, W))) });
  }
  _bus(c) {
    if (this.bus && this.bus.context === c) return this.bus;
    const k = c.createDynamicsCompressor(), g = c.createGain();
    k.threshold.value = -20; k.knee.value = 12; k.ratio.value = 3; k.attack.value = 0.003; k.release.value = 0.12; g.gain.value = 1.8;
    k.connect(g); g.connect(this.sfx.master); return (this.bus = k);
  }
  _play(c, b, t, g, r, pan = 0) {
    const s = c.createBufferSource(), gn = c.createGain(), bus = this._bus(c);
    s.buffer = b; s.playbackRate.value = r; gn.gain.value = g; s.connect(gn);
    if (c.createStereoPanner) { const p = c.createStereoPanner(); p.pan.value = clamp(pan, -1, 1); gn.connect(p); p.connect(bus); } else gn.connect(bus);
    s.start(Math.max(c.currentTime, t));
  }
  _clicks(c, B, t0, span, n, g, r, pan, spread) { for (let i = 0; i < n; i++) this._play(c, pick(B.click), t0 + span * R() ** 1.6, g * rr(0.4, 1), r * rr(0.85, 1.2), pan + rr(-spread, spread)); }
  _thump(c, f0, f1, dur, gain, delay = 0) {
    const t0 = c.currentTime + delay, o = c.createOscillator(), g = c.createGain();
    o.frequency.setValueAtTime(f0, t0); o.frequency.exponentialRampToValueAtTime(f1, t0 + dur);
    this.sfx._env(g, t0, 0.012, gain, dur); o.connect(g); g.connect(this._bus(c)); o.start(t0); o.stop(t0 + dur + 0.06);
  }

  /* ---- wax ---- */
  _loops(c, type) {
    if (this.loops && this.loops.c === c && this.loops.type === type && this.loops.fl === this.flav) return this.loops;
    if (this.loops) { const o = this.loops; try { o.fs.stop(); o.bs.stop(); } catch (_) {} }
    const B = this._wbank(c, type), bus = this._bus(c), fs = c.createBufferSource(), bs = c.createBufferSource(), fg = c.createGain(), bg = c.createGain(), pn = c.createStereoPanner ? c.createStereoPanner() : null;
    fs.buffer = B.fizz; bs.buffer = B.body; fs.loop = bs.loop = true; fg.gain.value = bg.gain.value = 0;
    fs.connect(fg); bs.connect(bg); if (pn) { fg.connect(pn); bg.connect(pn); pn.connect(bus); } else { fg.connect(bus); bg.connect(bus); }
    fs.start(c.currentTime, R() * 1.5); bs.start(c.currentTime, R() * 1.5);
    return (this.loops = { c, type, fl: this.flav, fs, bs, fg, bg, pn, f: 0, b: 0, p: 0 });
  }
  /* per frame: the micro-crackle haze follows strain (and how much coat is left), the foam body follows strain + pressure */
  waxFrame(type, drive, press, intact, pan, dt) {
    const c = this._live(); if (!c || this.mode !== 'wax') return;
    const L = this._loops(c, WAX[type] ? type : 'foam'), W = WAX[L.type], FV = FLAV[this.flav] || FLAV.crunch, t = c.currentTime;
    const tf = FV.fz * W.gain * 0.055 * drive * (0.25 + 0.75 * intact), tb = FV.bd * W.gain * 0.1 * Math.min(1, drive * 0.9 + press * 0.22) * (0.75 + 0.45 * (1 - intact));
    if (Math.abs(tf - L.f) > 2e-4) { L.fg.gain.setTargetAtTime(tf, t, 0.03); L.f = tf; }
    if (Math.abs(tb - L.b) > 2e-4) { L.bg.gain.setTargetAtTime(tb, t, 0.05); L.b = tb; }
    if (L.pn && Math.abs(pan - L.p) > 0.02) { L.pn.pan.setTargetAtTime(clamp(pan, -1, 1), t, 0.05); L.p = pan; }
  }
  quiet() { const L = this.loops; if (!L) return; const t = L.c.currentTime; L.fg.gain.setTargetAtTime(0, t, 0.04); L.bg.gain.setTargetAtTime(0, t, 0.06); L.f = L.b = 0; }
  /* one crack = a burst of 1–7 crackle grains a few ms apart; loudness spread matches the clip (median −25 dB under the peak) */
  crack(type, E, pan = 0, intact = 1, delay = 0) {
    const c = this._live(); if (!c || this.mode !== 'wax') return;
    const FV = FLAV[this.flav] || FLAV.crunch; if (R() > FV.keep) return;
    const B = this._wbank(c, type), G = FV.g * B.W.gain * (0.35 + 0.65 * intact);
    let n = 1; while (n < FV.n && R() < (0.22 + 0.1 * Math.min(E, 2)) * (0.6 + 0.4 * intact)) n++;
    let t = c.currentTime + 0.006 + delay + R() * 0.012;
    for (let k = 0; k < n; k++) {
      const att = clamp(21 * Math.exp(0.5 * gauss()) - 7 * (E - 1) - (k ? 0 : 5) + (1 - intact) * 8, 0, 55), A = 0.9 * Math.pow(10, -att / 20);
      if (A > 0.004) { const b = clamp(0.58 + 0.33 * gauss() + 0.08 * (E - 1) - (1 - intact) * 0.25, 0, 1); this._play(c, B.grains[clamp(Math.round(b * 47 + rr(-2, 2)), 0, 47)], t, A * G, rr(0.94, 1.06), pan + rr(-0.12, 0.12)); }
      t += 0.0003 - Math.log(1 - R()) * 0.0024;
    }
  }
  _wPress(type, kind, p, pan, amt) {
    const c = this._c(); if (!c) return;
    const B = this._wbank(c, type), G = B.W.gain * amt, r = Math.sqrt(p), t = c.currentTime + 0.003;
    if (kind === 'finger') { this._play(c, pick(B.tap), t, 0.3 * G, r * rr(0.95, 1.1), pan); return; }
    this._play(c, pick(B.tap), t, 0.42 * G, r * rr(0.88, 0.98), -0.35); this._play(c, pick(B.tap), t + rr(0.01, 0.035), 0.38 * G, r * rr(0.9, 1.02), 0.35);
    this._thump(c, 115 * p, 68 * p, 0.14, 0.06 * amt);
  }
  _wTicks(type, n, t0, span, g, pan, spread) {
    const c = this._live(); if (!c) return; const B = this._wbank(c, type);
    for (let i = 0; i < n; i++) { const u = R(); this._play(c, B.grains[(R() * 36) | 0], c.currentTime + t0 + Math.pow(u, 1.6) * span, g * B.W.gain * rr(0.3, 1) * (1 - 0.6 * u), rr(0.92, 1.06), pan + rr(-spread, spread)); }
  }

  /* ---- shared entry points (dispatch on mode) ---- */
  press(type, kind, p = 1, pan = 0, amt = 1) {
    if (this.mode === 'wax') return this._wPress(type, kind, p, pan, amt);
    const c = this._c(); if (!c) return;
    const B = this._bank(c, type), G = B.S.gain * amt, r = Math.sqrt(p), t = c.currentTime + 0.004;
    if (kind !== 'finger') {
      this._play(c, pick(B.squelch), t, 0.6 * G, r * rr(0.86, 0.96), -0.35);
      this._play(c, pick(B.squelch), t + rr(0.008, 0.03), 0.54 * G, r * rr(0.92, 1.04), 0.35);
      this._play(c, pick(B.blorp), t + rr(0.03, 0.08), 0.4 * G, r * rr(0.85, 1.05), rr(-0.2, 0.2));
      this._clicks(c, B, t + 0.02, 0.16, Math.round(rr(4, 8)), 0.16 * G, r, 0, 0.55);
      this._thump(c, 95 * p, 58 * p, 0.18, 0.1 * amt);
    } else {
      this._play(c, pick(B.squelch), t, 0.5 * G, r * rr(0.98, 1.12), pan);
      if (R() < 0.65) this._play(c, pick(B.blorp), t + rr(0.02, 0.06), 0.26 * G, r * rr(0.95, 1.15), pan);
      this._clicks(c, B, t + 0.008, 0.1, Math.round(rr(2, 5)), 0.13 * G, r, pan, 0.3);
    }
  }
  release(type, kind, p = 1, pan = 0, amt = 1) {
    if (this.mode === 'wax') return this._wTicks(type, (kind === 'finger' ? 1 : 2) + (R() < 0.5 ? 1 : 0), 0.01, 0.06, 0.12 * (0.5 + 0.5 * amt), pan, 0.3);
    const c = this._c(); if (!c) return;
    const B = this._bank(c, type), G = B.S.gain * (0.5 + 0.5 * amt), r = Math.sqrt(p), t = c.currentTime + 0.004;
    if (kind !== 'finger') { this._play(c, pick(B.peel), t, 0.42 * G, r * rr(0.9, 1.04), -0.3); this._play(c, pick(B.peel), t + rr(0.012, 0.04), 0.38 * G, r * rr(0.95, 1.1), 0.3); }
    else this._play(c, pick(B.peel), t, 0.4 * G, r * rr(0.95, 1.12), pan);
  }
  /* settling: cracked wax ticks as the foam rises back (wax) / a few soft plips as the goo settles (slime) */
  air(type, rise, pan = 0, amt = 1) {
    if (this.mode === 'wax') return this._wTicks(type, Math.round(rr(3, 6) * (0.5 + 0.5 * amt)), 0.12, Math.min(1.6, rise * 0.8), 0.08 * amt, pan, 0.4);
    const c = this._c(); if (!c) return;
    const B = this._bank(c, type), n = Math.round(rr(2, 4) * (type === 'jelly' ? 1.5 : 1));
    for (let i = 0; i < n; i++) this._play(c, pick(B.click), c.currentTime + 0.18 + R() * Math.min(1.4, rise * 0.75), 0.07 * B.S.gain * amt * rr(0.5, 1), rr(0.95, 1.3), pan + rr(-0.4, 0.4));
  }
  squish(type, p = 1, pan = 0, amt = 1, soft = false) {
    if (this.mode === 'wax') { if (!soft) { this.crack(type, 1.3 * amt, pan, 1); this._wPress(type, 'finger', p, pan, amt * 0.6); } return; }
    const c = this._c(); if (!c) return;
    const B = this._bank(c, type), G = B.S.gain * amt, r = Math.sqrt(p), t = c.currentTime + 0.004;
    this._play(c, pick(B.squelch), t, (soft ? 0.36 : 0.5) * G, r * (soft ? rr(1.05, 1.3) : rr(0.95, 1.1)), pan);
    if (!soft || R() < 0.3) this._play(c, pick(B.blorp), t + rr(0.01, 0.05), 0.24 * G, r * rr(1, 1.25), pan);
  }
  /* slime only: wet clicks at a rate that follows how fast the surface deforms, plus a few while just holding */
  knead(type, act, hold, pan, dt, p = 1) {
    if (this.mode === 'wax') return;
    const c = this._live(); if (!c || (act < 0.02 && hold < 0.05)) return;
    const B = this._bank(c, type), S = B.S, h = Math.min(dt, 0.05), t = c.currentTime + 0.01, r = Math.sqrt(p);
    const n = Math.min(6, poisson((S.rate * act + 5 * hold) * h));
    for (let i = 0; i < n; i++) this._play(c, pick(B.click), t + R() * h, S.gain * (0.06 + 0.17 * act) * rr(0.35, 1), r * rr(0.85, 1.2), pan + rr(-0.25, 0.25));
  }
  /* slime only: tacky strands crackle while stretching, the odd strand pops */
  stretch(type, speed, tension, pan, dt, p = 1) {
    if (this.mode === 'wax') return;
    const c = this._live(); if (!c || tension < 0.03) return;
    const B = this._bank(c, type), S = B.S, h = Math.min(dt, 0.05), t = c.currentTime + 0.01, r = Math.sqrt(p) * (0.9 + 0.45 * clamp(tension, 0, 1.2));
    const n = Math.min(5, poisson((10 + 140 * speed) * (0.5 + S.tack) * Math.min(1, tension * 3) * h));
    for (let i = 0; i < n; i++) this._play(c, pick(B.tick), t + R() * h, S.gain * (0.035 + 0.09 * speed) * rr(0.4, 1), r * rr(0.85, 1.25), pan + rr(-0.2, 0.2));
    if (R() < h * (1.5 + 6 * speed)) this._play(c, pick(B.click), t + R() * h, S.gain * 0.08 * (0.5 + speed), r * rr(0.9, 1.3), pan);
  }
  /* stretched coat let go: a big crunch and a smaller echo (wax) / strands peel, blorp, squelch, jelly bounces (slime) */
  snap(type, p = 1, pan = 0, a = 1, slipped = false) {
    if (this.mode === 'wax') { this.crack(type, 1.6 + a, pan, 1); this.crack(type, 0.9 + 0.6 * a, pan * 0.6, 1, 0.03); const c = this._c(); if (c) this._thump(c, 130 * p, 75 * p, 0.18, 0.05 * (0.5 + a)); return; }
    const c = this._c(); if (!c) return;
    const B = this._bank(c, type), G = B.S.gain * (0.45 + 0.55 * clamp(a, 0, 1)), r = Math.sqrt(p), t = c.currentTime + 0.004;
    this._play(c, pick(B.peel), t, 0.42 * G, r * (slipped ? rr(1.25, 1.4) : rr(1.08, 1.25)), pan);
    this._play(c, pick(B.blorp), t + rr(0.02, 0.04), 0.46 * G, r * rr(0.85, 1), pan);
    this._play(c, pick(B.squelch), t + rr(0.03, 0.06), 0.3 * G, r * rr(1.05, 1.2), pan * 0.5);
    if (type === 'jelly') for (let i = 0; i < 3; i++) this._play(c, pick(B.blorp), t + 0.1 + i * rr(0.08, 0.1), 0.2 * G * (1 - i * 0.28), r * rr(1.2, 1.5), pan);
    this._thump(c, 140 * p, 85 * p, 0.22, 0.05 * G, 0.02);
  }
}
