import { THREE, V3, mat, mesh, group, warpSphere, superF, lathe, mergeGeos, rng, STUD } from './kit.js';
import { buildAvatar, Animator, DASH_DIR } from './avatar.js';

const S = STUD;
const s = (v) => v * S;
const GC = new Map();
function rb(w, h, d, n = 8) { const k = [w, h, d, n].join(); if (!GC.has(k)) GC.set(k, warpSphere(superF(s(w / 2), s(h / 2), s(d / 2), n, n), 32, 20)); return GC.get(k); }
function bake(list) { return mergeGeos(list.map((m) => { m.updateMatrix(); return m.geometry.clone().applyMatrix4(m.matrix); })); }

export const ARENA = { L: 180, W: 130, name: 'Sweetshop Stadium' };
export const COVERS = [];

export function buildArena() {
  COVERS.length = 0;
  const A = group('SD_ARENA_SweetshopStadium');
  const play = group('PLAYABLE', A), deco = group('OUT_OF_BOUNDS_DRESSING', A);
  const M = {
    floor: mat('arena_floor_cream', 0xF4E6D3, 0.86), mint: mat('court_mint', 0xBDEAD6, 0.8), pink: mat('court_strawberry', 0xF8CAD4, 0.8), line: mat('court_line', 0xFFFDF8, 0.6),
    mintS: mat('team_mint', 0x5FD3AE, 0.62), pinkS: mat('team_strawberry', 0xF2687F, 0.62), cushion: mat('cushion_cream', 0xFFF3E2, 0.82),
    wafer: mat('wafer', 0xE5B06C, 0.78), waferD: mat('wafer_groove', 0xC98F4B, 0.8), cream: mat('wafer_cream', 0xFFF6E8, 0.7), sponge: mat('cake_sponge', 0xF2C98F, 0.82),
    mallow: mat('marshmallow', 0xFFF9F4, 0.8), lilac: mat('marshmallow_band', 0xD9C6F5, 0.7), plum: mat('scoreboard_plum', 0x3F3756, 0.6),
    glowW: mat('lamp_glow', 0xFFF6DC, 0.5, { emissive: 0xFFF1C8, emissiveIntensity: 1.2 }), red: mat('strawberry_red', 0xEE4A5C, 0.62), green: mat('frog_green', 0x6CC56A, 0.7),
  };
  const { L, W } = ARENA;
  mesh(new THREE.BoxGeometry(s(260), s(2), s(210)), M.floor, 'floor_base', A, [0, s(-1), 0]);
  mesh(new THREE.BoxGeometry(s(L / 2 - 3), s(0.06), s(W - 4)), M.mint, 'court_teamA_mint', play, [s(-L / 4 - 0.75), s(0.03), 0]);
  mesh(new THREE.BoxGeometry(s(L / 2 - 3), s(0.06), s(W - 4)), M.pink, 'court_teamB_strawberry', play, [s(L / 4 + 0.75), s(0.03), 0]);
  const ln = (w, d, x, z, m = M.line, n = 'court_line') => mesh(new THREE.BoxGeometry(s(w), s(0.04), s(d)), m, n, play, [s(x), s(0.08), s(z)]);
  ln(L, 1, 0, -W / 2 + 1.5); ln(L, 1, 0, W / 2 - 1.5); ln(1, W - 2, -L / 2 + 1.5, 0); ln(1, W - 2, L / 2 - 1.5, 0);
  ln(2.2, W - 2, 0, 0, M.line, 'center_line_visual');
  ln(0.8, W - 2, -2, 0, M.mintS, 'center_edge_mint'); ln(0.8, W - 2, 2, 0, M.pinkS, 'center_edge_strawberry');
  for (const sx of [-1, 1]) ln(0.8, W - 2, sx * 72, 0, M.line, 'spawn_zone_line');
  const ring = (r0, r1, x, z, m, n) => { const g = new THREE.RingGeometry(s(r0), s(r1), 64); g.rotateX(-Math.PI / 2); return mesh(g, m, n, play, [s(x), s(0.11), s(z)]); };
  ring(10, 11.2, 0, 0, M.line, 'center_circle');
  const spawns = { A: [], B: [] };
  for (const sx of [-1, 1]) for (const z of [-40, -20, 0, 20, 40]) {
    const m = sx < 0 ? M.mintS : M.pinkS;
    ring(1.9, 2.6, sx * 82, z, m, 'spawn_marker'); ring(0, 0.8, sx * 82, z, m, 'spawn_dot');
    (sx < 0 ? spawns.A : spawns.B).push(V3(sx * 82, 0, z));
  }
  const bnd = mesh(new THREE.PlaneGeometry(s(W - 2), s(9)), new THREE.MeshStandardMaterial({ name: 'boundary_jelly', color: 0xffffff, transparent: true, opacity: 0.13, roughness: 0.2, depthWrite: false, side: THREE.DoubleSide }), 'BOUNDARY_center_movement_assumed', play, [0, s(4.5), 0], [0, Math.PI / 2, 0]);
  bnd.castShadow = false; bnd.userData.noShadow = true;
  // perimeter cushions + gumdrop corners
  for (const sz of [-1, 1]) for (const sx of [-1, 1]) {
    mesh(rb(L / 2, 3.2, 3, 6), M.cushion, 'perimeter_cushion_long', play, [s(sx * L / 4), s(1.6), s(sz * (W / 2 + 1.5))]);
    mesh(rb(L / 2 - 1, 0.9, 3.3, 6), sx < 0 ? M.mintS : M.pinkS, 'perimeter_cap', play, [s(sx * L / 4), s(3.25), s(sz * (W / 2 + 1.5))]);
  }
  for (const sx of [-1, 1]) {
    mesh(rb(3, 3.2, W, 6), M.cushion, 'perimeter_cushion_end', play, [s(sx * (L / 2 + 1.5)), s(1.6), 0]);
    mesh(rb(3.3, 0.9, W - 1, 6), sx < 0 ? M.mintS : M.pinkS, 'perimeter_cap_end', play, [s(sx * (L / 2 + 1.5)), s(3.25), 0]);
  }
  const gum = lathe([[0, 0], [3, 0], [3.1, 1.5], [2.7, 4.2], [1.6, 5.6], [0, 6]].map(([r, y]) => [s(r), s(y)]), 40, 30);
  for (const sx of [-1, 1]) for (const sz of [-1, 0, 1]) mesh(gum, sz === 0 ? M.cushion : sx < 0 ? M.mintS : M.pinkS, 'gumdrop_column', play, [s(sx * (L / 2 + 1.5)), 0, s(sz * (W / 2 + 1.5))]);
  for (const sz of [-1, 1]) mesh(gum, M.cushion, 'gumdrop_center', play, [0, 0, s(sz * (W / 2 + 1.5))]);
  // cover — mirrored per side
  const wafer = (name, x, z, ry, len = 12) => {
    const g = group(name, play, [s(x), 0, s(z)], [0, ry, 0]);
    let y = 0;
    [[2.2, 'w'], [0.5, 'c'], [1.8, 'w'], [0.5, 'c'], [2.0, 'w']].forEach(([h, k]) => { mesh(k === 'w' ? rb(len, h, 3, 8) : rb(len - 0.4, h + 0.1, 2.6, 4), k === 'w' ? M.wafer : M.cream, k === 'w' ? 'wafer_layer' : 'wafer_cream_layer', g, [0, s(y + h / 2), 0]); y += h; });
    for (let i = -2; i <= 2; i++) for (const fz of [-1, 1]) mesh(rb(0.35, 6.4, 0.25, 4), M.waferD, 'wafer_groove', g, [s(i * 2.3), s(3.5), s(fz * 1.5)]);
    COVERS.push({ x, z, r: len / 2 + 1.5, h: 7, kind: 'Full cover · Wafer Wall 12×7×3', ry, w: len, d: 3 });
  };
  const cake = (name, x, z, icing) => {
    const g = group(name, play, [s(x), 0, s(z)]);
    let y = 0;
    [[6.5, 4], [5, 4], [3.6, 3.4]].forEach(([r, h], i) => {
      mesh(new THREE.CylinderGeometry(s(r), s(r), s(h), 48), M.sponge, 'cake_tier_' + i, g, [0, s(y + h / 2), 0]);
      mesh(new THREE.CylinderGeometry(s(r + 0.12), s(r + 0.12), s(0.7), 48), icing, 'cake_icing_band', g, [0, s(y + h - 0.35), 0]);
      mesh(new THREE.TorusGeometry(s(r), s(0.5), 10, 48), M.cream, 'cake_icing_rim', g, [0, s(y + h), 0], [Math.PI / 2, 0, 0]);
      const drips = [];
      for (let k = 0; k < 18; k++) { const a = (k / 18) * Math.PI * 2 + i; const m = new THREE.Mesh(new THREE.CapsuleGeometry(s(0.32), s(0.6 + (k % 3) * 0.5), 3, 8)); m.position.set(Math.cos(a) * s(r + 0.1), s(y + h - 0.9 - (k % 3) * 0.25), Math.sin(a) * s(r + 0.1)); drips.push(m); }
      mesh(bake(drips), M.cream, 'cake_drips', g);
      y += h;
    });
    const sb = mesh(lathe([[0, 0], [1.4, 0.4], [1.9, 1.6], [1.7, 2.6], [1.0, 3.2], [0, 3.4]].map(([r, yy]) => [s(r), s(yy)]), 32, 24), M.red, 'cake_topper_strawberry', g, [0, s(y - 0.2), 0]);
    sb.scale.y = -1; sb.position.y = s(y + 3.2);
    for (let k = 0; k < 5; k++) { const a = (k / 5) * Math.PI * 2; mesh(new THREE.SphereGeometry(s(1), 12, 8), M.green, 'cake_topper_leaf', g, [Math.cos(a) * s(0.9), s(y + 3.3), Math.sin(a) * s(0.9)], [0, -a, 0.3], [1.1, 0.25, 0.5]); }
    COVERS.push({ x, z, r: 8, h: 11.4, kind: 'Full cover + landmark · Layer Cake Ø13×11.4' });
  };
  const mallow = (name, x, z) => {
    const g = group(name, play, [s(x), 0, s(z)]);
    mesh(warpSphere(superF(s(3), s(1.75), s(3), 2, 6), 40, 24), M.mallow, 'marshmallow', g, [0, s(1.75), 0]);
    mesh(new THREE.TorusGeometry(s(3.02), s(0.35), 10, 48), M.lilac, 'marshmallow_band', g, [0, s(1.75), 0], [Math.PI / 2, 0, 0]);
    COVERS.push({ x, z, r: 4.5, h: 3.5, kind: 'Half cover · Marshmallow Ø6×3.5 (blocks lower body only)' });
  };
  for (const sx of [-1, 1]) {
    const T = sx < 0 ? 'A' : 'B';
    wafer('wafer_wall_' + T + '_back_S', sx * 64, -32, Math.PI / 2); wafer('wafer_wall_' + T + '_back_N', sx * 64, 32, Math.PI / 2);
    wafer('wafer_wall_' + T + '_fwd_S', sx * 30, -20, Math.PI / 2 + sx * 0.35); wafer('wafer_wall_' + T + '_fwd_N', sx * 30, 20, Math.PI / 2 - sx * 0.35);
    cake('cake_tower_' + T, sx * 46, 0, sx < 0 ? M.mintS : M.pinkS);
    mallow('marshmallow_' + T + '_S', sx * 42, -50); mallow('marshmallow_' + T + '_N', sx * 42, 50); mallow('marshmallow_' + T + '_C', sx * 16, 0);
  }
  // stands + crowd
  const r = rng(5), crowdCols = [0xF2687F, 0x5FD3AE, 0xFFD25E, 0xB892F0, 0x6EC6F5], bins = crowdCols.map(() => []);
  const gd = lathe([[0, 0], [1.2, 0], [1.25, 0.8], [0.95, 1.8], [0.5, 2.3], [0, 2.45]].map(([rr, y]) => [s(rr), s(y)]), 16, 10);
  for (const sz of [-1, 1]) for (let k = 0; k < 4; k++) {
    const z = sz * (W / 2 + 7 + k * 4.5), h = 2.5 + k * 2.6;
    mesh(rb(200, h, 4.5, 10), k % 2 ? M.cream : M.sponge, 'stand_tier', deco, [0, s(h / 2), s(z)]);
    for (let x = -96; x <= 96; x += 4.4) { if (r() < 0.18) continue; const m = new THREE.Mesh(gd); m.position.set(s(x + (r() - 0.5)), s(h), s(z)); m.scale.setScalar(0.85 + r() * 0.35); bins[(r() * crowdCols.length) | 0].push(m); }
  }
  bins.forEach((b, i) => mesh(bake(b), mat('crowd_gumdrop_' + i, crowdCols[i], 0.55), 'crowd_gumdrops_' + i, deco));
  // end landmarks: giant cupcake scoreboards
  for (const sx of [-1, 1]) {
    const g = group('cupcake_scoreboard_' + (sx < 0 ? 'A' : 'B'), deco, [s(sx * (L / 2 + 22)), 0, 0]);
    const liner = new THREE.CylinderGeometry(s(12), s(9.5), s(12), 56, 1); const p = liner.attributes.position;
    for (let i = 0; i < p.count; i++) { const x = p.getX(i), z = p.getZ(i), a = Math.atan2(z, x), k = 1 + 0.035 * Math.cos(28 * a); p.setXYZ(i, x * k, p.getY(i), z * k); }
    liner.computeVertexNormals();
    mesh(liner, sx < 0 ? M.mintS : M.pinkS, 'cupcake_liner', g, [0, s(6), 0]);
    mesh(warpSphere((d) => { const q = superF(s(13), s(8), s(13))(d); q.multiplyScalar(1 + 0.04 * Math.sin(3 * Math.atan2(d.z, d.x) + 12 * d.y)); q.y = Math.max(q.y, -s(0.5)); return q; }, 64, 40), M.cream, 'cupcake_frosting', g, [0, s(12), 0]);
    const scr = group('scoreboard', g, [s(-sx * 9), s(19), 0], [0, -sx * Math.PI / 2, 0]);
    mesh(rb(18, 8, 1.4, 6), M.plum, 'scoreboard_frame', scr);
    mesh(new THREE.BoxGeometry(s(15.5), s(5.8), s(0.2)), mat('scoreboard_screen', 0x261F38, 0.4, { emissive: 0x1C1530, emissiveIntensity: 1 }), 'scoreboard_screen', scr, [0, 0, s(0.75)]);
    for (const k of [-1, 1]) mesh(new THREE.BoxGeometry(s(6), s(3), s(0.1)), k < 0 ? mat('screen_mint', 0x5FD3AE, 0.4, { emissive: 0x2E9C7C, emissiveIntensity: 0.9 }) : mat('screen_strawberry', 0xF2687F, 0.4, { emissive: 0xB83A52, emissiveIntensity: 0.9 }), 'scoreboard_team_panel', scr, [s(k * 4), 0, s(0.88)]);
    mesh(new THREE.SphereGeometry(s(2), 20, 14), M.red, 'cupcake_cherry', g, [0, s(20.5) + s(5), 0]);
  }
  for (const sz of [-1, 1]) {
    const g = group('lollipop_landmark_' + (sz < 0 ? 'S' : 'N'), deco, [0, 0, s(sz * (W / 2 + 26))]);
    mesh(new THREE.CylinderGeometry(s(0.7), s(0.7), s(26), 16), M.cushion, 'lollipop_stick', g, [0, s(13), 0]);
    const disk = group('lollipop_candy', g, [0, s(26), 0], [Math.PI / 2, 0, 0]);
    mesh(new THREE.CylinderGeometry(s(8), s(8), s(2), 64), M.cream, 'lollipop_disk', disk);
    [7.2, 5.6, 4.0, 2.4].forEach((rr, i) => { for (const f of [-1, 1]) mesh(new THREE.TorusGeometry(s(rr), s(0.55), 10, 64), i % 2 ? M.mintS : M.pinkS, 'lollipop_swirl', disk, [0, s(f * 0.95), 0], [Math.PI / 2, 0, 0]); });
  }
  const cane = [mat('cane_white', 0xFFF8F2, 0.6), mat('cane_red', 0xEE4A5C, 0.6)];
  for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
    const g = group('light_pole', deco, [s(sx * 104), 0, s(sz * 88)]);
    for (let k = 0; k < 13; k++) mesh(new THREE.CylinderGeometry(s(0.8), s(0.8), s(2), 16), cane[k % 2], 'pole_segment', g, [0, s(1 + k * 2), 0]);
    const head = group('lamp', g, [0, s(27), 0], [0, Math.atan2(-sx, -sz), 0]);
    mesh(rb(7, 3, 2.4, 5), M.plum, 'lamp_housing', head);
    mesh(new THREE.BoxGeometry(s(6), s(2.2), s(0.3)), M.glowW, 'lamp_face', head, [0, 0, s(1.15)]);
  }
  // collision proxies + annotations (not exported with art)
  const proxies = group('COLLISION_PROXIES');
  const pm = new THREE.MeshBasicMaterial({ color: 0x3A7BFF, transparent: true, opacity: 0.22, depthWrite: false });
  const pm2 = new THREE.MeshBasicMaterial({ color: 0xFFB020, transparent: true, opacity: 0.25, depthWrite: false });
  for (const c of COVERS) {
    const m = c.w ? new THREE.Mesh(new THREE.BoxGeometry(s(c.w), s(c.h), s(c.d)), pm) : new THREE.Mesh(new THREE.CylinderGeometry(s(c.r - (c.h > 5 ? 1.5 : 1.5)), s(c.r - 1.5), s(c.h), 24), c.h > 5 ? pm : pm2);
    m.position.set(s(c.x), s(c.h / 2), s(c.z)); if (c.ry) m.rotation.y = c.ry; m.name = 'COLL_' + c.kind; proxies.add(m);
  }
  const annot = group('ANNOTATIONS');
  const dimM = new THREE.MeshBasicMaterial({ color: 0x2B2233 });
  const dimLine = (x0, z0, x1, z1) => { const len = Math.hypot(x1 - x0, z1 - z0); const m = mesh(new THREE.BoxGeometry(s(len), s(0.15), s(0.4)), dimM, 'dim', annot, [s((x0 + x1) / 2), s(0.3), s((z0 + z1) / 2)], [0, -Math.atan2(z1 - z0, x1 - x0), 0]); for (const [x, z] of [[x0, z0], [x1, z1]]) mesh(new THREE.BoxGeometry(s(0.4), s(0.15), s(3)), dimM, 'dim_tick', annot, [s(x), s(0.3), s(z)], [0, -Math.atan2(z1 - z0, x1 - x0), 0]); return m; };
  dimLine(-L / 2, -W / 2 - 4, L / 2, -W / 2 - 4); dimLine(L / 2 + 4, -W / 2, L / 2 + 4, W / 2);
  dimLine(-82, 6, -64 + 3, 6);
  const labels = [
    { t: `${L} studs · ${(L * S).toFixed(1)} m playable length`, p: V3(0, s(1), s(-W / 2 - 8)) },
    { t: `${W} studs · ${(W * S).toFixed(1)} m width`, p: V3(s(L / 2 + 9), s(1), 0) },
    { t: 'Spawn → first cover 15.5 st ≈ 0.97 s @ 16 st/s', p: V3(s(-73), s(1), s(10)) },
    { t: 'Center line: visual marking + assumed movement boundary (split-court)', p: V3(0, s(10), s(30)) },
    { t: 'Layer Cake (full cover, landmark)', p: V3(s(-46), s(14), 0) },
    { t: 'Wafer Wall · full cover 7 st', p: V3(s(-30), s(8.5), s(20)) },
    { t: 'Marshmallow · half cover 3.5 st', p: V3(s(-42), s(5), s(50)) },
    { t: 'Team A spawn ×5 (mint · ●)', p: V3(s(-82), s(2), s(-46)) },
    { t: 'Team B spawn ×5 (strawberry · ◆)', p: V3(s(82), s(2), s(-46)) },
  ];
  return { root: A, proxies, annot, labels, spawns };
}

/* ---------- 10-player density simulation ---------- */
export class ArenaSim {
  constructor({ scene, fx, sfx, protoToy, toyIds, catalog, bounds }) {
    this.hx = bounds?.hx ?? 87; this.hz = bounds?.hz ?? 62; this.y0 = bounds?.y0 ?? 0;
    this.scene = scene; this.fx = fx; this.sfx = sfx; this.protoToy = protoToy; this.cat = catalog;
    this.g = group('__sim', scene); this.players = []; this.proj = []; this.t = 0; this.ultT = 6; this.on = true; this.hits = 0; this.throws = 0; this.rand = rng(99);
    for (const team of ['A', 'B']) for (let i = 0; i < 5; i++) {
      const av = buildAvatar({ team: team === 'A' ? 'mint' : 'strawberry', S, name: 'Player_' + team + (i + 1) });
      const an = new Animator(av);
      const toyId = toyIds[(i * 3 + (team === 'B' ? 7 : 0)) % toyIds.length];
      const hand = protoToy(toyId).root.clone(true); hand.scale.setScalar(0.8); av.grip.add(hand);
      const sx = team === 'A' ? -1 : 1;
      const p = { team, sx, av, an, toyId, hand, pos: V3(sx * 82, 0, -40 + i * 20), vel: V3(), target: V3(), yaw: sx < 0 ? Math.PI / 2 : -Math.PI / 2, nextThrow: 1 + this.rand() * 2.5, nextDash: 2 + this.rand() * 4, nextJump: 3 + this.rand() * 5, dashT: -1, dashDir: V3(), flash: 0 };
      this.pick(p);
      av.root.position.set(s(p.pos.x), this.y0, s(p.pos.z)); av.root.rotation.y = p.yaw;
      an.onEvent = (n, d) => this.onEv(p, n, d);
      this.g.add(av.root); this.players.push(p);
    }
  }
  pick(p) {
    for (let k = 0; k < 20; k++) {
      const x = p.sx * (8 + this.rand() * (this.hx - 11)), z = -(this.hz - 4) + this.rand() * 2 * (this.hz - 4);
      if (COVERS.every((c) => Math.hypot(c.x - x, c.z - z) > c.r + 2.5)) { p.target.set(x, 0, z); return; }
    }
    p.target.set(p.sx * 70, 0, 0);
  }
  onEv(p, n, d) {
    const fx = this.fx, w = this.wpos(p);
    if (n === 'pushoff' || n === 'plant') { fx.burst('sphere', w.clone().setY(s(0.3)), n === 'pushoff' ? 6 : 4, { color: 0xFFF6EA, colors: [0xFFF6EA, 0xF4E6D3], speed: 1.6, size: s(0.5), life: 0.45, gravity: 0.5, drag: 4, flat: true }); }
    if (n === 'land') fx.burst('sphere', w.clone().setY(s(0.2)), d ? 10 : 5, { colors: [0xFFF6EA, 0xF4E6D3], speed: 2, size: s(0.45), life: 0.45, gravity: 0.3, drag: 5, flat: true });
    if (n === 'release') this.launch(p);
  }
  wpos(p) { return V3(s(p.pos.x), s(p.an.airY()) + this.y0, s(p.pos.z)); }
  launch(p) {
    const foes = this.players.filter((q) => q.team !== p.team);
    const foe = foes[(this.rand() * foes.length) | 0];
    const from = V3(); p.hand.getWorldPosition(from);
    const lead = foe.vel.clone().multiplyScalar(0.25);
    const willHit = this.rand() < 0.38;
    const to = V3(s(foe.pos.x + lead.x + (willHit ? 0 : (this.rand() - 0.5) * 14)), s(willHit ? 3.6 : 0.2) + this.y0, s(foe.pos.z + lead.z + (willHit ? 0 : (this.rand() - 0.5) * 14)));
    const meta = this.cat.find((c) => c.id === p.toyId);
    const obj = this.protoToy(p.toyId).root.clone(true); obj.scale.setScalar(0.8); this.g.add(obj);
    const dist = from.distanceTo(to), dur = dist / s(70);
    const rib = this.fx.ribbon({ a: meta.trail.a, b: meta.trail.b, width: s(meta.trail.w / S) * 0.9, life: meta.trail.life, opacity: 0.8 });
    this.proj.push({ obj, from, to, t: 0, dur, rib, meta, foe: willHit ? foe : null, spin: V3(this.rand(), this.rand(), this.rand()).normalize() });
    p.hand.visible = false; setTimeout(() => (p.hand.visible = true), 650);
    this.throws++; if (this.proj.length < 6) this.sfx.whoosh(0.35);
  }
  ultimate() {
    const caster = this.players[(this.rand() * 10) | 0];
    const tx = -caster.sx * (30 + this.rand() * 30), tz = -30 + this.rand() * 60;
    const at = V3(s(tx), s(0.15) + this.y0, s(tz));
    this.fx.ring(at, { color: 0xFF9A4D, r0: s(8), r1: s(8), life: 0.9, pulse: 18, opacity: 0.75, inner: 0.9 });
    this.fx.ring(at, { color: 0xFFE7A0, r0: s(0.5), r1: s(8), life: 0.9, opacity: 0.35, inner: 0.0 });
    this.pendingUlt = { t: 0.9, caster, at };
    this.sfx.roar();
  }
  update(dt, cam, now, dragonHead) {
    if (!this.on) return;
    this.t += dt;
    for (const p of this.players) {
      const an = p.an;
      if (p.dashT >= 0) {
        p.dashT += dt; const T = 0.22, k = Math.min(1, p.dashT / T);
        const prev = 1 - Math.pow(1 - Math.min(1, (p.dashT - dt) / T), 3), cur = 1 - Math.pow(1 - k, 3);
        p.pos.addScaledVector(p.dashDir, 14 * (cur - prev));
        if (p.rib) p.rib.push(V3(s(p.pos.x), s(3.2), s(p.pos.z)), now);
        if (k >= 1) { p.dashT = -1; p.rib && p.rib.stop(); p.rib = null; }
      } else {
        const d = p.target.clone().sub(p.pos); d.y = 0;
        if (d.length() < 2) this.pick(p);
        d.normalize();
        for (const c of COVERS) { const o = V3(p.pos.x - c.x, 0, p.pos.z - c.z), dl = o.length(); if (dl < c.r + 2) d.addScaledVector(o.normalize(), (c.r + 2 - dl) * 0.6); }
        d.normalize();
        p.vel.lerp(d.multiplyScalar(16), Math.min(1, dt * 6));
        p.pos.addScaledVector(p.vel, dt);
      }
      p.pos.x = p.sx < 0 ? Math.min(-3, Math.max(-this.hx, p.pos.x)) : Math.max(3, Math.min(this.hx, p.pos.x));
      p.pos.z = Math.max(-this.hz, Math.min(this.hz, p.pos.z));
      an.speed = p.dashT >= 0 ? 0 : p.vel.length();
      p.nextThrow -= dt; p.nextDash -= dt; p.nextJump -= dt;
      if (p.nextThrow <= 0 && an.throwT < 0) { an.startThrow(); p.nextThrow = 1.8 + this.rand() * 2.4; }
      if (p.nextDash <= 0 && p.dashT < 0 && !an.airborne) {
        const side = this.rand() < 0.5 ? 'L' : 'R'; an.startDash(side); p.dashT = 0;
        const f = V3(Math.sin(p.yaw), 0, Math.cos(p.yaw)), l = V3(f.z, 0, -f.x);
        p.dashDir.copy(side === 'L' ? l : l.negate());
        p.rib = this.fx.ribbon({ a: p.team === 'A' ? 0xBDEAD6 : 0xF8CAD4, b: 0xffffff, width: s(1.2), life: 0.18, opacity: 0.45 });
        p.nextDash = 3 + this.rand() * 4;
      }
      if (p.nextJump <= 0 && !an.airborne && p.dashT < 0) { an.startJump(); p.nextJump = 3.5 + this.rand() * 5; }
      const tgtYaw = (p.sx < 0 ? Math.PI / 2 : -Math.PI / 2) + Math.sin(this.t * 0.7 + p.pos.z) * 0.35;
      p.yaw += (tgtYaw - p.yaw) * Math.min(1, dt * 5);
      an.update(dt);
      p.av.root.position.set(s(p.pos.x), s(an.airY()) + this.y0, s(p.pos.z)); p.av.root.rotation.y = p.yaw;
      if (p.flash > 0) { p.flash -= dt; const k = 1 + Math.sin(p.flash * 40) * 0.06 * (p.flash / 0.4); p.av.root.scale.setScalar(k); } else p.av.root.scale.setScalar(1);
    }
    for (let i = this.proj.length - 1; i >= 0; i--) {
      const q = this.proj[i]; q.t += dt; const k = Math.min(1, q.t / q.dur);
      const pos = q.from.clone().lerp(q.to, k); pos.y += Math.sin(Math.PI * k) * s(2.5);
      q.obj.position.copy(pos); q.obj.rotateOnAxis(q.spin, dt * 12);
      q.rib.push(pos, now);
      if (this.rand() < 0.5) this.fx.emit(q.meta.trail.shape, { pos, vel: V3((this.rand() - 0.5) * 0.6, this.rand() * 0.5, (this.rand() - 0.5) * 0.6), color: q.meta.trail.pcols[(this.rand() * q.meta.trail.pcols.length) | 0], size: s(0.22), life: 0.4, gravity: -2 });
      if (k >= 1) {
        q.rib.stop(); this.g.remove(q.obj);
        const tr = q.meta.trail;
        if (q.foe) {
          this.hits++; q.foe.flash = 0.4;
          this.fx.burst('spark', pos, 8, { colors: [0xFFFFFF, 0xFFE27A], speed: 3, size: s(0.35), life: 0.45, gravity: -2 });
          this.fx.burst(tr.shape, pos, 10, { colors: tr.pcols, speed: 2.6, size: s(0.3), life: 0.6, floor: s(0.1) });
          this.fx.ring(pos, { color: q.foe.team === 'A' ? 0x5FD3AE : 0xF2687F, r0: s(0.5), r1: s(4), life: 0.3, normal: V3(0, 1, 0), opacity: 0.9 });
          if (this.hits % 2 === 0) this.sfx.splat(1.2);
        } else {
          this.fx.splat(pos.clone().setY(s(0.12) + this.y0), V3(0, 1, 0), tr.b, s(1.4), 0.9);
          this.fx.burst(tr.shape, pos, 6, { colors: tr.pcols, speed: 2, size: s(0.28), life: 0.5, normal: V3(0, 1, 0), floor: s(0.1) });
        }
        this.proj.splice(i, 1);
      }
    }
    this.ultT -= dt;
    if (this.ultT <= 0) { this.ultimate(); this.ultT = 12 + this.rand() * 6; }
    if (this.pendingUlt) {
      const u = this.pendingUlt; u.t -= dt;
      if (u.t <= 0 && !u.head) {
        const h = dragonHead(); h.scale.setScalar(5); this.g.add(h);
        const from = this.wpos(u.caster).setY(s(5));
        u.head = { obj: h, from, t: 0, dur: from.distanceTo(u.at) / s(110), rib: this.fx.ribbon({ a: 0xFFD25E, b: 0xB892F0, width: s(4), life: 0.3, opacity: 0.85 }) };
        this.sfx.whoosh(0.4);
      }
      if (u.head) {
        const H = u.head; H.t += dt; const k = Math.min(1, H.t / H.dur);
        const pos = H.from.clone().lerp(u.at, k); pos.y += Math.sin(Math.PI * k) * s(4) + s(1.5) * (1 - k);
        H.obj.position.copy(pos); H.obj.lookAt(u.at.x, pos.y - s(1), u.at.z);
        H.rib.push(pos, now);
        for (let e = 0; e < 3; e++) this.fx.emit('glowdrop', { pos: pos.clone().add(V3((this.rand() - 0.5) * 0.5, (this.rand() - 0.5) * 0.5, (this.rand() - 0.5) * 0.5)), vel: V3((this.rand() - 0.5) * 2, this.rand() * 1.5, (this.rand() - 0.5) * 2), color: [0xFF9A4D, 0xFFD25E, 0xFF6F7D][e], size: s(0.5), life: 0.4, gravity: 2 });
        if (k >= 1) {
          this.g.remove(H.obj); H.rib.stop();
          const fx = this.fx;
          fx.ring(u.at, { color: 0xFFD25E, r0: s(1), r1: s(9), life: 0.35, opacity: 0.95 });
          fx.ring(u.at.clone().setY(s(0.2)), { color: 0xB892F0, r0: s(1), r1: s(12), life: 0.5, opacity: 0.6 });
          fx.burst('glowdrop', u.at.clone().setY(s(1)), 40, { colors: [0xFF9A4D, 0xFFD25E, 0xFF6F7D], speed: 9, size: s(0.6), life: 0.6, normal: V3(0, 1, 0), gravity: -6 });
          fx.burst('sphere', u.at.clone().setY(s(1)), 16, { colors: [0xFFF1E3, 0xE9DDF7], speed: 4, size: s(1.4), life: 0.8, gravity: 1, drag: 3, flat: true });
          fx.burst('spark', u.at.clone().setY(s(2)), 14, { colors: [0xFFFFFF, 0xFFE7A0], speed: 6, size: s(0.5), life: 0.5 });
          fx.flash(u.at.clone().setY(s(4)), 0xFFB060, 40, 0.35); fx.kick(0.12);
          this.sfx.boom();
          this.pendingUlt = null;
        }
      }
    }
  }
  dispose() { this.scene.remove(this.g); }
}
