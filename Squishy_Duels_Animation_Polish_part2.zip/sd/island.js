// Squish Island: the base lobby from docs/superpowers/specs/2026-10-11-lobby-bases-capsules-design.md; capsule numbers from
// 2026-10-12-big-number-progression-design.md (all numbers [P]).
import { THREE, STUD, V3, mat, mesh, group, rng } from './kit.js';
import { s, C, SPH, put, grp, plate, toyAt, lockIcon, canvasMat } from './lobby.js';
import { byId } from './toys.js';
import { buildAvatar, Animator } from './avatar.js';

const TAU = Math.PI * 2, D2R = Math.PI / 180;
const polar = (deg, r) => [r * Math.sin(deg * D2R), -r * Math.cos(deg * D2R)];
const face = (x, z) => Math.atan2(-x, -z);
const hexMix = (a, b, k) => new THREE.Color(a).lerp(new THREE.Color(b), k).getHex();
const css = (h) => '#' + h.toString(16).padStart(6, '0');
const easeOut = (t) => 1 - (1 - t) * (1 - t);

export const CAPSULE = {
  tiers: ['Foam', 'Jelly', 'Marshmallow', 'Gummy', 'Taffy', 'Caramel', 'Bubblegum', 'Rainbow', 'Crystal', 'Royal'],
  secs: [4.0, 3.5, 3.1, 2.7, 2.4, 2.1, 1.9, 1.6, 1.4, 1.3],
  tier: (L) => Math.floor((L - 1) / 10),
  interval: (L) => CAPSULE.secs[CAPSULE.tier(L)],
  power: (L) => Math.round(10 * Math.pow(1.13, L - 1) * Math.pow(2, CAPSULE.tier(L))),
  squishy: { Common: 1, Uncommon: 4, Epic: 16, Exclusive: 64 },
  slots: [0, 2500, 80000, 1500000],
};
const lookOf = (L) => ({ k: CAPSULE.tiers[CAPSULE.tier(L)] });
const sqPow = (id) => CAPSULE.squishy[byId(id).rarity] ?? 1;
const big = (n) => {
  for (const [v, k] of [[1e15, 'Qa'], [1e12, 'T'], [1e9, 'B'], [1e6, 'M'], [1e3, 'K']]) if (n >= v) { const x = n / v, d = x < 10 ? 2 : x < 100 ? 1 : 0; let t = (Math.floor(x * 10 ** d) / 10 ** d).toFixed(d); if (d) t = t.replace(/0+$/, '').replace(/\.$/, ''); return t + k; }
  return String(Math.round(n));
};

/* studs: one tile = 1 stud, uv in studs; side faces sample the flat corner */
function canvasTex(px, draw, rep) {
  const c = document.createElement('canvas'); c.width = c.height = px; draw(c.getContext('2d'), px);
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; t.repeat.set(rep, rep); return t;
}
function studCell(g, x, y, p, tone) {
  const c = (v) => `rgb(${v},${v},${v})`, m = x + p / 2, n = y + p / 2, r = p * 0.3;
  g.fillStyle = c(tone); g.fillRect(x, y, p, p);
  g.fillStyle = 'rgba(0,0,0,.15)'; g.beginPath(); g.arc(m + p * 0.05, n + p * 0.07, r, 0, TAU); g.fill();
  g.fillStyle = c(Math.min(255, tone + 9)); g.beginPath(); g.arc(m, n, r, 0, TAU); g.fill();
  g.strokeStyle = 'rgba(255,255,255,.65)'; g.lineWidth = p * 0.05; g.beginPath(); g.arc(m, n, r * 0.76, Math.PI * 0.95, Math.PI * 1.6); g.stroke();
}
let TEX = null;
const textures = () => TEX || (TEX = {
  stud: canvasTex(64, (g, p) => studCell(g, 0, 0, p, 242), 1),
  check: canvasTex(512, (g) => { for (let i = 0; i < 8; i++) for (let j = 0; j < 8; j++) studCell(g, i * 64, j * 64, 64, ((i >> 2) + (j >> 2)) % 2 ? 220 : 242); }, 1 / 8),
  tile: canvasTex(256, (g) => {
    for (let i = 0; i < 2; i++) for (let j = 0; j < 2; j++) { g.fillStyle = (i + j) % 2 ? '#E6EAF0' : '#FFFFFF'; g.fillRect(i * 128, j * 128, 128, 128); }
    g.strokeStyle = 'rgba(40,50,70,.14)'; g.lineWidth = 3; for (const k of [0, 128, 256]) { g.beginPath(); g.moveTo(k, 0); g.lineTo(k, 256); g.moveTo(0, k); g.lineTo(256, k); g.stroke(); }
  }, 1 / 8),
});
const GC = new Map();
function BR(w, h, d) {
  const k = [w, h, d].join(); if (GC.has(k)) return GC.get(k);
  const g = new THREE.BoxGeometry(s(w), s(h), s(d)), uv = g.attributes.uv;
  for (let i = 0; i < 24; i++) { if (i >= 8 && i < 12) uv.setXY(i, uv.getX(i) * w, uv.getY(i) * d); else uv.setXY(i, 0.04, 0.04); }
  GC.set(k, g); return g;
}
function CT(r0, r1, h, n = 48) {
  const k = ['ct', r0, r1, h, n].join(); if (GC.has(k)) return GC.get(k);
  const g = new THREE.CylinderGeometry(s(r0), s(r1), s(h), n), P = g.attributes.position, N = g.attributes.normal, uv = g.attributes.uv;
  for (let i = 0; i < P.count; i++) { if (N.getY(i) > 0.5) uv.setXY(i, P.getX(i) / STUD, P.getZ(i) / STUD); else uv.setXY(i, 0.04, 0.04); }
  GC.set(k, g); return g;
}
function mergeUV(list) {
  const parts = list.map((g) => (g.index ? g.toNonIndexed() : g)); let n = 0; parts.forEach((g) => (n += g.attributes.position.count));
  const P = new Float32Array(n * 3), N = new Float32Array(n * 3), U = new Float32Array(n * 2); let o = 0;
  for (const g of parts) { const c = g.attributes.position.count; P.set(g.attributes.position.array, o * 3); N.set(g.attributes.normal.array, o * 3); if (g.attributes.uv) U.set(g.attributes.uv.array, o * 2); else U.fill(0.04, o * 2, (o + c) * 2); o += c; }
  const out = new THREE.BufferGeometry(); out.setAttribute('position', new THREE.BufferAttribute(P, 3)); out.setAttribute('normal', new THREE.BufferAttribute(N, 3)); out.setAttribute('uv', new THREE.BufferAttribute(U, 2)); out.computeBoundingSphere(); return out;
}
/* every static part is a Roblox-style part; they are merged per material after the build */
function collector() {
  const K = new Map(); let n = 0;
  const add = (mt, geo, parent, x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0) => { const m = new THREE.Mesh(geo); m.position.set(s(x), s(y), s(z)); m.rotation.set(rx, ry, rz); parent.add(m); if (!K.has(mt)) K.set(mt, []); K.get(mt).push(m); n++; return m; };
  add.count = () => n;
  add.bake = (parent, noCast, prefix) => { for (const [mt, list] of K) { const out = mesh(mergeUV(list.map((m) => m.geometry.clone().applyMatrix4(m.matrixWorld))), mt, prefix + mt.name.replace(/^isl_/, ''), parent, [0, 0, 0]); out.receiveShadow = true; out.castShadow = !noCast.has(mt); } };
  return add;
}
function palette() {
  const T = textures(), sm = (n, hex, map = T.stud, r = 0.7) => mat('isl_' + n, hex, r, { map });
  return {
    grass: sm('grass', 0x5CCB4E, T.check, 0.85), sand: sm('sand', 0xF5DC9B, T.check, 0.9), sea: mat('isl_sea', 0x2BA7E3, 0.3), shallow: mat('isl_shallow', 0x6FD3F5, 0.35),
    tile: mat('isl_plaza_tile', 0xFFFFFF, 0.6, { map: T.tile }), curb: sm('curb', 0xFFFFFF), path: sm('path', 0xEFE1C6, T.stud, 0.85), stone: sm('stone', 0xC9CFD8), rock: mat('isl_rock', 0x9AA3AE, 0.9),
    wood: sm('wood', 0xA8673A, T.stud, 0.8), woodD: mat('isl_wood_dark', 0x7A4A2A, 0.85), white: sm('white', 0xFFFFFF, T.stud, 0.55), dark: mat('isl_ink', 0x2B2233, 0.5), cream: sm('foam_mat', 0xFFF3E2, T.stud, 0.85),
    red: sm('red', 0xE8343F), orange: sm('orange', 0xFF8A1F), yellow: sm('yellow', 0xFFC51F), lime: sm('lime', 0x9BE22B), skyB: sm('skyblue', 0x38B6FF), blue: sm('blue', 0x2E7BF0), purple: sm('purple', 0x8E4FE0), pink: sm('pink', 0xFF5FA2),
    mint: mat('isl_team_mint', 0x5FD3AE, 0.6), berry: mat('isl_team_strawberry', 0xF2687F, 0.6), gold: mat('isl_gold', 0xE8B84A, 0.3, { metalness: 0.4 }),
    glass: mat('isl_glass', 0xE4F6FF, 0.08, { transparent: true, opacity: 0.35, depthWrite: false }), water: mat('isl_fountain_water', 0x7FD8FF, 0.15, { transparent: true, opacity: 0.85 }),
    glow: mat('isl_lantern_glow', 0xFFF6DC, 0.5, { emissive: 0xFFE3A8, emissiveIntensity: 1 }), dragon: sm('dragon_teal', 0x4FBE9B), belly: mat('isl_dragon_belly', 0xFFF0D8, 0.7), wing: mat('isl_dragon_wing', 0xB892F0, 0.7),
    toast: mat('isl_toast', 0xF2C27E, 0.8), crust: mat('isl_crust', 0xB9783E, 0.8), butter: sm('butter', 0xFFD25E), choc: mat('isl_choc', 0x7A4A35, 0.7), chocD: mat('isl_choc_dark', 0x5E3626, 0.75),
    banana: mat('isl_banana', 0xFFD84A, 0.6), bread: mat('isl_bread', 0xF3C98B, 0.8), leaf: mat('isl_leaf', 0x3FAF4E, 0.8), boba: mat('isl_boba', 0x3B2A2A, 0.25),
    frost: [sm('frost_pink', 0xFF9CC4, T.stud, 0.75), sm('frost_mint', 0x9EF0D3, T.stud, 0.75), sm('frost_cream', 0xFFF3E2, T.stud, 0.75)],
    cloud: mat('isl_cloud', 0xFFFFFF, 0.9), cloudIn: mat('isl_cloud_ear', 0xFFC8DC, 0.9), seg: mat('isl_ring_off', 0x3F3756, 0.6),
    ringOn: mat('isl_ring_on', 0x38B6FF, 0.4, { emissive: 0x38B6FF, emissiveIntensity: 0.9 }), ringFlash: mat('isl_ring_flash', 0xFFFFFF, 0.3, { emissive: 0xFFFFFF, emissiveIntensity: 1.4 }),
  };
}
const STR = {};
const stripes = (key, cols, n) => STR[key] || (STR[key] = canvasTex(128, (g, p) => { const w = p / n; for (let i = 0; i < n; i++) { g.fillStyle = cols[i % cols.length]; g.fillRect(i * w, 0, w + 1, p); } }, 1));
const LOOKM = () => ({
  Foam: { body: mat('isl_cap_foam', 0xFFF3E2, 0.8), trim: mat('isl_cap_foam_trim', 0xE6D3B8, 0.7) },
  Jelly: { body: mat('isl_cap_jelly', 0xFF6F86, 0.25), trim: mat('isl_cap_jelly_trim', 0xE8445C, 0.35) },
  Marshmallow: { body: mat('isl_cap_mallow', 0xFFF9F4, 0.85), trim: mat('isl_cap_mallow_trim', 0xE2A866, 0.75) },
  Gummy: { body: mat('isl_cap_gummy', 0x6FD889, 0.15, { transparent: true, opacity: 0.86 }), trim: mat('isl_cap_gummy_trim', 0x3FAF5E, 0.3) },
  Taffy: { body: mat('isl_cap_taffy', 0xFFFFFF, 0.5, { map: stripes('taffy', ['#FF9CC4', '#FFFFFF'], 10) }), trim: mat('isl_cap_taffy_trim', 0xFF6FA8, 0.45) },
  Caramel: { body: mat('isl_cap_caramel', 0xE0A050, 0.25), trim: mat('isl_cap_caramel_trim', 0xA8652A, 0.4) },
  Bubblegum: { body: mat('isl_cap_bubblegum', 0xFF6FC8, 0.3), trim: mat('isl_cap_bubblegum_trim', 0xD9409E, 0.35) },
  Rainbow: { body: mat('isl_cap_rainbow', 0xFFFFFF, 0.4, { map: stripes('rainbow', ['#E8343F', '#FF8A1F', '#FFC51F', '#9BE22B', '#38B6FF', '#8E4FE0'], 12) }), trim: mat('isl_cap_rainbow_trim', 0xFFFFFF, 0.4) },
  Crystal: { body: mat('isl_cap_crystal', 0xBFEFFF, 0.06, { metalness: 0.1, emissive: 0x6FD3F5, emissiveIntensity: 0.3 }), trim: mat('isl_cap_crystal_trim', 0xE4F6FF, 0.1, { metalness: 0.3 }) },
  Royal: { body: mat('isl_cap_royal', 0x7E57C2, 0.55), trim: mat('isl_cap_royal_trim', 0xE8B84A, 0.3, { metalness: 0.4 }) },
});
function ringText(text, R0, R1) {
  const W = 2048, m = canvasMat((g) => {
    const c = W / 2, rad = ((R0 + R1) / 2 / R1) * c, fs = Math.round(((R1 - R0) / R1) * c * 0.6);
    g.font = `700 ${fs}px Fredoka, system-ui, sans-serif`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.lineJoin = 'round';
    const ch = [...text], ws = ch.map((x) => g.measureText(x).width), k = (TAU * rad) / ws.reduce((a, b) => a + b, 0);
    let a = 0;
    ch.forEach((x, i) => { const w = ws[i] * k, th = -(a + w / 2) / rad; a += w; g.save(); g.translate(c + rad * Math.sin(th), c - rad * Math.cos(th)); g.rotate(th + Math.PI); g.lineWidth = fs * 0.18; g.strokeStyle = '#2B2233'; g.strokeText(x, 0, 0); g.fillStyle = '#FFFFFF'; g.fillText(x, 0, 0); g.restore(); });
  }, W, W, 'isl_zone_paint');
  m.polygonOffset = true; m.polygonOffsetFactor = -4; m.depthWrite = false;
  const geo = new THREE.PlaneGeometry(s(R1 * 2), s(R1 * 2)); geo.rotateX(-Math.PI / 2);
  const o = new THREE.Mesh(geo, m); o.name = 'zone_name_paint'; o.userData.noOutline = true; o.userData.noShadow = true; o.renderOrder = 1; return o;
}

const OWN = [0xE8343F, 0xFF8A1F, 0xFFC51F, 0x9BE22B, 0x1FC7B6, 0x38B6FF, 0x2E7BF0, 0x2B3A8C, 0x8E4FE0, 0xFF5FA2];
const NAMES = ['Mia', 'Leo', null, 'Zoe', 'Kai', '', 'Ava', null, 'Nova', 'Max']; // null = open plot, '' = you
const UNLOCKED = [4, 2, 0, 3, 1, 4, 4, 0, 2, 3];
const HERO_SET = [['Dragon', 61], ['Birdie', 52], ['Butter', 44], ['KittyBread', 33]];
const IDS = ['KittyBread', 'Toast', 'Banana', 'Butter', 'Chocolate', 'Birdie', 'Donut', 'Dragon', 'MochiFox', 'StrawberryFrog', 'BobaBear', 'PancakePup', 'CloudBunny', 'CupcakeAxolotl'];
const SLOTS = [[-13, -8], [13, -8], [-13, 8], [13, 8]];
const GREY = 0xB8BEC6;

export function buildIsland() {
  const M = palette(), LM = LOOKM(), r = rng(77), add = collector(), addP = collector();
  const A = group('SD_SQUISH_ISLAND'), tmp = group('_bake', A), annot = group('ANNOTATIONS');
  const D = { caps: [], hero: [], conf: [], wings: [], spam: false, spamT: 0, flash: 0, t: 0, pop: null };
  let dynN = 0; const P = (...a) => { dynN++; return put(...a); };
  const sign = (...a) => { dynN++; return plate(...a); };
  const twin = (name, x, z, ry) => ({ real: grp(name, A, x, 0, z, ry), bk: grp(name, tmp, x, 0, z, ry) });
  const FL = [M.red, M.yellow, M.pink, M.white, M.purple, M.orange];

  /* ground, sea */
  add(M.grass, CT(160, 160, 2, 128), tmp, 0, -1, 0);
  add(M.sand, CT(176, 178, 2, 128), tmp, 0, -1.6, 0);
  add(M.shallow, C(205, 205, 0.4, 96), tmp, 0, -1.6, 0);
  add(M.sea, C(620, 620, 0.4, 96), tmp, 0, -1.95, 0);

  /* Squish Square: tiles, curb with gaps at the 10 paths, painted zone name */
  add(M.tile, CT(70, 70, 0.9, 96), tmp, 0, 0.45, 0);
  for (let k = 0; k < 40; k++) { if (k % 4 === 0) continue; const a = k * 9, [x, z] = polar(a, 70.4); add(M.curb, BR(11.4, 1.3, 1.6), tmp, x, 0.65, z, 0, -a * D2R, 0); }
  const zone = ringText('SQUISH SQUARE  •  SQUISH SQUARE  •  ', 26, 37); zone.position.y = s(0.97); A.add(zone);

  /* Duel stage + queue pads + brick tower */
  add(M.white, C(22, 22.8, 1.2, 64), tmp, 0, 1.5, 0);
  add(M.stone, CT(21.2, 21.2, 0.1, 64), tmp, 0, 2.15, 0);
  const pads = [];
  for (let k = 0; k < 10; k++) { const mint = k < 5, a = (mint ? 240 : 60) + (k % 5) * 15, [x, z] = polar(a, 15.5); pads.push(P(C(2.6, 2.6, 0.4, 32), (mint ? M.mint : M.berry).clone(), 'queue_pad_' + (mint ? 'mint' : 'strawberry'), A, x, 2.4, z)); }
  const BRK = [M.red, M.yellow, M.blue, M.lime];
  [[14, 14], [-14, 14], [14, -14], [-14, -14]].forEach(([x, z], pi) => { for (let k = 0; k < 9; k++) add(BRK[(k + pi) % 4], BR(7, 3.8, 7), tmp, x, 4.1 + k * 3.8, z); });
  for (const [x, z, ry] of [[0, 14, 0], [0, -14, 0], [14, 0, Math.PI / 2], [-14, 0, Math.PI / 2]]) add(M.white, BR(21, 1.6, 1.6), tmp, x, 19, z, 0, ry, 0);
  add(M.white, BR(38, 2.4, 38), tmp, 0, 37.6, 0);
  for (const [x, z, ry] of [[0, 18.6, 0], [0, -18.6, 0], [18.6, 0, Math.PI / 2], [-18.6, 0, Math.PI / 2]]) {
    add(M.red, BR(38.4, 1.2, 1.2), tmp, x, 39.4, z, 0, ry, 0); add(M.yellow, BR(38, 0.7, 0.7), tmp, x, 42.2, z, 0, ry, 0);
    for (let k = -3; k <= 3; k++) add(M.yellow, BR(0.8, 2.6, 0.8), tmp, x + (ry ? 0 : k * 6), 40.9, z + (ry ? k * 6 : 0));
  }
  for (let k = 0; k < 4; k++) { const ry = (k * Math.PI) / 2; sign('DUEL', 15, 4.4, A, Math.sin(ry) * 19.3, 33.6, Math.cos(ry) * 19.3, ry, { bg: '#E8343F', fg: '#FFFFFF', border: '#2B2233' }); }

  /* Dragon Spire (landmark, faces your base in the south) */
  const dg = grp('dragon_spire', A, 0, 38.8, 0), db = grp('dragon_body', dg, 0, 0, 0);
  for (const [x, z] of [[5, 5], [-5, 5], [5, -5], [-5, -5]]) P(BR(4, 5, 4), M.dragon, 'dragon_leg', db, x, 2.5, z);
  P(BR(14, 11, 17), M.dragon, 'dragon_torso', db, 0, 10.5, 0); P(BR(10, 8, 0.8), M.belly, 'dragon_belly', db, 0, 9.5, 8.8);
  for (const z of [-6, -2.5, 1]) P(BR(1.6, 2.6, 2.2), M.yellow, 'dragon_spike', db, 0, 17.3, z);
  const hd = grp('dragon_head', db, 0, 16, 5);
  P(BR(12, 10, 11), M.dragon, 'dragon_head_block', hd, 0, 5, 0); P(BR(8, 5, 6), M.dragon, 'dragon_snout', hd, 0, 2.5, 8);
  for (const x of [-2, 2]) P(BR(1.2, 1, 0.4), M.dark, 'dragon_nostril', hd, x, 3.6, 11.1);
  for (const x of [-3.2, 3.2]) { P(BR(3, 3.2, 0.6), M.white, 'dragon_eye', hd, x, 6.6, 5.6); P(BR(1.5, 2, 0.4), M.dark, 'dragon_pupil', hd, x * 0.94, 6.3, 5.95); P(BR(1.8, 5, 1.8), M.yellow, 'dragon_horn', hd, x * 1.1, 11.6, -2.5, -0.35, 0, 0); }
  for (const sd of [-1, 1]) { const w = grp('dragon_wing', db, sd * 7, 14, -2); w.rotation.z = sd * 0.45; P(BR(13, 0.8, 9), M.wing, 'dragon_wing_membrane', w, sd * 6.5, 0, 0); P(BR(13, 1.2, 1.2), M.dragon, 'dragon_wing_bone', w, sd * 6.5, 0.4, 4.4); D.wings.push({ w, sd }); }
  P(BR(8, 6, 7), M.dragon, 'dragon_tail', db, 0, 7, -11); P(BR(5, 4, 6), M.dragon, 'dragon_tail', db, 0, 5, -16.5); P(BR(3, 3, 4), M.dragon, 'dragon_tail', db, 0, 4, -21); P(BR(4, 1, 3), M.yellow, 'dragon_tail_tip', db, 0, 5.9, -21);
  D.dragon = db;

  /* stalls between the paths, facing the tower */
  const stall = (ang, name, col, top) => {
    const [x, z] = polar(ang, 46), t = twin('STALL_' + name.replace(/\W+/g, '_'), x, z, face(x, z)), K = t.bk;
    add(M.wood, BR(12, 3.6, 5), K, 0, 2.7, 0); add(M.white, BR(12.6, 0.5, 5.6), K, 0, 4.75, 0); add(col, BR(12.2, 2.6, 0.4), K, 0, 2.6, 2.6);
    for (const [px, pz] of [[-5.8, -2.4], [5.8, -2.4], [-5.8, 2.4], [5.8, 2.4]]) add(M.white, BR(0.8, 9, 0.8), K, px, 5.4, pz);
    for (let k = 0; k < 6; k++) { const m = k % 2 ? M.white : col; add(m, BR(2.2, 0.5, 7), K, -5.5 + k * 2.2, 10.2, 0.4, 0.18, 0, 0); add(m, BR(2.2, 1, 0.4), K, -5.5 + k * 2.2, 9.1, 3.85); }
    sign(name, 10, 2.2, t.real, 0, 12.4, 3.2, 0, { bg: '#FFFFFF', fg: '#2B2233', border: css(col.color.getHex()) });
    top(K, t.real);
  };
  stall(18, 'Shop', M.red, (K, R) => { P(C(2.6, 2.6, 0.7, 28), M.gold, 'shop_big_coin', R, 0, 14.6, -0.5, Math.PI / 2, 0, 0); for (let k = 0; k < 4; k++) add(M.gold, C(1.2, 1.2, 0.5, 16), K, -3.4, 5.25 + k * 0.5, 0.8); for (let k = 0; k < 3; k++) add(M.gold, C(1.2, 1.2, 0.5, 16), K, 3.2, 5.25 + k * 0.5, 0.6); });
  stall(54, 'Squishy Box', M.purple, (K) => { add(M.purple, BR(6, 5, 6), K, 0, 14, -1); add(M.yellow, BR(6.2, 5.1, 1.1), K, 0, 14, -1); add(M.yellow, BR(1.1, 5.1, 6.2), K, 0, 14, -1); for (const sd of [-1, 1]) add(M.yellow, BR(2.6, 1.6, 1), K, sd * 1.1, 17.2, -1, 0, 0, -sd * 0.5); });
  stall(162, 'Quests', M.lime, (K) => { add(M.wood, BR(9, 6, 0.6), K, 0, 14.4, -1.5); for (let k = 0; k < 3; k++) { add(M.white, BR(2.2, 2.8, 0.2), K, -2.9 + k * 2.9, 14.2, -1.1); add(M.red, BR(0.4, 0.4, 0.3), K, -2.9 + k * 2.9, 15.5, -0.95); } });
  stall(198, 'Daily', M.yellow, (K, R) => { add(M.white, BR(6, 6.4, 3), K, 0, 14.6, -1); add(M.red, BR(6.1, 1.6, 3.1), K, 0, 17, -1); sign('7', 3, 3, R, 0, 14, 0.55, 0, { bg: null, fg: '#E8343F', size: 110 }); });
  stall(234, 'Collection', M.blue, (K, R) => { toyAt('Birdie', R, -3.6, 5, 0.6, 2.4); toyAt('Donut', R, 0, 5, 0.6, 2.4); toyAt('MochiFox', R, 3.6, 5, 0.6, 2.4); });

  /* practice range (tangent lane) and the foam mats with the giant Kitty Bread */
  {
    const [x, z] = polar(108, 57), t = twin('PRACTICE_RANGE', x, z, -108 * D2R), K = t.bk;
    add(M.stone, BR(40, 0.3, 8), K, 0, 1.05, 0); add(M.white, BR(0.6, 0.32, 8), K, -16, 1.07, 0);
    for (const zz of [-4.2, 4.2]) add(M.mint, BR(40, 0.8, 0.5), K, 0, 1.3, zz);
    for (let k = 0; k < 3; k++) { const zz = -2.6 + k * 2.6; add(M.wood, BR(0.7, 4.4, 0.7), K, 17, 3.1, zz); add(M.white, C(1.7, 1.7, 0.5, 24), K, 17, 5.6, zz, 0, 0, Math.PI / 2); add(M.red, C(1.1, 1.1, 0.56, 24), K, 17, 5.6, zz, 0, 0, Math.PI / 2); add(M.white, C(0.45, 0.45, 0.6, 16), K, 17, 5.6, zz, 0, 0, Math.PI / 2); }
    sign('Practice range', 12, 2.4, t.real, -12, 4.4, 4.6, 0, { bg: '#FFFFFF', fg: '#2B2233', border: '#5FD3AE' });
  }
  {
    const [x, z] = polar(288, 55), t = twin('FOAM_MATS', x, z, face(x, z)), K = t.bk;
    for (let i = 0; i < 6; i++) { const mx = -8 + (i % 3) * 8, mz = i < 3 ? 6 : -1; add(i % 2 ? M.mint : M.berry, BR(7, 0.5, 7), K, mx, 1.15, mz); add(M.cream, BR(6.2, 0.6, 6.2), K, mx, 1.6, mz); }
    add(M.white, BR(12, 1, 9), K, 0, 1.4, -10); toyAt('KittyBread', t.real, 0, 1.9, -10, 10);
  }
  { /* Butter Fountain */
    const [x, z] = polar(342, 47), K = grp('butter_fountain', tmp, x, 0, z, face(x, z));
    for (let k = 0; k < 8; k++) { const a = k * 45 * D2R; add(M.white, BR(5.2, 1.8, 1.6), K, Math.sin(a) * 6.4, 1.8, Math.cos(a) * 6.4, 0, a, 0); }
    add(M.water, C(6, 6, 0.5, 32), K, 0, 1.9, 0);
    add(M.butter, BR(5, 3, 4), K, 0, 3.6, 0); add(M.butter, BR(3.6, 2.4, 3), K, 0, 6.3, 0); add(M.butter, BR(2.4, 1.6, 2), K, 0, 8.3, 0, 0, 0.3, 0);
    for (const [dx, dz] of [[2.3, 1.2], [-2.1, -1.6], [1.4, -2.1]]) add(M.butter, BR(0.6, 1.8, 0.6), K, dx, 2.6, dz);
    for (let k = 0; k < 4; k++) { const a = (45 + k * 90) * D2R; add(M.water, BR(0.5, 3.2, 0.5), K, Math.sin(a) * 3.2, 3.4, Math.cos(a) * 3.2, Math.cos(a) * 0.5, 0, -Math.sin(a) * 0.5); }
  }
  for (const a of [18, 54, 162, 198, 234, 342]) { /* Chocolate bar benches */
    const [x, z] = polar(a, 63), b = grp('chocolate_bench', tmp, x, 0, z, face(x, z));
    add(M.choc, BR(7, 1, 2.6), b, 0, 2.1, 0); add(M.choc, BR(7, 3, 0.8), b, 0, 3.6, -1.2); for (const gx of [-1.8, 0, 1.8]) add(M.chocD, BR(0.3, 0.2, 2.62), b, gx, 2.62, 0);
    for (const sx of [-2.8, 2.8]) add(M.chocD, BR(1, 1.6, 2), b, sx, 1.4, 0);
  }
  for (const a of [99, 117, 276, 300]) { /* Pancake Stack tables */
    const [x, z] = polar(a, 66), b = grp('pancake_table', tmp, x, 0, z);
    add(M.woodD, C(0.5, 0.6, 2.4, 10), b, 0, 2.1, 0); for (let k = 0; k < 3; k++) add(M.toast, C(2.4 - k * 0.1, 2.4 - k * 0.1, 0.55, 24), b, 0, 3.6 + k * 0.55, 0);
    add(M.choc, C(2.2, 2.2, 0.15, 24), b, 0, 5, 0); add(M.butter, BR(1.1, 0.5, 1.1), b, 0, 5.3, 0); for (const sx of [-3.6, 3.6]) add(M.toast, C(1, 1, 1.8, 12), b, sx, 1.8, 0);
  }

  /* paths, Boba bollards, Mochi Fox lanterns */
  const lantern = (parent, x, z, ry) => { const g = grp('mochi_fox_lantern', parent, x, 0, z, ry); add(M.white, BR(0.8, 5, 0.8), g, 0, 2.5, 0); add(M.glow, BR(2, 2.3, 2), g, 0, 6.15, 0); add(M.orange, BR(2.5, 0.6, 2.5), g, 0, 7.6, 0); for (const sx of [-0.8, 0.8]) add(M.orange, BR(0.7, 1, 0.5), g, sx, 8.4, 0); };
  for (let i = 0; i < 10; i++) {
    const a = i * 36, [x, z] = polar(a, 83);
    add(M.path, BR(8, 0.35, 28), tmp, x, 0.18, z, 0, -a * D2R, 0);
    for (const rr of [76, 90]) for (const sd of [-1, 1]) { const [bx, bz] = polar(a + (sd * 5.6) / rr / D2R, rr); add(M.woodD, C(0.5, 0.6, 2.2, 10), tmp, bx, 1.1, bz); add(M.boba, SPH(0.95, 12, 8), tmp, bx, 2.9, bz); }
    for (const sd of [-1, 1]) { const [lx, lz] = polar(a + (sd * 6.4) / 73 / D2R, 73); lantern(tmp, lx, lz, -a * D2R); }
  }

  /* garden ring: one prop per sector between the paths */
  const cupTree = (x, z, k = 1, ci = 0) => {
    const g = grp('cupcake_tree', tmp, x, 0, z, r() * TAU); g.scale.setScalar(k);
    add(M.wood, BR(1.2, 5, 1.2), g, 0, 2.5, 0); add([M.pink, M.skyB, M.yellow][ci % 3], BR(6, 3, 6), g, 0, 6.5, 0);
    const fr = M.frost[ci % 3]; add(fr, BR(7, 2, 7), g, 0, 9, 0); add(fr, BR(5.2, 1.8, 5.2), g, 0, 10.9, 0); add(fr, BR(3.2, 1.4, 3.2), g, 0, 12.5, 0); add(M.red, BR(1.4, 1.4, 1.4), g, 0, 13.9, 0);
  };
  { const [x, z] = polar(18, 84), g = grp('toast_stack_tower', tmp, x, 0, z, face(x, z));
    [0, 0.14, -0.1, 0.2, -0.16, 0.06].forEach((rot, k) => { const y = 0.75 + k * 1.5, ox = k % 2 ? 0.4 : -0.3; add(M.crust, BR(8.4, 1.4, 7.4), g, ox, y, 0, 0, rot, 0); add(M.toast, BR(7.6, 0.1, 6.6), g, ox, y + 0.71, 0, 0, rot, 0); });
    add(M.butter, BR(2.6, 0.9, 2.6), g, 0, 9.9, 0, 0, 0.3, 0); }
  { const [x, z] = polar(90, 84), g = grp('banana_slide', tmp, x, 0, z, face(x, z) + Math.PI / 2);
    add(M.wood, BR(4, 9, 4), g, -7, 4.5, 0); add(M.white, BR(5, 0.6, 5), g, -7, 9.3, 0);
    for (let k = 0; k < 6; k++) add(M.white, BR(0.4, 0.4, 3), g, -9.2, 1.2 + k * 1.4, 0);
    for (let k = 0; k < 7; k++) { const t0 = k / 6; add(M.banana, BR(3.2, 0.8, 3.4), g, -4 + k * 2.3, 8.6 - Math.pow(t0, 0.85) * 8, 0, 0, 0, -0.15 - t0 * 0.7); }
    add(M.crust, BR(1.4, 0.9, 3.4), g, 12.4, 0.8, 0); }
  { const [x, z] = polar(198, 83), g = grp('frog_lily_pond', tmp, x, 0, z, face(x, z));
    add(M.water, C(9, 9, 0.5, 40), g, 0, 0.2, 0);
    for (let k = 0; k < 12; k++) { const a = k * 30 * D2R; add(M.stone, BR(4.8, 1.1, 2), g, Math.sin(a) * 9.8, 0.55, Math.cos(a) * 9.8, 0, a, 0); }
    for (const [px, pz, pr] of [[-3, 2, 2.2], [3.5, -1, 1.8], [0.5, -4.5, 1.6], [-4, -3, 1.4]]) add(M.leaf, C(pr, pr, 0.2, 20), g, px, 0.55, pz);
    add(M.red, BR(3, 2.2, 2.6), g, -3, 1.75, 2); add(M.leaf, BR(1.2, 0.8, 1.2), g, -3, 3.2, 2);
    for (const sx of [-0.8, 0.8]) { add(M.white, BR(0.8, 0.8, 0.5), g, -3 + sx, 2.4, 3.3); add(M.dark, BR(0.4, 0.4, 0.2), g, -3 + sx, 2.4, 3.6); add(M.red, BR(1, 0.6, 1.4), g, -3 + sx * 1.8, 0.95, 2.6); } }
  for (const [dx, dz, ci] of [[-5, -3, 0], [4, -4, 1], [0, 5, 2]]) { const [x, z] = polar(270, 84); cupTree(x + dx, z + dz, 0.9, ci); }
  for (const a of [54, 126, 162, 234, 306, 342]) {
    const [x, z] = polar(a, 84), g = grp('flower_bed', tmp, x, 0, z, face(x, z) + Math.PI / 2);
    add(M.wood, BR(12, 1.2, 4), g, 0, 0.6, 0); add(M.woodD, BR(11.4, 0.2, 3.4), g, 0, 1.25, 0);
    for (let k = 0; k < 8; k++) { const fx = -4.9 + k * 1.4, fz = k % 2 ? 0.8 : -0.8; add(M.leaf, BR(0.3, 1.6, 0.3), g, fx, 2.1, fz); add(FL[(k + a) % 6], BR(1, 1, 1), g, fx, 3.2, fz); }
  }
  for (let i = 0; i < 10; i++) for (const rr of [118, 141]) { const [x, z] = polar(i * 36 + 18, rr); cupTree(x, z, rr > 130 ? 1.15 : 1, i + (rr > 130 ? 1 : 0)); }

  /* beach + sea details */
  for (let k = 0; k < 14; k++) { const [x, z] = polar(k * 25.7 + r() * 10, 166 + r() * 7), g = grp('beach_rocks', tmp, x, 0, z, r() * TAU); add(M.rock, BR(4 + r() * 3, 2.4, 3.4), g, 0, 0.4, 0, 0, 0, 0.1); add(M.rock, BR(2.4, 1.6, 2.2), g, 2.6, 0, 1.4, 0.2, 0.4, 0); }
  for (let k = 0; k < 8; k++) { const [x, z] = polar(k * 45 + 22, 169); cupTree(x, z, 0.85, k); }
  for (let k = 0; k < 9; k++) { const [x, z] = polar(194 + k * 6 + r() * 4, 182 + r() * 14); add(M.leaf, C(1.6 + r(), 1.6 + r(), 0.2, 16), tmp, x, -1.25, z); }
  const clouds = grp('cloud_bunnies', A, 0, 0, 0); D.clouds = clouds;
  for (let k = 0; k < 6; k++) {
    const [x, z] = polar(k * 60 + 20, 120 + (k % 3) * 45), c = grp('cloud_bunny', clouds, x, 74 + (k % 2) * 14, z, r() * TAU); c.scale.setScalar(1 + (k % 3) * 0.25);
    P(BR(16, 5, 9), M.cloud, 'cloud_puff', c, 0, 0, 0); P(BR(9, 4, 7), M.cloud, 'cloud_puff', c, -7, 1.2, 1); P(BR(8, 5, 8), M.cloud, 'cloud_puff', c, 6, 1.8, -0.5); P(BR(7, 3, 6), M.cloud, 'cloud_puff', c, 1, 3.6, 0);
    for (const sx of [-2, 2]) { P(BR(1.8, 6, 1.4), M.cloud, 'cloud_ear', c, sx, 7.6, 0, 0, 0, sx * -0.08); P(BR(0.9, 4.4, 0.3), M.cloudIn, 'cloud_ear_inner', c, sx, 7.6, 0.75, 0, 0, sx * -0.08); }
  }

  /* capsules */
  const capsule = (parent, x, z, ry, id, lvl, hero) => {
    const lk = LM[lookOf(lvl).k], g = grp('capsule', parent, x, 1.6, z, ry);
    const body = [P(C(3.5, 3.7, 1.5, 28), lk.body, 'capsule_drum', g, 0, 0.75, 0), P(C(3.6, 3.6, 1.1, 28), lk.body, 'capsule_cap', g, 0, 9.35, 0)];
    const trim = [P(C(3.66, 3.66, 0.5, 28), lk.trim, 'capsule_trim', g, 0, 1.6, 0), P(C(1.2, 1.5, 1, 16), lk.trim, 'capsule_knob', g, 0, 10.4, 0)];
    P(C(3, 3, 7, 28), M.glass, 'capsule_glass', g, 0, 5.3, 0);
    for (let k = 0; k < 4; k++) { const q = (k + 0.5) * (Math.PI / 2); trim.push(P(BR(0.45, 7, 0.45), lk.trim, 'capsule_post', g, Math.sin(q) * 3.25, 5.3, Math.cos(q) * 3.25)); }
    const press = grp('capsule_press', g, 0, 8.8, 0); trim.push(P(C(2.5, 2.5, 0.5, 24), lk.trim, 'capsule_press_plate', press, 0, -0.25, 0)); P(C(0.4, 0.4, 1.2, 10), M.white, 'capsule_press_rod', press, 0, 0.35, 0);
    const wrap = grp('capsule_squishy', g, 0, 1.85, 0); toyAt(id, wrap, 0, 0, 0, 3.4);
    const c = { g, wrap, press, body, trim, id, lvl, hero, T: CAPSULE.interval(lvl), t: r() * CAPSULE.interval(lvl), ph: -1, y: 1, v: 0, spin: 0, pp: 0, segs: [], plate: sign(`Lv ${lvl}`, 3.2, 1.05, g, 0, 0.75, 3.76, 0, { round: 0.3 }) };
    if (hero) for (let k = 0; k < 12; k++) { const a = (k / 12) * TAU; c.segs.push(P(BR(1.55, 0.5, 0.5), M.seg, 'capsule_ring_seg', g, Math.sin(a) * 3.95, 1.6, Math.cos(a) * 3.95, 0, a, 0)); }
    D.caps.push(c); if (hero) D.hero.push(c); return c;
  };
  const lockedSlot = (parent, x, z, ry, price) => { const g = grp('locked_slot', parent, x, 1.6, z, ry); lockIcon(g, 0, 3.4, 0, { gold: M.gold, dark: M.dark }, 0.9); sign(big(price), 4.6, 1.5, g, 0, 1.2, 0.2, 0, { bg: '#2B2233', fg: '#FFC51F', border: '#FFC51F' }); dynN += 3; return g; };

  /* 10 bases in a ring; local +z faces the hub */
  const baseR = [];
  for (let i = 0; i < 10; i++) {
    const a = i * 36, [cx, cz] = polar(a, 122), name = NAMES[i], open = name === null, hero = name === '', hex = open ? GREY : OWN[i], T = textures();
    const own = mat('isl_own_' + i, hex, 0.62, { map: T.stud }), light = mat('isl_own_light_' + i, hexMix(hex, 0xFFFFFF, 0.62), 0.75, { map: T.stud }), dark = mat('isl_own_dark_' + i, hexMix(hex, 0x000000, 0.22), 0.65, { map: T.stud });
    const t = twin('BASE_' + String(i + 1).padStart(2, '0'), cx, cz, -a * D2R), K = t.bk, R = t.real, KP = hero ? grp('BASE_06_props', tmp, cx, 0, cz, -a * D2R) : K, ap = hero ? addP : add;
    baseR.push(R); own.color.setHex(hex); light.color.setHex(hexMix(hex, 0xFFFFFF, 0.62)); dark.color.setHex(hexMix(hex, 0, 0.22));
    add(light, BR(44, 1, 52), K, 0, 0.5, 0);
    for (const sz of [-1, 1]) add(own, BR(44.6, 1.3, 1.2), K, 0, 0.65, sz * 25.9);
    for (const sx of [-1, 1]) add(own, BR(1.2, 1.3, 52), K, sx * 21.9, 0.65, 0);
    const post = (x, z) => { add(M.white, BR(0.9, 4.4, 0.9), K, x, 3.2, z); add(own, BR(1.4, 0.7, 1.4), K, x, 5.75, z); };
    for (const sx of [-1, 1]) {
      for (const z of [-20, -12, -4, 4, 12, 20, 25.2]) post(sx * 21.6, z);
      post(sx * 16, 25.2);
      for (const y of [2.5, 4]) { add(M.white, BR(0.45, 0.45, 47.2), K, sx * 21.6, y, 1.6); add(M.white, BR(11.2, 0.45, 0.45), K, sx * 16, y, 25.2); }
    }
    for (let row = 0; row < 3; row++) for (let j = 0; j < 4; j++) add((row + j) % 2 ? M.white : own, BR(11, 3, 2), K, -16.5 + j * 11, 2.5 + row * 3, -25);
    add(dark, BR(6, 0.3, 6), K, 0, 1.15, -18);
    for (const sd of [-1, 1]) { add(M.white, BR(4.6, 0.32, 0.5), K, 0, 1.17, -18 + sd * 2.05); add(M.white, BR(0.5, 0.32, 4.6), K, sd * 2.05, 1.17, -18); }
    for (let k = 0; k < 6; k++) add(M.path, BR(6, 0.3, 4), K, 0, 1.15, -12 + k * 6.6);
    SLOTS.forEach(([x, z]) => add(dark, BR(8.4, 0.6, 8.4), K, x, 1.3, z));
    /* Donut Arch gate: frosting in the owner colour, name sign under it */
    for (const sx of [-1, 1]) add(own, BR(3, 3, 3), K, sx * 9.6, 2.5, 25.2);
    for (let k = 0; k <= 8; k++) { const q = (k * Math.PI) / 8; add(M.toast, BR(3.9, 3.2, 3.2), K, Math.cos(q) * 9.6, 4 + Math.sin(q) * 9.6, 25.2, 0, 0, q + Math.PI / 2); add(own, BR(4, 1.3, 3.4), K, Math.cos(q) * 10.9, 4 + Math.sin(q) * 10.9, 25.2, 0, 0, q + Math.PI / 2); }
    for (let k = 0; k < 10; k++) { const q = 0.2 + (k / 9) * (Math.PI - 0.4); add(FL[k % 6], BR(0.35, 0.35, 1.1), K, Math.cos(q) * 11.7, 4 + Math.sin(q) * 11.7, 25.2 + (k % 2 ? 0.7 : -0.7), 0, 0, k * 0.7); }
    for (const sx of [-5, 5]) add(M.white, BR(0.2, 1.6, 0.2), K, sx, 11.3, 26.1);
    const label = hero ? 'Your base' : open ? 'Open plot' : `${name}'s base`;
    const sg = sign(label, 13, 2.6, R, 0, 9.4, 26.2, 0, { bg: '#FFFFFF', fg: '#2B2233', border: css(hex) });
    for (const sx of [-1, 1]) lantern(K, sx * 12.8, 28.4, 0);
    const caps = []; let statue = null;
    if (!open) {
      /* props: Birdie nest, Toast bench, Chocolate flower box, Kitty Loaf mailbox */
      ap(M.wood, BR(5, 2, 5), KP, -17, 2, -19); ap(M.woodD, BR(4.4, 0.3, 4.4), KP, -17, 3.1, -19);
      for (const [nx, nz, q] of [[0, 1.5, 0], [0, -1.5, 0], [1.5, 0, 1], [-1.5, 0, 1]]) ap(M.crust, BR(3.4, 1, 0.8), KP, -17 + nx, 3.7, -19 + nz, 0, (q * Math.PI) / 2, 0);
      ap(M.skyB, BR(2, 1.6, 1.6), KP, -17, 4.6, -19); ap(M.orange, BR(0.6, 0.5, 0.7), KP, -17, 4.6, -17.9); for (const sx of [-0.55, 0.55]) ap(M.dark, BR(0.35, 0.35, 0.2), KP, -17 + sx, 5, -18.2);
      for (const sx of [14.6, 19.4]) ap(M.woodD, BR(0.8, 1.6, 2.4), KP, sx, 1.8, -19);
      ap(M.toast, BR(6, 1, 3), KP, 17, 3.1, -19); ap(M.crust, BR(6.6, 4.6, 0.6), KP, 17, 5.1, -20.6); ap(M.toast, BR(5.8, 3.8, 0.2), KP, 17, 5.1, -20.25);
      ap(M.choc, BR(6, 2, 3), KP, -17, 2, 19); for (const gx of [-1, 1]) ap(M.chocD, BR(0.3, 0.2, 3.05), KP, -17 + gx, 3.05, 19); ap(M.chocD, BR(6.05, 0.2, 0.3), KP, -17, 3.05, 19);
      for (let k = 0; k < 4; k++) { const fx = -19.2 + k * 1.5; ap(M.leaf, BR(0.3, 1.4, 0.3), KP, fx, 3.8, 19); ap([M.pink, M.yellow, M.white, M.red][k], BR(0.9, 0.9, 0.9), KP, fx, 4.9, 19); }
      ap(M.white, BR(0.8, 3.4, 0.8), KP, 17, 2.7, 19); ap(M.bread, BR(3.2, 2.4, 2.2), KP, 17, 5.6, 19); for (const sx of [-1, 1]) ap(M.bread, BR(0.7, 0.8, 0.6), KP, 17 + sx, 7.2, 19);
      for (const sx of [-0.6, 0.6]) ap(M.dark, BR(0.35, 0.35, 0.1), KP, 17 + sx, 5.9, 20.15); ap(M.red, BR(0.2, 1.6, 0.2), KP, 18.8, 6, 18.4); ap(M.red, BR(1, 0.7, 0.1), KP, 19.3, 6.5, 18.4);
      SLOTS.forEach(([x, z], j) => {
        const ry = x < 0 ? Math.PI / 2 : -Math.PI / 2;
        if (j < UNLOCKED[i]) { const [id, lvl] = hero ? HERO_SET[j] : [IDS[(i * 5 + j * 3) % 14], 1 + ((i * 23 + j * 37) % 100)]; caps.push(capsule(R, x, z, ry, id, lvl, hero)); }
        else lockedSlot(R, x, z, ry, CAPSULE.slots[j]);
      });
      add(M.white, BR(9, 3, 6), K, 0, 11.5, -25); statue = toyAt(caps[0].id, R, 0, 13, -25, 9);
    }
    if (hero) {
      const openSign = sign('Open plot', 13, 2.6, R, 0, 9.4, 26.2, 0, { bg: '#FFFFFF', fg: '#2B2233', border: css(GREY) }); openSign.visible = false;
      D.heroLock = lockedSlot(R, -13, -8, Math.PI / 2, CAPSULE.slots[1]); D.heroLock.visible = false;
      D.heroBase = { mats: [[own, hex, GREY], [light, hexMix(hex, 0xFFFFFF, 0.62), hexMix(GREY, 0xFFFFFF, 0.62)], [dark, hexMix(hex, 0, 0.22), hexMix(GREY, 0, 0.22)]], statue, sg, openSign, props: null };
    }
  }

  /* scale avatars */
  const avatars = [];
  const avatar = (parent, x, y, z, ry, team, hold) => {
    const av = buildAvatar({ team, name: 'ScaleAvatar_' + avatars.length }), h = grp('scale_avatar', parent, x, y, z, ry); h.add(av.root);
    av.root.traverse((o) => { if (o.isMesh && !o.userData.isOutline) o.castShadow = true; });
    if (hold) { const tt = toyAt(hold, av.grip, 0, 0, 0, 1.5); tt.position.set(0, 0, -0.12); }
    const an = new Animator(av); an.hold = !!hold; an.t = avatars.length * 0.9; avatars.push({ av, an, holder: h });
  };
  avatar(baseR[5], 0, 1.3, -17, 0, 'mint', 'KittyBread');
  avatar(baseR[0], 3, 1, 21, Math.PI, 'berry');
  avatar(baseR[0], -6, 1, -2, Math.PI / 2, 'berry', 'Toast');
  { const [x, z] = polar(90, 15.5); avatar(A, x, 2.6, z, face(x, z), 'berry'); }
  { const [x, z] = polar(270, 15.5); avatar(A, x, 2.6, z, face(x, z), 'mint', 'Donut'); }
  { const [x, z] = polar(18, 38.5); avatar(A, x, 0.9, z, face(x, z) + Math.PI, 'mint'); }

  /* merge static parts */
  const nParts = add.count() + addP.count() + dynN;
  A.updateMatrixWorld(true);
  const NOCAST = new Set([M.grass, M.sand, M.sea, M.shallow, M.tile, M.path, M.water, M.glow]);
  add.bake(group('island_static', A), NOCAST, 'SD_ISLAND_');
  const heroProps = group('BASE_06_props', A); addP.bake(heroProps, NOCAST, 'SD_ISLAND_BASE06_'); D.heroBase.props = heroProps;
  A.remove(tmp);
  A.traverse((o) => { if (!o.isMesh || o.userData.isOutline || o.name.startsWith('SD_ISLAND_')) return; if (o.userData.noShadow || o.material === M.glass || o.name.startsWith('cloud')) { o.castShadow = false; return; } o.castShadow = true; o.receiveShadow = true; });

  /* animation */
  const top = (c) => c.g.getWorldPosition(V3()).add(V3(0, s(12.5), 0));
  const CG = new THREE.BoxGeometry(s(0.6), s(0.6), s(0.16)), CM = [M.red, M.yellow, M.blue, M.lime, M.pink, M.orange];
  const confetti = (p, n) => { for (let i = 0; i < n; i++) { const m = new THREE.Mesh(CG, CM[i % 6]); m.name = 'fx_confetti'; m.position.copy(p); A.add(m); const q = Math.random() * TAU, sp = s(5 + Math.random() * 9); D.conf.push({ m, v: V3(Math.cos(q) * sp, s(16 + Math.random() * 12), Math.sin(q) * sp), w: V3(Math.random() * 14 - 7, Math.random() * 14 - 7, Math.random() * 14 - 7), life: 1.2 + Math.random() * 0.6 }); } };
  const setLevel = (c, L, fx) => {
    const was = lookOf(c.lvl).k; c.lvl = Math.max(1, Math.min(100, L)); c.T = CAPSULE.interval(c.lvl); c.t = Math.min(c.t, c.T * 0.9);
    const lk = lookOf(c.lvl), m = LM[lk.k]; c.body.forEach((o) => (o.material = m.body)); c.trim.forEach((o) => (o.material = m.trim));
    c.plate.parent.remove(c.plate); c.plate = plate(`Lv ${c.lvl}`, 3.2, 1.05, c.g, 0, 0.75, 3.76, 0, { round: 0.3 });
    if (!fx) return;
    const p = top(c); p.y -= s(5); confetti(p, lk.k !== was ? 70 : 26); c.spin = 0.7; c.v += 3.4; c.pp = 0.3; D.flash = 0.35;
    if (D.pop) D.pop(top(c), lk.k !== was ? `<b>${lk.k} tier!</b> squeezes every ${c.T.toFixed(1)} s` : `<b>Lv ${c.lvl}</b> · ${big(sqPow(c.id) * CAPSULE.power(c.lvl))} per squeeze`);
  };
  const tap = () => { for (const c of D.hero) { if (!c.g.visible) continue; c.t += 0.15 * c.T; c.v -= 1.5; } };
  const stepCap = (c, dt) => {
    if (!c.g.visible) return;
    c.t += dt; if (c.t >= c.T) { c.t %= c.T; c.ph = 0; c.paid = false; c.kick = false; }
    let k = 0;
    if (c.ph >= 0) {
      c.ph += dt; const p = c.ph;
      k = p < 0.16 ? (p / 0.16) ** 2 : p < 0.3 ? 1 : p < 0.62 ? 1 - easeOut((p - 0.3) / 0.32) : 0; if (p >= 0.62) c.ph = -1;
      if (!c.paid && p >= 0.16) { c.paid = true; if (c.hero && D.pop) { const pw = CAPSULE.power(c.lvl); D.pop(top(c), `<b>+${big(sqPow(c.id) * pw)}</b> Coins · <b>+${big(pw)}</b> Grip`); } }
      if (!c.kick && p >= 0.3) { c.kick = true; c.v += 2.6; }
    }
    c.press.position.y = s(8.8 - 4.5 * k);
    const target = Math.min(1, Math.max(0.58, (8.3 - 4.5 * k - 1.85) / 3.4));
    for (let n = Math.ceil(dt / 0.006), h = dt / n, j = 0; j < n; j++) { c.v += (900 * (target - c.y) - 26 * c.v) * h; c.y += c.v * h; }
    const w = 1 + (1 - c.y) * 0.6; c.wrap.scale.set(w, c.y, w);
    if (c.spin > 0) { c.spin = Math.max(0, c.spin - dt); c.wrap.rotation.y = TAU * easeOut(1 - c.spin / 0.7); }
    if (c.pp > 0) { c.pp = Math.max(0, c.pp - dt); c.plate.scale.setScalar(1 + (0.4 * c.pp) / 0.3); }
    if (c.segs.length) { const lit = Math.floor((c.t / c.T) * 12), fl = D.flash > 0; c.segs.forEach((m, i) => (m.material = fl ? M.ringFlash : i < lit ? M.ringOn : M.seg)); }
  };
  const C1 = () => D.hero[0];
  const act = (k) => {
    if (k === 'tap') tap();
    if (k === 'spam') { D.spam = !D.spam; return true; }
    if (k === 'up' && C1().g.visible) { if (C1().lvl >= 100) { if (D.pop) D.pop(top(C1()), '<b>Max level</b>'); } else setLevel(C1(), C1().lvl + 1, true); }
    if (k === 'look' && C1().g.visible) { const nx = C1().lvl >= 91 ? 0 : (CAPSULE.tier(C1().lvl) + 1) * 10 + 1; setLevel(C1(), nx || 1, !!nx); }
    return false;
  };

  /* stations (panel), cameras in metres */
  const v = (x, y, z) => V3(s(x), s(y), s(z));
  const cams = (T, yaw, d, h, det) => { const at = (q, dd, hh) => T.clone().add(V3(Math.sin(q) * s(dd), s(hh), Math.cos(q) * s(dd))); return { Front: [at(yaw, d, h), T.clone()], '¾ view': [at(yaw + 0.7, d * 0.95, h * 1.25), T.clone()], Detail: det || [at(yaw - 0.35, d * 0.45, h * 0.5), T.clone()] }; };
  const stations = [], labels = [];
  const st = (id, name, lp, cm, info, states = [], set = () => {}, actions = null) => { stations.push({ id, name, info, cams: cm, states, cur: states[0], set, actions }); labels.push({ t: name, p: lp, id }); };
  const [sx0, sz0] = polar(18, 46), [rx0, rz0] = polar(205, 168);
  st('hub', 'Squish Square', v(-30, 16, 30), cams(v(0, 4, 0), 2.5, 120, 70, [v(-20, 18, 58), v(0, 1, 30)]),
    { what: 'A raised square with the Duel tower in the middle and 7 stalls between the 10 paths. The zone name is painted around the stage.', foot: 'Ø140 st · stage Ø44 · stalls at r 46', interact: 'Duel queue in the centre · each stall opens its usual screen', mats: 'White tiles, bright brick tower, white paint with an ink outline', keep: 'All 7 stations stay; only their places change' });
  st('tower', 'Duel tower', v(0, 76, 0), cams(v(0, 34, 0), 0.35, 100, 30, [v(14, 62, 44), v(0, 58, 10)]),
    { what: 'Four brick pillars, a deck at 39 st and a blocky Dragon on top: the landmark you can see from every base.', foot: '38 × 38 st deck · about 69 st tall', interact: '10 queue pads under the deck (5 mint, 5 strawberry), same queue rules', mats: 'Red, yellow, blue and lime bricks · teal Dragon', keep: 'Duel queue rules unchanged' },
    ['Waiting', 'Match found'], (k) => pads.forEach((m) => { m.material.emissive.setHex(m.material.color.getHex()); m.material.emissiveIntensity = k === 'Match found' ? 0.8 : 0; }));
  st('base', 'Your base', v(0, 22, 122), cams(v(0, 5, 118), Math.PI, 62, 34, [v(0, 15, 142), v(0, 8, 72), true]),
    { what: 'Your own plot: 4 capsule pads, a statue of the squishy in capsule 1, a Donut Arch gate with your name, and props made from the squishies.', foot: '44 × 52 st · gate 16 wide · Detail = your spawn view', interact: 'You spawn here · taps here also push your capsules', mats: 'Your colour on the floor, rim and frosting · white fence', keep: 'Visitors can walk in and look, nothing more' },
    ['Owned', 'Open plot'], (k) => {
      const o = k === 'Open plot', H = D.heroBase; H.mats.forEach(([m, a, b]) => m.color.setHex(o ? b : a)); H.statue.visible = !o; H.props.visible = !o; H.sg.visible = !o; H.openSign.visible = o;
      D.hero.forEach((c) => (c.g.visible = !o)); D.heroLock.visible = false; if (o) D.spam = false;
    });
  st('capsule', 'Capsules', v(13, 16, 130), cams(v(13, 5.5, 130), -Math.PI / 2, 20, 6, [v(0, 36, 98), v(0, 1, 124)]),
    { what: 'Each capsule squeezes on its own: every 4.0 s at Foam, down to 1.3 s at Royal. A squeeze pays squishy power × capsule power in Coins (10 at Lv1, 59B with Dragon at Lv100) and capsule power in Grip.', foot: '8 × 8 st pad · 11 st tall · 10 tiers × 10 levels', interact: 'Tap, click or E opens its card · upgrade with Coins · tapping in your base speeds it up', mats: 'One look per tier: Foam, Jelly, Marshmallow, Gummy, Taffy, Caramel, Bubblegum, Rainbow, Crystal, Royal', keep: 'No hourly cap; no pay while offline; one squishy per capsule' },
    [...CAPSULE.tiers, 'Locked'], (k) => {
      const c = C1(), lock = k === 'Locked'; c.g.visible = !lock && D.heroBase.statue.visible; D.heroLock.visible = lock;
      if (!lock) setLevel(c, CAPSULE.tiers.indexOf(k) * 10 + 1, false);
    }, [['tap', 'Tap'], ['spam', 'Spam-tap'], ['up', 'Upgrade'], ['look', 'Next look']]);
  st('stalls', 'Stalls', v(sx0, 20, sz0), cams(v(sx0, 8, sz0), face(sx0, sz0), 19, 10),
    { what: 'Shop, Squishy Box, Quests, Daily and Collection become market stalls, each with one big prop on top.', foot: '12 × 5 st counters under striped awnings', interact: 'Walk up and the usual screen opens', mats: 'Awnings in each station colour', keep: 'Same screens, new places' });
  st('garden', 'Garden', v(84, 18, 0), cams(v(84, 4, 0), -Math.PI / 2, 48, 24),
    { what: 'Between the paths: Toast Stack Tower, Banana Slide, Frog Lily Pond, a cupcake grove and flower beds. Boba bollards and Mochi Fox lanterns line the paths.', foot: 'Ring r 70–96 · 10 paths, 8 wide', interact: 'Decor only; small bits have no collision', mats: 'Studded grass, path stone', keep: 'Every prop comes from a squishy' });
  st('beach', 'Beach and sea', v(rx0, 14, rz0), cams(v(rx0, 2, rz0), Math.atan2(rx0, rz0), 70, 24),
    { what: 'A sand ring with rocks and cupcake trees, lily pads on the shallow water and Cloud Bunny clouds overhead.', foot: 'Beach r 160–176 · water out to the horizon', interact: 'Decor only', mats: 'Checker sand, two blues of water', keep: 'Gives the island an edge you can see' });

  return {
    root: A, annot, stations, avatars, labels,
    title: 'Squish Island · 10 bases',
    sub: 'The new base lobby from the spec: every player gets a base with up to 4 auto-squeeze capsules, in a ring around the Duel tower. Pick a station to fly there.',
    facts: `<div class="facts"><div><span>Island</span><b>Ø352 st (99 m): grass to r 160, beach to r 176, sea beyond</b></div><div><span>Bases</span><b>10 × (44 × 52 st), gates at r 96 facing the tower · 8 owned, 2 open</b></div><div><span>Walking</span><b>spawn → Duel 116 st ≈ 7.3 s · gate → Duel 74 st ≈ 4.6 s</b></div><div><span>Parts</span><b>${nParts.toLocaleString('en-US')} in this model · spec budget 5,200</b></div></div>`,
    fine: 'Every number is a proposal [P] from the specs of 2026-10-11 and 2026-10-12. Studs here are a texture; in Roblox they use the built-in Studs surface.',
    cams: { 'Overview A': [v(-150, 150, 270), v(0, 0, 40)], 'Overview B': [v(220, 130, -200), v(0, 0, -10)], Plan: [v(0, 600, 0.01), v(0, 0, 0)], 'Spawn eye': [v(0, 15, 142), v(0, 8, 72), true] },
    light: 16, shadow: 56, far: 900, sky: 0x9FD9F6, fog: [s(380), s(1600)], clip: [0.1, 1500],
    get spam() { return D.spam; },
    act,
    update(dt, pop) {
      D.t += dt; D.pop = pop;
      if (D.spam) { D.spamT -= dt; while (D.spamT <= 0) { D.spamT += 0.2; tap(); } }
      for (const c of D.caps) stepCap(c, dt);
      if (D.flash > 0) D.flash -= dt;
      D.dragon.position.y = s(Math.sin(D.t * 1.3) * 0.25);
      for (const w of D.wings) w.w.rotation.z = w.sd * (0.45 + 0.12 * Math.sin(D.t * 2.1));
      D.clouds.rotation.y += dt * 0.012;
      for (let i = D.conf.length - 1; i >= 0; i--) { const q = D.conf[i]; q.v.y -= s(42) * dt; q.m.position.addScaledVector(q.v, dt); q.m.rotation.x += q.w.x * dt; q.m.rotation.y += q.w.y * dt; q.m.rotation.z += q.w.z * dt; q.life -= dt; if (q.life <= 0) { A.remove(q.m); D.conf.splice(i, 1); } }
    },
  };
}
