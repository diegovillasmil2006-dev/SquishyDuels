import { THREE, V3, mat, mesh, group, STUD, lathe } from './kit.js';
import { CATALOG, RARITY, buildToy, byId, Squisher, DragonHead, studs } from './toys.js';
import { SoftSquish, SquishAudio, feelOf } from './squish.js';
import { SFX, FX } from './fx.js';
import { buildAvatar, Animator, DASH, DASH_DIR, JUMP, KEY_LABELS, JUMP_LABELS, applyPose, ROBLOX_NAMES } from './avatar.js';
import { buildArena, ArenaSim, ARENA, COVERS } from './arena.js';
import { buildBlox, BLOX } from './blox.js';
import { buildLobby } from './lobby.js';
import { buildIsland } from './island.js';
import { buildPillow, buildReef, buildArcade, ARENAS2 } from './arenas2.js';

const stage = document.querySelector('three-d-stage');
await stage.ready;
const scene = stage._scene, camera = stage._camera, controls = stage._controls, key = stage._key;
const KEY_POS = key.position.clone();
const rim = new THREE.DirectionalLight(0xffe4ee, 0.75); rim.position.set(-3, 4, -5); scene.add(rim);
const sfx = new SFX(), fx = new FX(scene);
const sa = new SquishAudio(sfx);
const deco = group('__deco', scene);
const $ = (s) => document.querySelector(s);
const panel = $('#panel'), labelsEl = $('#labels'), toast = $('#toast'), tl = $('#timeline');
const protos = {}; const proto = (id) => protos[id] || (protos[id] = buildToy(id));
const hex = (n) => '#' + n.toString(16).padStart(6, '0');
const ease = (t) => 0.5 - 0.5 * Math.cos(Math.PI * Math.min(1, Math.max(0, t)));
const S = STUD;

let V = { name: null }, labels = [], camTw = null, fxNow = 0, timeScale = 1, toastT = 0;
const state = { toyId: 'KittyBread', sound: true, shake: true, quality: 'High', arena: 'sweet', lobby: 'island' };

function say(msg, dur = 2.2) { toast.textContent = msg; toast.classList.add('on'); toastT = dur; }
function addLabel(html, getPos, cls = '') { const el = document.createElement('div'); el.className = 'lbl ' + cls; el.innerHTML = html; labelsEl.appendChild(el); const L = { el, getPos, on: true }; labels.push(L); return L; }
function clearLabels() { labelsEl.innerHTML = ''; labels = []; }
function popAt(p, html) { const L = addLabel(html, () => p, 'pop'); setTimeout(() => { L.el.remove(); const i = labels.indexOf(L); if (i >= 0) labels.splice(i, 1); }, 1400); }
function tweenCam(pos, tgt, dur = 0.8) { camTw = { p0: camera.position.clone(), t0: controls.target.clone(), p1: pos.clone(), t1: tgt.clone(), t: 0, dur }; }
function shadowSpan(n, far) { const c = key.shadow.camera; c.left = c.bottom = -n; c.right = c.top = n; c.far = far || 500; c.updateProjectionMatrix(); }
function setShadowRes(n) { if (key.shadow.mapSize.x === n) return; key.shadow.mapSize.set(n, n); if (key.shadow.map) { key.shadow.map.dispose(); key.shadow.map = null; } }
function panForPanel(k) { const f = controls.target.clone().sub(camera.position), d = f.length(); const right = f.normalize().cross(V3(0, 1, 0)).normalize(); const sh = right.multiplyScalar(d * k * Math.min(1, 340 / Math.max(1, window.innerWidth) * 2.4)); camera.position.add(sh); controls.target.add(sh); controls.update(); }
function recv(o) { o.traverse((m) => { if (m.isMesh) { m.receiveShadow = true; m.castShadow = !m.userData.noShadow; } }); return o; }
function clearGroup(g) { while (g.children.length) g.remove(g.children[0]); }

function cleanup() {
  fx.clear(); clearGroup(deco); clearLabels(); tl.classList.remove('on'); tl.innerHTML = '';
  if (V.sim) V.sim.dispose();
  if (V.soft) V.soft.dispose();
  controls.autoRotate = false; controls.enabled = true; stage._ground.visible = true;
  key.position.copy(KEY_POS); setShadowRes(2048); camTw = null; timeScale = 1;
  if (V.bg !== undefined) { scene.background = V.bg; scene.fog = null; }
  V = { name: null }; panel.classList.remove('mini');
}
function setTabs(n) { document.querySelectorAll('[data-view]').forEach((b) => b.classList.toggle('on', b.dataset.view === n)); }
function rarityChip(r) { return `<span class="chip" style="--c:${RARITY[r]}">${r}</span>`; }

/* ======================= LINEUP ======================= */
function viewLineup() {
  cleanup(); V.name = 'lineup'; setTabs('lineup');
  stage.setAttribute('name', 'SquishyDuels_Lineup_14');
  const root = group('SD_Lineup_14');
  const rows = [CATALOG.filter((c) => c.existing), CATALOG.filter((c) => !c.existing)];
  V.toys = []; V.sq = [];
  rows.forEach((row, ri) => {
    const built = row.map((c) => buildToy(c.id));
    const gap = 0.16, total = built.reduce((a, t) => a + t.size.x, 0) + gap * (built.length - 1);
    let x = -total / 2;
    built.forEach((t) => { t.root.position.set(x + t.size.x / 2, ri ? 0.16 : 0, ri ? -0.7 : 0); x += t.size.x + gap; root.add(t.root); V.toys.push(t); V.sq.push(new Squisher(t)); });
    const tier = mesh(new THREE.BoxGeometry(total + 0.7, ri ? 0.32 : 0.16, 0.66), mat(ri ? 'tier_back' : 'tier_front', ri ? 0xF6E3CF : 0xFBF0E2, 0.88), 'display_tier', deco, [0, ri ? 0.0 : -0.08, ri ? -0.72 : 0]);
    mesh(new THREE.BoxGeometry(total + 0.72, 0.03, 0.02), mat(ri ? 'trim_mint' : 'trim_strawberry', ri ? 0x5FD3AE : 0xF2687F, 0.6), 'tier_trim', deco, [0, ri ? 0.14 : -0.015, ri ? -0.39 : 0.331]);
    if (false) addLabel(ri ? '<b>Six new originals</b><span>proposed rarity · new design IDs</span>' : '<b>Existing eight</b><span>redesigned · catalog IDs and rarity unchanged</span>', () => V3(-total / 2 - 0.15, ri ? 0.5 : 0.36, ri ? -0.7 : 0), 'row');
  });
  mesh(new THREE.CylinderGeometry(9, 9, 0.02, 64), mat('studio_floor', 0xF1E8DA, 0.95), 'floor', deco, [0, -0.17, 0]);
  recv(deco);
  stage.setObject(root); stage._ground.visible = false;
  V.toys.forEach((t, i) => {
    const back = !t.meta.existing;
    const L = addLabel(`<i style="--c:${RARITY[t.meta.rarity]}"></i><b>${t.meta.name}</b>`, () => { const p = V3(); t.root.getWorldPosition(p); if (back) p.y += t.size.y + 0.05; else { p.y = -0.02; p.z += 0.4; } return p; }, 'toy' + (back ? '' : ' below'));
    L.el.style.pointerEvents = 'auto'; L.el.onclick = () => { sfx.tick(); state.toyId = t.meta.id; viewInspect(); };
    L.el.onmouseenter = () => { V.sq[i].kick(-1.2); };
  });
  V.auto = 1.5;
  tweenCam(V3(0, 1.05, 4.1), V3(0, 0.2, -0.35), 0.01);
  panel.classList.add('mini');
  panel.innerHTML = `
    <h2>14-toy lineup</h2>
    <p class="hint">Front: existing eight, IDs and rarity unchanged. Back: six new originals, proposed rarity. Matched scale, 1 stud = 0.28 m, avg. height ${studs(V.toys.reduce((a, t) => a + t.size.y, 0) / 14)} st. Click a name to inspect.</p>`;
}

/* ======================= INSPECT ======================= */
function buildTarget(x, h, face = 1) {
  const g = group('practice_target', deco, [x, 0, 0]);
  const wob = group('target_wobble', g);
  mesh(new THREE.CylinderGeometry(0.3, 0.34, 0.06, 40), mat('target_base', 0x3F3756, 0.6), 'target_base', g, [0, 0.03, 0]);
  mesh(new THREE.CylinderGeometry(0.028, 0.028, h, 16), mat('cane_white', 0xFFF8F2, 0.6), 'target_post', wob, [0, h / 2, 0]);
  const board = group('target_board', wob, [0, h, 0], [0, 0, Math.PI / 2]);
  [[0.42, 0xFFF6E8], [0.34, 0xF2687F], [0.25, 0xFFF6E8], [0.16, 0x5FD3AE], [0.07, 0xF2687F]].forEach(([r, c], i) => mesh(new THREE.CylinderGeometry(r, r, 0.05 + i * 0.006, 48), mat('target_ring_' + i, c, 0.7), 'target_ring', board, [0, 0, 0]));
  board.rotation.y = face > 0 ? 0 : Math.PI;
  recv(g); g.visible = false;
  return { g, wob, a: 0, v: 0, x, h, face };
}
function viewInspect(id) {
  cleanup(); V.name = 'inspect'; setTabs('inspect');
  if (id) state.toyId = id;
  const t = buildToy(state.toyId), m = t.meta;
  V.toy = t; V.sq = new Squisher(t); V.soft = new SoftSquish(t, { audio: sa, squisher: V.sq, pan: 0 });
  stage.setAttribute('name', 'SD_ART_' + m.id);
  const r = Math.max(t.size.x, t.size.z) * 0.72 + 0.08;
  mesh(new THREE.CylinderGeometry(r, r * 1.05, 0.05, 72), mat('pedestal_top', 0xFFF8EE, 0.7), 'pedestal', deco, [0, -0.025, 0]);
  mesh(new THREE.TorusGeometry(r * 1.025, 0.013, 10, 120), mat('rim_' + m.rarity, new THREE.Color(RARITY[m.rarity]).getHex(), 0.5), 'pedestal_rim', deco, [0, -0.004, 0], [Math.PI / 2, 0, 0]);
  mesh(new THREE.CylinderGeometry(12, 12, 0.02, 64), mat('studio_floor', 0xF1E8DA, 0.95), 'floor', deco, [0, -0.06, 0]);
  V.target = buildTarget(-3.2, 0.6, 1);
  recv(deco);
  stage.setObject(t.root); stage._ground.visible = false; shadowSpan(4.5);
  panForPanel(0.2);
  V.home = { p: camera.position.clone(), t: controls.target.clone() };
  const sz = t.size, tr = m.trail;
  panel.innerHTML = `
    <div class="head"><button class="nav" data-act="prev" aria-label="Previous toy">‹</button><div><h2>${m.name}</h2><div class="tags">${rarityChip(m.rarity)}<span class="tag">${m.existing ? 'Existing · redesigned' : 'New · proposed'}</span></div></div><button class="nav" data-act="next" aria-label="Next toy">›</button></div>
    <div class="acts">
      <button class="big" data-act="squeeze" id="sqBtn">Hold to squeeze <kbd>Space</kbd></button>
      <button class="big alt" data-act="throw">Throw <kbd>T</kbd></button>
      ${m.id === 'Dragon' ? '<button class="big ult" data-act="ult">Dragon ultimate <kbd>U</kbd></button>' : ''}
    </div>
    <div class="meter"><div class="bar"><i id="sqBar"></i></div><span id="sqTxt">Idle · 0%</span></div>
    <div class="seg" role="group" aria-label="Turnaround">${['Front', '3/4', 'Side', 'Back', 'Top'].map((v) => `<button data-cam="${v}">${v}</button>`).join('')}<button data-act="spin" id="spinBtn">Turntable</button></div>
    <div class="facts">
      <div><span>Design asset</span><b class="mono">SD_ART_${m.id}</b></div>
      <div><span>Size W×H×D</span><b>${studs(sz.x)} × ${studs(sz.y)} × ${studs(sz.z)} st</b></div>
      <div><span>Pivot</span><b>base center, +Z = face</b></div>
      <div><span>Grip</span><b>RightGripAttachment → lower third, face out</b></div>
      <div><span>Flight</span><b>${m.flight}</b></div>
      <div><span>Squeeze</span><b>${Math.round((1 - m.squeeze.depth) * 100)}% · ${feelOf(m.id).label}</b></div>
      <div><span>Trail</span><b><i class="sw" style="background:${hex(tr.a)}"></i><i class="sw" style="background:${hex(tr.b)}"></i> ${studs(tr.w)} st · ${tr.life}s · ${tr.shape}</b></div>
      <div><span>Secondary</span><b>${t.sec.length} spring part${t.sec.length === 1 ? '' : 's'}</b></div>
    </div>
    <p class="note">${m.note}</p>
    <p class="fine">Drag on the squishy to knead it; drag off its edge to stretch it. Preview squeezes award no Coins or Grip. Gameplay hitbox and range stay as currently implemented; this art only replaces the visual.</p>
    <div class="grid14 small">${CATALOG.map((c) => `<button class="tbtn ${c.id === m.id ? 'on' : ''}" data-toy="${c.id}" style="--c:${RARITY[c.rarity]}"><i></i>${c.name}</button>`).join('')}</div>`;
  const b = $('#sqBtn');
  b.addEventListener('pointerdown', (e) => { e.preventDefault(); squeezeOn(); });
  ['pointerup', 'pointerleave', 'pointercancel'].forEach((ev) => b.addEventListener(ev, squeezeOff));
}
function squeezeOn() {
  if (V.name !== 'inspect' || V.throw || V.sq.pressed) return;
  const m = V.toy.meta; V.sq.press(); V.soft.top(true);
  const base = V3(0, 0.02, 0), r = Math.max(V.toy.size.x, V.toy.size.z) * 0.55;
  fx.ring(base, { color: RARITY[m.rarity], r0: r * 0.6, r1: r * 1.5, life: 0.45, opacity: 0.55 });
  fx.burst('sphere', base, 10, { colors: [0xFFF6EA, 0xF6E6D4], speed: 1.1, size: 0.02, life: 0.5, flat: true, gravity: 0.4, drag: 4, spread: r * 0.9 });
}
function squeezeOff() {
  if (V.name !== 'inspect' || !V.sq || !V.sq.pressed) return;
  const m = V.toy.meta; V.sq.release(); V.soft.top(false);
  const top = V3(0, V.toy.size.y * 0.8, 0), tr = m.trail;
  fx.burst(tr.shape, top, 9, { colors: tr.pcols, speed: 1.4, size: 0.022, life: 0.75, normal: V3(0, 1, 0), bias: 1.2, gravity: -2.5, floor: 0.005 });
  if (m.rarity === 'Epic' || m.rarity === 'Exclusive') { fx.burst('spark', top, 6, { colors: [0xFFFFFF, tr.sparkle || 0xFFE27A], speed: 1.2, size: 0.02, life: 0.6, gravity: 0.3 }); sfx.sparkle(3); }
  if (!V.toldNoReward) { V.toldNoReward = true; say('Preview squeeze · no Coins or Grip awarded'); }
}
function startThrow(ult) {
  if (V.name !== 'inspect' || V.throw) return;
  if (V.sq.pressed) V.sq.release();
  const T = V.target; T.g.visible = true; T.pop = 0;
  tweenCam(V3(-0.25, 1.3, 4.7), V3(-0.45, 0.42, 0), 0.6);
  V.throw = { phase: ult ? 'charge' : 'windup', t: 0, ult };
  if (ult) {
    sfx.roar(); V.sq.press();
    fx.ring(V3(T.x, 0.012, 0), { color: 0xFF9A4D, r0: 0.75, r1: 0.75, life: 1.5, pulse: 16, opacity: 0.8, inner: 0.9 });
    say('Telegraph = authoritative impact area (placeholder radius)');
  } else { V.sq.press(); sfx.squish(V.toy.meta.squeeze.pitch * 1.1); }
}
function impactFX(p, normal, m, big) {
  const tr = m.trail;
  fx.splat(p, normal, tr.b, big ? 0.22 : 0.13, big ? 1.0 : 1.4);
  fx.burst(tr.shape, p, big ? 26 : 16, { colors: tr.pcols, speed: big ? 3.2 : 2.2, size: big ? 0.03 : 0.024, life: 0.75, normal, bias: 0.9, gravity: -5, floor: 0.005 });
  fx.burst('spark', p, big ? 14 : 8, { colors: [0xFFFFFF, 0xFFE27A], speed: 2.2, size: 0.022, life: 0.45, normal, gravity: 0 });
  fx.ring(p, { color: RARITY[m.rarity], r0: 0.05, r1: big ? 0.9 : 0.5, life: 0.32, normal, opacity: 0.9 });
  fx.flash(p.clone().addScaledVector(normal, 0.3), 0xFFE0B0, big ? 18 : 7, 0.22);
  fx.kick(big ? 0.05 : 0.018);
  sfx.splat(1); setTimeout(() => sfx.ding(), 60);
}
function updateThrow(dt) {
  const th = V.throw, t = V.toy, m = t.meta, T = V.target;
  th.t += dt;
  const h = t.size.y, endP = V3(T.x + 0.045, T.h + (Math.random() - 0.5) * 0.04, (Math.random() - 0.5) * 0.06);
  if (th.phase === 'windup') {
    t.root.rotation.z = -0.32 * ease(th.t / 0.2);
    if (th.t >= 0.2) {
      V.sq.release(); V.sq.kick(4); sfx.whoosh(0.55);
      const car = (th.car = group('carrier', deco, [0, h / 2, 0])); car.add(t.root); t.root.position.set(0, -h / 2, 0); t.root.rotation.set(0, 0, 0);
      th.start = V3(0, h / 2, 0); th.end = endP.clone().setX(endP.x + h * 0.35);
      const twin = m.trail.twin || 0;
      th.ribs = (twin ? [-twin, twin] : [0]).map((o) => ({ o, r: fx.ribbon({ a: m.trail.a, b: m.trail.b, width: m.trail.w, life: m.trail.life, opacity: 0.85, wavy: m.trail.wavy }) }));
      th.phase = 'flight'; th.t = 0;
    }
  } else if (th.phase === 'flight') {
    const dur = m.flight === 'float' ? 0.62 : 0.48, k = Math.min(1, th.t / dur);
    const p = th.start.clone().lerp(th.end, k); p.y += Math.sin(Math.PI * k) * 0.45 + (m.flight === 'hop' ? Math.abs(Math.sin(k * Math.PI * 3)) * 0.12 : 0) + (m.flight === 'float' ? Math.sin(k * 12) * 0.03 : 0);
    const car = th.car; car.position.copy(p);
    const r = car.rotation;
    switch (m.flight) {
      case 'tumble': r.z += dt * 13; break;
      case 'frisbee': r.y += dt * 22; r.x = 0.35; break;
      case 'spiral': r.x += dt * 16; r.y = -0.2; break;
      case 'glide': r.y = -Math.PI / 2; r.z = Math.sin(th.t * 20) * 0.15; break;
      case 'wheel': r.z += dt * 18; break;
      case 'face': r.y = -Math.PI / 2; r.x = Math.sin(th.t * 18) * 0.1; break;
      case 'hop': r.y += dt * 6; break;
      case 'upright': r.z = Math.sin(th.t * 16) * 0.2; break;
      case 'float': r.y += dt * 4; r.z = Math.sin(th.t * 9) * 0.2; break;
      default: r.y += dt * 8; r.z = Math.sin(th.t * 22) * 0.3;
    }
    th.ribs.forEach(({ o, r: rb }) => rb.push(p.clone().add(V3(0, 0, o)), fxNow));
    const tr = m.trail;
    if (Math.random() < tr.rate * dt * 2) fx.emit(tr.shape, { pos: p.clone().add(V3((Math.random() - 0.5) * 0.08, (Math.random() - 0.5) * 0.08, (Math.random() - 0.5) * 0.08)), vel: V3(0.6 + Math.random() * 0.6, Math.random() * 0.6, (Math.random() - 0.5) * 0.6), color: tr.pcols[(Math.random() * tr.pcols.length) | 0], size: 0.018 + Math.random() * 0.012, life: 0.55, gravity: tr.gravity ?? -2.5 });
    if (tr.sparkle && Math.random() < 0.35) fx.emit('spark', { pos: p, vel: V3(Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5), color: tr.sparkle, size: 0.016, life: 0.4, gravity: 0 });
    if (tr.ember && Math.random() < 0.6) fx.emit('glowdrop', { pos: p, vel: V3(0.8, 0.4, 0), color: [0xFF9A4D, 0xFFD25E][(Math.random() * 2) | 0], size: 0.02, life: 0.35, gravity: 1 });
    if (k >= 1) {
      th.ribs.forEach(({ r: rb }) => rb.stop());
      impactFX(V3(T.x + 0.04, p.y, p.z), V3(1, 0, 0), m, false);
      T.v += 3.2; addHitPop('Practice hit · no Coins');
      th.phase = 'bounce'; th.t = 0; th.vel = V3(1.5, 1.9, 0.45);
    }
  } else if (th.phase === 'bounce') {
    const car = th.car; th.vel.y -= 9.8 * dt; car.position.addScaledVector(th.vel, dt); car.rotation.z -= dt * 6;
    if (car.position.y < h / 2) { car.position.y = h / 2; th.vel.y *= -0.35; th.vel.x *= 0.6; if (Math.abs(th.vel.y) > 0.4) { fx.burst('sphere', car.position.clone().setY(0.02), 5, { colors: [0xFFF6EA], speed: 0.8, size: 0.016, life: 0.4, flat: true, drag: 5, gravity: 0.3 }); sfx.land(false); } }
    if (th.t > 0.75) { th.phase = 'out'; th.t = 0; }
  } else if (th.phase === 'out') {
    const k = Math.min(1, th.t / 0.16); th.car.scale.setScalar(1 - k);
    if (k >= 1) {
      fx.burst('sphere', th.car.position, 10, { colors: [0xFFFFFF, 0xF6E6D4], speed: 1.2, size: 0.03, life: 0.45, gravity: 0.5, drag: 3 });
      stage._scene.add(t.root); t.root.position.set(0, 0, 0); t.root.rotation.set(0, 0, 0); t.root.scale.setScalar(0.001); deco.remove(th.car);
      th.phase = 'respawn'; th.t = 0; tweenCam(V.home.p, V.home.t, 0.7);
      fx.ring(V3(0, 0.01, 0), { color: RARITY[m.rarity], r0: 0.05, r1: 0.6, life: 0.5, opacity: 0.8 }); sfx.pop(); sfx.sparkle(2);
    }
  } else if (th.phase === 'respawn') {
    const k = Math.min(1, th.t / 0.42), e = k < 1 ? 1 + Math.sin(k * Math.PI * 2.2) * (1 - k) * 0.35 - (1 - k) * (1 - k) * 0.9 : 1;
    t.root.scale.setScalar(Math.max(0.001, e));
    if (k >= 1) { t.root.scale.setScalar(1); V.throw = null; T.g.visible = false; }
  } else if (th.phase === 'charge') {
    t.root.rotation.z = Math.sin(th.t * 60) * 0.02;
    const c = V3(0, h * 0.6, 0);
    for (let i = 0; i < 3; i++) { const d = V3(Math.random() - 0.5, Math.random() - 0.3, Math.random() - 0.5).normalize(); fx.emit('glowdrop', { pos: c.clone().addScaledVector(d, 0.55), vel: d.multiplyScalar(-1.5), color: [0xFF9A4D, 0xFFD25E, 0xB892F0][i], size: 0.018, life: 0.35, gravity: 0, drag: 0 }); }
    if (th.t > 0.8) {
      V.sq.release(); V.sq.kick(5); t.root.rotation.z = 0;
      const head = DragonHead(); head.scale.setScalar(1.5); head.position.set(0, h * 0.75, 0.05); deco.add(head);
      th.head = head; th.hs = head.position.clone(); th.he = V3(T.x + 0.2, T.h, 0);
      th.ribs = [fx.ribbon({ a: 0xFFE7A0, b: 0xFF9A4D, width: 0.42, life: 0.28, opacity: 0.85 }), fx.ribbon({ a: 0xD9C6FF, b: 0xB892F0, width: 0.2, life: 0.4, opacity: 0.7, wavy: 1 })];
      sfx.whoosh(0.32); th.phase = 'launch'; th.t = 0;
    }
  } else if (th.phase === 'launch') {
    const k = Math.min(1, th.t / 0.3), p = th.hs.clone().lerp(th.he, k * k * (3 - 2 * k)); p.y += Math.sin(Math.PI * k) * 0.25;
    th.head.position.copy(p); th.head.lookAt(th.he.x - 1, th.he.y, th.he.z); th.head.rotateY(Math.PI); th.head.rotation.z = 0;
    th.head.lookAt(th.he);
    th.ribs.forEach((r, i) => r.push(p.clone().add(V3(0, i * 0.04 - 0.02, 0)), fxNow));
    for (let i = 0; i < 4; i++) fx.emit(i % 2 ? 'glowdrop' : 'sphere', { pos: p.clone().add(V3((Math.random() - 0.5) * 0.3, (Math.random() - 0.5) * 0.3, (Math.random() - 0.5) * 0.3)), vel: V3(1.5, Math.random() * 0.6, (Math.random() - 0.5)), color: i % 2 ? 0xFF9A4D : 0xEDE4F7, size: i % 2 ? 0.028 : 0.05, life: 0.4, gravity: 0.8, drag: 2 });
    if (k >= 1) {
      deco.remove(th.head); th.ribs.forEach((r) => r.stop());
      const at = V3(T.x + 0.05, T.h, 0);
      impactFX(at, V3(1, 0, 0), V.toy.meta, true);
      fx.ring(V3(T.x, 0.015, 0), { color: 0xFFD25E, r0: 0.1, r1: 0.75, life: 0.3, opacity: 0.9 });
      fx.burst('glowdrop', at, 40, { colors: [0xFF9A4D, 0xFFD25E, 0xFF6F7D], speed: 4, size: 0.03, life: 0.6, gravity: -4 });
      fx.burst('sphere', V3(T.x, 0.1, 0), 18, { colors: [0xFFF1E3, 0xE9DDF7], speed: 1.8, size: 0.07, life: 0.8, flat: true, drag: 3, gravity: 0.6 });
      sfx.boom(); T.v += 6; addHitPop('Dragon burst · visual only, damage area = telegraph');
      th.phase = 'settle'; th.t = 0;
    }
  } else if (th.phase === 'settle') {
    if (th.t > 1.1) { tweenCam(V.home.p, V.home.t, 0.7); V.throw = null; setTimeout(() => { if (V.target && !V.throw) V.target.g.visible = false; }, 700); }
  }
}
function addHitPop(txt) {
  const T = V.target, p = V3(T.x, T.h + 0.55, 0), L = addLabel(txt, () => p, 'pop'); L.t = 0;
  setTimeout(() => { L.el.remove(); labels = labels.filter((x) => x !== L); }, 1400);
}

/* ======================= AVATAR ======================= */
const CLIP_INFO = {
  F: 'Forward', B: 'Backward', L: 'Left strafe', R: 'Right strafe',
};
function viewAvatar() {
  cleanup(); V.name = 'avatar'; setTabs('avatar');
  stage.setAttribute('name', 'SD_Avatar_R15_' + state.toyId);
  const av = buildAvatar({ team: 'mint', name: 'SD_Avatar_R15' });
  const toy = proto(state.toyId).root.clone(true); toy.scale.setScalar(0.8); toy.position.set(0, 0, -0.12); av.grip.add(toy);
  av.root.rotation.y = -Math.PI / 2;
  V.av = av; V.an = new Animator(av); V.toyMesh = toy; V.mv = { x: 0, z: 0 };
  V.an.onEvent = (n, d) => avatarEvent(n, d);
  const floorM = mat('court_mint', 0xBDEAD6, 0.8);
  mesh(new THREE.BoxGeometry(14, 0.04, 6), mat('arena_floor_cream', 0xF4E6D3, 0.86), 'motion_floor', deco, [0.8, -0.02, 0]);
  mesh(new THREE.BoxGeometry(12, 0.012, 4.6), floorM, 'motion_lane', deco, [0.8, 0.006, 0]);
  for (let i = -20; i <= 26; i += 2) mesh(new THREE.BoxGeometry(0.02, 0.014, i % 10 === 0 ? 0.3 : 0.14), mat('court_line', 0xFFFDF8, 0.6), 'stud_tick', deco, [i * S, 0.012, 2.1]);
  V.hrpMark = mesh(new THREE.RingGeometry(0.14, 0.18, 40).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ color: 0x2E9C7C }), 'hrp_marker', deco, [0, 0.016, 0]);
  V.pelMark = mesh(new THREE.CircleGeometry(0.06, 24).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ color: 0xF2687F }), 'pelvis_marker', deco, [0, 0.018, 0]);
  V.target = buildTarget(-4.6, 1.15, 1);
  V.target.g.visible = true;
  mesh(new THREE.CylinderGeometry(12, 12, 0.02, 64), mat('studio_floor', 0xF1E8DA, 0.95), 'floor', deco, [0, -0.05, 0]);
  recv(deco);
  stage.setObject(av.root); stage._ground.visible = false; shadowSpan(7);
  V.home = { p: V3(-0.2, 1.75, 8.6), t: V3(-0.2, 1.2, 0) };
  tweenCam(V.home.p, V.home.t, 0.01);
  V.markLabels = [];
  V.markLabels.push(addLabel('<b>HRP</b> gameplay root', () => V3(V.mv.x, 0.02, V.mv.z + 0.25), 'tiny mint'));
  V.markLabels.push(addLabel('<b>Pelvis</b> visual offset', () => { const p = V3(); V.av.J.root.getWorldPosition(p); p.y = 0.02; p.z += 0.25; return p; }, 'tiny pink'));
  panel.innerHTML = `
    <h2>Avatar motion · R15</h2>
    <p class="sub">Proposed baseline rig. Animation authored at 30 fps; gameplay displacement stays server-owned.</p>
    <div class="label">Dash (holding ${byId(state.toyId).name})</div>
    <div class="pad">
      <span></span><button data-dash="F">Forward <kbd>↑</kbd></button><span></span>
      <button data-dash="L">Left <kbd>←</kbd></button><button data-dash="B">Back <kbd>↓</kbd></button><button data-dash="R">Right <kbd>→</kbd></button>
    </div>
    <div class="acts row"><button class="big" data-act="jump">Jump <kbd>Space</kbd></button><button class="big alt" data-act="runjump">Run + jump <kbd>J</kbd></button><button class="big alt" data-act="athrow">Throw <kbd>F</kbd></button></div>
    <div class="label">Playback</div>
    <div class="seg" role="group" aria-label="Speed">${[1, 0.5, 0.25].map((v) => `<button data-speed="${v}" class="${v === 1 ? 'on' : ''}">${v}×</button>`).join('')}<button data-act="holdtoggle" id="holdBtn" class="on">Holding</button></div>
    <div class="seg" role="group" aria-label="Pose sheets"><button data-sheet="F">Dash pose sheet</button><button data-sheet="L">Strafe sheet</button><button data-sheet="J">Jump pose sheet</button></div>
    <div class="state"><span>State</span><b id="anState">Idle</b><span>Frame</span><b id="anFrame">—</b></div>
    <div class="facts">
      <div><span>Dash displacement</span><b>14 st / 0.22 s · provisional</b></div>
      <div><span>Dash cooldown</span><b>unassigned (server)</b></div>
      <div><span>Jump</span><b>JumpPower 50, g 196.2 → 6.4 st apex, 0.51 s air</b></div>
      <div><span>Priorities</span><b>Locomotion: Movement · Dash/Jump: Action · Throw: Action2 (upper mask)</b></div>
      <div><span>AnimationIds</span><b>unassigned</b></div>
    </div>
    <p class="fine">The pelvis offset (pink) never exceeds 0.3 st; all travel comes from the HumanoidRootPart (mint ring), so no second displacement is baked into the clip.</p>`;
}
function footPos(side) { const p = V3(); V.av.J[side + 'Ankle'].getWorldPosition(p); p.y = 0.02; return p; }
function avatarEvent(n, d) {
  if (n === 'pushoff') { const p = footPos(d === 'L' ? 'r' : d === 'R' ? 'l' : d === 'B' ? 'l' : 'r'); fx.burst('sphere', p, 9, { colors: [0xFFF6EA, 0xE9DCC8], speed: 1.6, size: 0.04, life: 0.5, flat: true, gravity: 0.4, drag: 4.5 }); sfx.dash(); }
  if (n === 'plant') { const p = footPos(d === 'R' ? 'r' : 'l'); fx.burst('sphere', p, 6, { colors: [0xFFF6EA, 0xE9DCC8], speed: 1.1, size: 0.035, life: 0.45, flat: true, gravity: 0.3, drag: 5 }); sfx.land(false); }
  if (n === 'takeoff') { fx.burst('sphere', V3(V.mv.x, 0.02, V.mv.z), 6, { colors: [0xFFF6EA], speed: 1, size: 0.035, life: 0.4, flat: true, drag: 5, gravity: 0.3 }); sfx.jump(); }
  if (n === 'land') { const p = V3(V.mv.x, 0.015, V.mv.z); fx.ring(p, { color: 0xFFFFFF, r0: 0.15, r1: d ? 0.9 : 0.6, life: 0.35, opacity: 0.6 }); fx.burst('sphere', p.setY(0.03), d ? 14 : 8, { colors: [0xFFF6EA, 0xE9DCC8], speed: 1.5, size: 0.04, life: 0.5, flat: true, drag: 5, gravity: 0.3 }); sfx.land(d); }
  if (n === 'release') {
    const from = V3(); V.toyMesh.getWorldPosition(from); V.toyMesh.visible = false;
    const m = byId(state.toyId), obj = proto(state.toyId).root.clone(true); obj.scale.setScalar(0.8); deco.add(obj);
    V.proj = { obj, from, to: V3(V.target.x + 0.05, V.target.h, 0), t: 0, m, rib: fx.ribbon({ a: m.trail.a, b: m.trail.b, width: m.trail.w, life: m.trail.life, opacity: 0.85, wavy: m.trail.wavy }) };
    sfx.whoosh(0.45);
  }
}
function avDash(dir) {
  if (V.name !== 'avatar' || V.an.dash || V.an.airborne || V.sheet) return;
  const d = DASH_DIR[dir], w = V3(-d[2], 0, d[0]);
  const D = 14 * S;
  V.mv.x = -0.6 - w.x * D / 2; V.mv.z = -w.z * D / 2 * 0.6;
  V.dash = { w, t: 0, D, dir, line: null };
  V.an.startDash(dir);
  const len = D, mid = V3(V.mv.x + w.x * D / 2, 0.02, V.mv.z + w.z * D / 2);
  const line = mesh(new THREE.BoxGeometry(len, 0.01, 0.035), new THREE.MeshBasicMaterial({ color: 0x2E9C7C, transparent: true, opacity: 0.8 }), 'dash_path', deco, [mid.x, 0.02, mid.z], [0, Math.atan2(-w.z, w.x), 0]);
  V.dash.line = line;
  V.dash.ribs = [fx.ribbon({ a: 0xBDEAD6, b: 0xFFFFFF, width: 0.16, life: 0.16, opacity: 0.45 }), fx.ribbon({ a: 0xFFFFFF, b: 0xBDEAD6, width: 0.1, life: 0.14, opacity: 0.35 })];
  setTimeout(() => { if (V.dash && V.dash.line === line) {} deco.remove(line); }, 1400);
  renderTimeline('dash', dir);
}
function avJump(run) {
  if (V.name !== 'avatar' || V.an.airborne || V.an.dash || V.sheet) return;
  if (run) { V.mv.x = 1.3; V.mv.z = 0; V.run = { t: 0, jumped: false, after: 0 }; }
  else { V.mv.x = -0.6; V.mv.z = 0; V.an.startJump(); }
  renderTimeline('jump');
}
function avThrow() { if (V.name !== 'avatar' || V.an.throwT >= 0 || V.sheet || !V.an.hold) return; V.mv.x = -0.2; V.mv.z = 0; V.an.startThrow(); renderTimeline('throw'); }
function renderTimeline(kind, dir) {
  tl.classList.add('on');
  if (kind === 'dash') {
    const keys = DASH[dir];
    const SH = ['Compress', 'Push-off', 'Peak', 'Plant', 'Recover'];
    tl.innerHTML = `<div class="tl-h">Dash ${CLIP_INFO[dir]} · 12 frames @ 30 fps · 0.40 s visual · gameplay 0.22 s</div><div class="tl-f">${Array.from({ length: 13 }, (_, f) => `<div class="cell ${keys.some((q) => q.f === f) ? 'key' : ''}" data-f="${f}"><b>${f}</b></div>`).join('')}</div><div class="tl-k">${keys.map((q, i) => `<span style="left:${((q.f + 0.5) / 13) * 100}%">${SH[i]}</span>`).join('')}</div>`;
    V.tlKind = 'dash';
  } else if (kind === 'jump') {
    tl.innerHTML = `<div class="tl-h">Jump · state-driven by vertical velocity and ground contact (no fixed timeline)</div><div class="tl-s">${JUMP_LABELS.map((l) => `<div class="st" data-s="${l}">${l}</div>`).join('')}</div>`;
    V.tlKind = 'jump';
  } else {
    const TK = { 0: 'Ready', 4: 'Windup', 6: 'Release ●', 10: 'Follow', 20: 'Recover' };
    tl.innerHTML = `<div class="tl-h">Throw · upper-body mask (Action2) · release event f6 = gameplay spawn</div><div class="tl-f">${Array.from({ length: 21 }, (_, f) => `<div class="cell ${TK[f] ? 'key' : ''}" data-f="${f}"><b>${f}</b></div>`).join('')}</div><div class="tl-k">${Object.entries(TK).map(([f, l]) => `<span style="left:${((+f + 0.5) / 21) * 100}%">${l}</span>`).join('')}</div>`;
    V.tlKind = 'throw';
  }
}
function showSheet(kind) {
  if (V.sheet && V.sheet.kind === kind) { hideSheet(); return; }
  hideSheet();
  const g = group('pose_sheet', deco), sheet = { kind, g, avs: [] };
  const poses = kind === 'J' ? [JUMP.TAKEOFF, JUMP.RISE, JUMP.APEX, JUMP.FALL, JUMP.LAND] : DASH[kind].map((k) => k.p);
  const names = kind === 'J' ? JUMP_LABELS : KEY_LABELS;
  const ys = kind === 'J' ? [0, 0.8, 1.15, 0.7, 0] : [0, 0, 0, 0, 0];
  poses.forEach((P, i) => {
    const av = buildAvatar({ team: 'mint', name: 'pose_' + i });
    const toy = proto(state.toyId).root.clone(true); toy.scale.setScalar(0.8); toy.position.set(0, 0, -0.12); av.grip.add(toy);
    av.root.position.set(-2.6 + i * 1.2, ys[i], 0); av.root.rotation.y = Math.PI / 2; applyPose(av, P); g.add(av.root); recv(av.root);
    const f = kind === 'J' ? ['physics starts f0', 'vy > 0', '|vy| small', 'vy < 0', 'ground contact'][i] : `F${DASH[kind][i].f} · ${(DASH[kind][i].f / 30).toFixed(3)} s`;
    addLabel(`<b>${names[i]}</b><span>${f}</span>`, () => V3(-2.6 + i * 1.2, -0.05, 0.75), 'sheet');
  });
  V.av.root.visible = false; V.sheet = sheet; V.markLabels.forEach((l) => (l.on = false)); V.hrpMark.visible = V.pelMark.visible = false;
  tweenCam(V3(1.9, 1.7, 8.6), V3(1.9, 0.95, 0), 0.6);
  document.querySelectorAll('[data-sheet]').forEach((b) => b.classList.toggle('on', b.dataset.sheet === kind));
}
function hideSheet() {
  if (!V.sheet) return;
  deco.remove(V.sheet.g);
  labels.filter((l) => l.el.classList.contains('sheet')).forEach((l) => l.el.remove());
  labels = labels.filter((l) => !l.el.classList.contains('sheet'));
  V.sheet = null; V.av.root.visible = true; V.markLabels.forEach((l) => (l.on = true)); V.hrpMark.visible = V.pelMark.visible = true; tweenCam(V.home.p, V.home.t, 0.6);
  document.querySelectorAll('[data-sheet]').forEach((b) => b.classList.remove('on'));
}
function updateAvatar(dt) {
  const an = V.an, mv = V.mv;
  if (V.dash) {
    const d = V.dash; d.t += dt;
    const T = 0.22, k = Math.min(1, d.t / T), pk = Math.min(1, (d.t - dt) / T);
    const e = (x) => 1 - Math.pow(1 - Math.max(0, x), 3);
    const step = d.D * (e(k) - e(pk));
    mv.x += d.w.x * step; mv.z += d.w.z * step;
    if (d.t < 0.26) { const sh = V3(); V.av.J.waist.getWorldPosition(sh); d.ribs[0].push(sh.clone().add(V3(0, 0.35, 0)), fxNow); d.ribs[1].push(sh.clone().add(V3(0, -0.15, 0)), fxNow); }
    else if (!d.stopped) { d.stopped = true; d.ribs.forEach((r) => r.stop()); }
    if (d.t > 0.6) V.dash = null;
  }
  if (V.run) {
    const r = V.run; r.t += dt;
    let sp = 16;
    if (r.t > 0.25 && !r.jumped) { r.jumped = true; an.startJump(); }
    if (r.jumped && !an.airborne) { r.after += dt; if (r.after > 0.15) sp = Math.max(0, 16 * (1 - (r.after - 0.15) / 0.3)); }
    an.speed = sp; mv.x -= sp * S * dt;
    if (r.after > 0.5) { V.run = null; an.speed = 0; }
  }
  an.update(dt);
  V.av.root.position.set(mv.x, an.airY() * S, mv.z);
  V.hrpMark.position.set(mv.x, 0.016, mv.z);
  const pp = V3(); V.av.J.root.getWorldPosition(pp); V.pelMark.position.set(pp.x, 0.018, pp.z);
  if (V.proj) {
    const q = V.proj; q.t += dt; const k = Math.min(1, q.t / 0.42);
    const p = q.from.clone().lerp(q.to, k); p.y += Math.sin(Math.PI * k) * 0.3;
    q.obj.position.copy(p); q.obj.rotation.z += dt * 12; q.rib.push(p, fxNow);
    if (k >= 1) {
      deco.remove(q.obj); q.rib.stop(); V.proj = null;
      impactFX(V3(V.target.x + 0.04, p.y, p.z), V3(1, 0, 0), q.m, false); V.target.v += 3;
      setTimeout(() => { if (V.toyMesh) { V.toyMesh.visible = true; fx.burst('spark', V3().setFromMatrixPosition(V.toyMesh.matrixWorld), 5, { colors: [0xFFFFFF], speed: 0.8, size: 0.015, life: 0.35, gravity: 0 }); sfx.pop(); } }, 250);
    }
  }
  const st = $('#anState'), fr = $('#anFrame');
  if (st) { st.textContent = an.state + (an.throwT >= 0 ? ' + Throw' : ''); fr.textContent = an.dash ? `${Math.min(12, an.dash.f).toFixed(1)} / 12` : an.throwT >= 0 ? `${an.throwT.toFixed(1)} / 20` : '—'; }
  if (V.tlKind === 'dash' && an.dash) tl.querySelectorAll('.cell').forEach((c) => c.classList.toggle('now', +c.dataset.f === Math.round(an.dash.f)));
  if (V.tlKind === 'throw' && an.throwT >= 0) tl.querySelectorAll('.cell').forEach((c) => c.classList.toggle('now', +c.dataset.f === Math.round(an.throwT)));
  if (V.tlKind === 'jump') { const s = an.state; tl.querySelectorAll('.st').forEach((c) => c.classList.toggle('now', (s.includes('Takeoff') && c.dataset.s === 'Takeoff') || (s.includes('Rising') && c.dataset.s === 'Rising') || (s.includes('Apex') && c.dataset.s === 'Apex') || (s.includes('Falling') && c.dataset.s === 'Falling') || (s.startsWith('Land') && c.dataset.s === 'Land / compress'))); }
}

/* ======================= ARENAS ======================= */
const ARENA_DEFS = {
  sweet: { name: 'Sweetshop Stadium', id: 'SD_ARENA_SweetshopStadium', build: buildArena, L: ARENA.L, W: ARENA.W, facts: [
    ['Theme', 'Bakery sports court · wafer walls, layer cake, marshmallows'], ['Spawn → first cover', '15.5 st · 0.97 s @ WalkSpeed 16'], ['Spawn → center line', '82 st · 5.1 s'], ['Cross-court throw', '60–110 st · 0.9–1.6 s @ 70 st/s (placeholder speed)'], ['Narrowest lane', '27 st (wall end ↔ perimeter) · ≥ 2 dash widths'],
    ['Cover', '4 wafer walls (7 st full) · 1 cake tower · 3 marshmallows (3.5 st half) per side'], ['Jump vs cover', '6.4 st apex clears half cover sightline, never full cover']],
    fine: 'Stands, cupcake scoreboards, lollipops and light poles sit outside bounds and never block aim. No hazards, moving parts or disappearing cover.' },
  pine: { name: 'Pinewood Camp', id: 'SD_ARENA_PinewoodCamp', build: buildBlox, L: BLOX.L, W: BLOX.W, facts: [
    ['Theme', 'Bloxy summer camp · plank deck, log walls, crates, voxel pines'], ['Spawn → first cover', '9.6 st · 0.6 s @ WalkSpeed 16'], ['Spawn → center line', '78 st · 4.9 s'],
    ['Cover', '2 log walls (6.8 st full) · 2 crate pairs (6 st full) · 3 stumps (3.5 st half) · watchtower base per side'], ['Jump vs cover', '6.4 st apex clears stump sightlines, never log walls or crates']],
    fine: 'Cabins, campfire, scoreboards, lanterns and the voxel forest sit outside bounds and never block aim. No hazards or moving parts.' },
  pillow: { eyeZ: 22, name: 'Pillow Fort Park', id: 'SD_ARENA_PillowFortPark', build: buildPillow, L: ARENAS2.pillow.L, W: ARENAS2.pillow.W, facts: [
    ['Theme', 'Plush playroom · quilted court, pillow walls, blanket fort, giant sofa'], ['Layout', 'Funnel: forward walls angle toward center, the fort anchors the back middle'], ['Spawn → first cover', '≈ 10 st · 0.6 s (back pillow walls)'], ['Spawn → center line', '80 st · 5.0 s'],
    ['Cover', '6 pillow walls (7 st full) · fort (7.4 st full, landmark) · 3 beanbags (3.5 st half) · 4 plush blocks (4.4 st half) per side'], ['Jump vs cover', '6.4 st apex clears beanbags and blocks, never pillow walls']],
    fine: 'Bolster pillows mark the boundary. Sofa, giant squishies, toy shelf, string lights and hanging stars are outside bounds or overhead and never block aim.' },
  reef: { eyeZ: 22, name: 'Bubble Reef Court', id: 'SD_ARENA_BubbleReefCourt', build: buildReef, L: ARENAS2.reef.L, W: ARENAS2.reef.W, facts: [
    ['Theme', 'Dry aquarium court · sponge walls, giant clam, sea-glass pillars, brain coral'], ['Symmetry', 'Rotational 180°: each team’s left flank matches the other’s right'], ['Spawn → first cover', '≈ 8 st · 0.5 s (brain coral)'], ['Spawn → center line', '84 st · 5.3 s'],
    ['Cover', '3 sponge walls (7 st full) · giant clam (8.6 st full, landmark) · 2 sea-glass pillars (9.6 st full, narrow) · 3 brain corals (3.4 st half) per side'], ['Jump vs cover', '6.4 st apex clears brain coral, never sponge walls or pillars']],
    fine: 'Aquarium tanks, kelp, fish and bubbles are decoration behind glass: no swimming, no water hazard. Pebbles mark the boundary.' },
  arcade: { eyeZ: 22, name: 'Arcade Toyworks', id: 'SD_ARENA_ArcadeToyworks', build: buildArcade, L: ARENAS2.arcade.L, W: ARENAS2.arcade.W, facts: [
    ['Theme', 'Toy workshop arcade · studded brick walls, cabinets, claw machine'], ['Layout', 'Staggered grid: the tightest of the five, faster rounds'], ['Spawn → first cover', '≈ 10 st · 0.6 s (toy blocks)'], ['Spawn → center line', '76 st · 4.8 s'],
    ['Cover', '4 brick walls (7.5 st full) · 2 cabinet pairs (9.4 st full) · claw machine (18 st full, landmark) · 4 toy blocks (5 st half) per side'], ['Jump vs cover', '6.4 st apex clears toy blocks, never bricks or cabinets']],
    fine: 'Conveyor, prize counter, gumball machines and marquees are decorative only and sit outside bounds. Glowing accents stay on props, never on the floor.' },
};
const arenaCams = (d) => ({ Overview: [V3(-22, 24, 44), V3(9, 0, 4)], Plan: [V3(9, 72, 0.01), V3(9, 0, 0)], 'Team A eye': [V3(-(d.L / 2 + 4) * S, 9 * S, (d.eyeZ ?? 0) * S), V3(-30 * S, 3 * S, 0)], 'Team B eye': [V3((d.L / 2 + 4) * S, 9 * S, -(d.eyeZ ?? 0) * S), V3(30 * S, 3 * S, 0)] });
function viewArena() {
  cleanup(); V.name = 'arena'; setTabs('arena');
  const d = ARENA_DEFS[state.arena] || ARENA_DEFS.sweet, cams = arenaCams(d); V.arenaCams = cams;
  stage.setAttribute('name', d.id);
  const ar = d.build(); V.ar = ar;
  stage.setObject(ar.root); stage._ground.visible = false;
  ar.root.traverse((o) => { if (o.isMesh && o.userData.noShadow) o.castShadow = false; });
  key.position.copy(KEY_POS).multiplyScalar(9); shadowSpan(42, 400); setShadowRes(4096);
  deco.add(ar.annot); deco.add(ar.proxies); ar.proxies.visible = false;
  V.dimLabels = ar.labels.map((l) => { const L = addLabel(l.t, () => l.p, 'dim'); L.on = false; return L; }); ar.annot.visible = false;
  V.sim = new ArenaSim({ scene, fx, sfx, protoToy: proto, toyIds: CATALOG.map((c) => c.id), catalog: CATALOG, bounds: { hx: d.L / 2 - 3, hz: d.W / 2 - 3, y0: ar.deckY || 0 } });
  V.sim.g.traverse((o) => { if (o.isMesh) o.castShadow = true; });
  V.camKey = 'Overview'; tweenCam(...cams.Overview, 0.01);
  const L = d.L, W = d.W;
  const facts = [['Playable', `${L} × ${W} st (${(L * S).toFixed(1)} × ${(W * S).toFixed(1)} m)`], ['Per team half', `${L / 2} × ${W} st ≈ ${Math.round((L / 2) * W / 5)} st² per player`], ['Longest sightline', `${Math.round(Math.hypot(L, W))} st diagonal`], ...d.facts];
  panel.innerHTML = `
    <h2>${d.name} · 5v5</h2>
    <div class="seg" role="group" aria-label="Arena">${Object.entries(ARENA_DEFS).map(([k, a]) => `<button data-arena="${k}" class="${k === state.arena ? 'on' : ''}">${a.name}</button>`).join('')}</div>
    <p class="sub">Mirrored or rotational split-court for 5 v 5. Every dimension below is proposed balance and needs playtesting.</p>
    <div class="seg" role="group" aria-label="Camera">${Object.keys(cams).map((k) => `<button data-acam="${k}" class="${k === 'Overview' ? 'on' : ''}">${k}</button>`).join('')}</div>
    <div class="seg" role="group" aria-label="Layers"><button data-layer="sim" class="on">10-player sim</button><button data-layer="dims">Dimensions</button><button data-layer="proxies">Collision proxies</button></div>
    <div class="density"><div><span>Particles</span><b id="dP">0</b><i><em id="dPb"></em></i><small>budget 400</small></div><div><span>Trails</span><b id="dR">0</b><i><em id="dRb"></em></i><small>budget 12</small></div><div><span>Throws / hits</span><b id="dH">0 / 0</b></div></div>
    <div class="facts">${facts.map(([k, v]) => `<div><span>${k}</span><b>${v}</b></div>`).join('')}</div>
    <p class="fine">Center line = visual marking + assumed movement boundary (translucent plane). ${d.fine}</p>`;
}

/* ======================= LOBBY ======================= */
const LOBBY_CAMS = { 'Overview A': [V3(-27, 30, 36), V3(0, 0, 3)], 'Overview B': [V3(30, 27, -36), V3(0, 0, -3)], Plan: [V3(0, 80, 0.01), V3(0, 0, 0)], 'Spawn eye': [V3(0, 1.55, 3.4), V3(0, 1.6, -12)] };
const LC = () => (V.lobby && V.lobby.cams) || LOBBY_CAMS;
function viewLobby() {
  cleanup(); V.name = 'lobby'; setTabs('lobby');
  const isl = state.lobby !== 'plaza';
  stage.setAttribute('name', isl ? 'SD_SQUISH_ISLAND' : 'SD_LOBBY');
  const lb = isl ? buildIsland() : buildLobby(); V.lobby = lb; V.station = null;
  stage.setObject(lb.root); stage._ground.visible = false;
  key.position.copy(KEY_POS).multiplyScalar(lb.light || 9); shadowSpan(lb.shadow || 40, lb.far || 400); setShadowRes(4096);
  if (lb.sky) { V.bg = scene.background; scene.background = new THREE.Color(lb.sky); scene.fog = new THREE.Fog(lb.sky, lb.fog[0], lb.fog[1]); }
  if (lb.clip) { camera.near = lb.clip[0]; camera.far = lb.clip[1]; camera.updateProjectionMatrix(); }
  deco.add(lb.annot); lb.annot.visible = false;
  V.stLabels = lb.labels.map((l) => { const L = addLabel(`<b>${l.t}</b>`, () => l.p, 'stn'); L.el.style.pointerEvents = 'auto'; L.el.onclick = () => focusStation(l.id); return L; });
  tweenCam(...panelShift(LC()['Overview A']), 0.01);
  renderLobbyPanel(null);
}
function panelShift([p, t, fixed]) { if (fixed) return [p.clone(), t.clone()]; const f = t.clone().sub(p), d = f.length(), k = Math.min(0.3, 238 / Math.max(700, innerWidth)), rt = f.normalize().cross(V3(0, 1, 0)).normalize().multiplyScalar(d * k); return [p.clone().add(rt), t.clone().add(rt)]; }
function focusStation(id, cam = 'Front') { const S0 = V.lobby.stations.find((x) => x.id === id); if (!S0) return; V.station = S0; V.stLabels.forEach((l) => (l.on = false)); tweenCam(...panelShift(S0.cams[cam]), 1.0); renderLobbyPanel(S0, cam); sfx.tick(); }
function renderLobbyPanel(S0, cam = 'Front') {
  const st = V.lobby.stations, lay = V.lobbyLayers || (V.lobbyLayers = { labels: true, foot: false, avatars: true });
  const card = S0 ? `<div class="stcard">
      <h3>${S0.name}</h3>
      <p class="sub">${S0.info.what}</p>
      <div class="seg" role="group" aria-label="Station views">${Object.keys(S0.cams).map((k) => `<button data-scam="${k}" class="${k === cam ? 'on' : ''}">${k}</button>`).join('')}</div>
      ${S0.states.length ? `<div class="seg" role="group" aria-label="States">${S0.states.map((k) => `<button data-sstate="${k}" class="${k === S0.cur ? 'on' : ''}">${k}</button>`).join('')}</div>` : ''}
      ${S0.actions ? `<div class="acts row">${S0.actions.map(([k, t]) => `<button class="big${k === 'spam' && V.lobby.spam ? ' alt' : ''}" data-lact="${k}">${k === 'spam' && V.lobby.spam ? 'Stop spam-tap' : t}</button>`).join('')}</div>` : ''}
      <div class="facts"><div><span>Footprint</span><b>${S0.info.foot}</b></div><div><span>Interaction</span><b>${S0.info.interact}</b></div><div><span>Materials</span><b>${S0.info.mats}</b></div><div><span>Preserve</span><b>${S0.info.keep}</b></div></div>
    </div>` : '<div class="facts"><div><span>Hub</span><b>232 × 184 st (65 × 52 m), walled</b></div><div><span>Promenade</span><b>Ø66 st ring with 8–11 st paths to every station</b></div><div><span>Spawn → Duel gate</span><b>≈ 50 st · 3.1 s @ WalkSpeed 16</b></div><div><span>Scale</span><b>R15 avatars at spawn, queue, shop, squeeze zone and range</b></div></div>';
  panel.innerHTML = `
    <div class="seg" role="group" aria-label="Lobby version"><button data-lvar="island" class="${state.lobby !== 'plaza' ? 'on' : ''}">Squish Island · new</button><button data-lvar="plaza" class="${state.lobby === 'plaza' ? 'on' : ''}">Candy plaza · old</button></div>
    <h2>${V.lobby.title || 'Lobby · 12 stations'}</h2>
    <p class="sub">${V.lobby.sub || 'One compact hub built from the same foam-toy kit as the arenas. Pick a station to fly there; states only swap art.'}</p>
    <div class="seg" role="group" aria-label="Lobby cameras">${Object.keys(LC()).map((k) => `<button data-lcam="${k}">${k}</button>`).join('')}</div>
    <div class="stgrid">${st.map((x, i) => `<button data-st="${x.id}" class="${S0 && S0.id === x.id ? 'on' : ''}"><span>${String(i + 1).padStart(2, '0')}</span>${x.name}</button>`).join('')}</div>
    ${S0 || !V.lobby.facts ? card : V.lobby.facts}
    <div class="seg" role="group" aria-label="Layers"><button data-llayer="labels" class="${lay.labels ? 'on' : ''}">Labels</button><button data-llayer="foot" class="${lay.foot ? 'on' : ''}">Footprints</button><button data-llayer="avatars" class="${lay.avatars ? 'on' : ''}">Avatars</button></div>
    <p class="fine">${V.lobby.fine || 'Odds, prices, rewards and requirements come from the live game; these models only present them. Export downloads the whole lobby as named meshes.'}</p>`;
}

/* ======================= input ======================= */
document.addEventListener('click', (e) => {
  const b = e.target.closest('button'); if (!b) return;
  sfx.ensure();
  if (b.dataset.view) { sfx.tick(); ({ lineup: viewLineup, inspect: () => viewInspect(), avatar: viewAvatar, lobby: viewLobby, arena: viewArena })[b.dataset.view](); return; }
  if (b.dataset.st) { focusStation(b.dataset.st); return; }
  if (b.dataset.scam && V.station) { sfx.tick(); tweenCam(...panelShift(V.station.cams[b.dataset.scam]), 0.9); renderLobbyPanel(V.station, b.dataset.scam); return; }
  if (b.dataset.sstate && V.station) { sfx.tick(); V.station.cur = b.dataset.sstate; V.station.set(b.dataset.sstate); const on = document.querySelector('[data-scam].on'); renderLobbyPanel(V.station, on ? on.dataset.scam : 'Front'); return; }
  if (b.dataset.lvar) { sfx.tick(); state.lobby = b.dataset.lvar; viewLobby(); return; }
  if (b.dataset.lact && V.lobby && V.lobby.act) { sfx.tick(); if (V.lobby.act(b.dataset.lact) && V.station) { const on = document.querySelector('[data-scam].on'); renderLobbyPanel(V.station, on ? on.dataset.scam : 'Front'); } return; }
  if (b.dataset.lcam) { sfx.tick(); V.station = null; V.stLabels.forEach((l) => (l.on = V.lobbyLayers.labels)); tweenCam(...(b.dataset.lcam === 'Plan' ? LC().Plan : panelShift(LC()[b.dataset.lcam])), 1.1); renderLobbyPanel(null); const nb = document.querySelector(`[data-lcam="${b.dataset.lcam}"]`); if (nb) nb.classList.add('on'); return; }
  if (b.dataset.llayer) { sfx.tick(); const k = b.dataset.llayer, lay = V.lobbyLayers; lay[k] = !lay[k]; b.classList.toggle('on', lay[k]); if (k === 'labels') V.stLabels.forEach((l) => (l.on = lay[k])); if (k === 'foot') V.lobby.annot.visible = lay[k]; if (k === 'avatars') V.lobby.avatars.forEach((a) => (a.holder.visible = lay[k])); return; }
  if (b.dataset.arena) { sfx.tick(); state.arena = b.dataset.arena; viewArena(); return; }
  if (b.dataset.toy) { sfx.tick(); state.toyId = b.dataset.toy; viewInspect(); return; }
  if (b.dataset.cam && V.name === 'inspect') {
    sfx.tick(); const c = controls.target.clone(), d = camera.position.distanceTo(c);
    const dirs = { Front: V3(0, 0.25, 1), '3/4': V3(1, 0.45, 1.2), Side: V3(1, 0.2, 0), Back: V3(-0.3, 0.3, -1), Top: V3(0, 1, 0.08) };
    tweenCam(c.clone().addScaledVector(dirs[b.dataset.cam].normalize(), d), c, 0.6); return;
  }
  if (b.dataset.dash) { avDash(b.dataset.dash); return; }
  if (b.dataset.speed) { timeScale = +b.dataset.speed; document.querySelectorAll('[data-speed]').forEach((x) => x.classList.toggle('on', x === b)); sfx.tick(); return; }
  if (b.dataset.sheet) { sfx.tick(); showSheet(b.dataset.sheet); return; }
  if (b.dataset.acam) { sfx.tick(); V.camKey = b.dataset.acam; tweenCam(...V.arenaCams[b.dataset.acam], 1.0); document.querySelectorAll('[data-acam]').forEach((x) => x.classList.toggle('on', x === b)); return; }
  if (b.dataset.layer) {
    sfx.tick(); const on = !b.classList.contains('on'); b.classList.toggle('on', on);
    if (b.dataset.layer === 'sim') { V.sim.on = on; V.sim.g.visible = on; if (!on) fx.clear(); }
    if (b.dataset.layer === 'dims') { V.ar.annot.visible = on; V.dimLabels.forEach((l) => (l.on = on)); }
    if (b.dataset.layer === 'proxies') V.ar.proxies.visible = on;
    return;
  }
  const a = b.dataset.act;
  if (a === 'prev' || a === 'next') { sfx.tick(); const i = CATALOG.findIndex((c) => c.id === state.toyId); state.toyId = CATALOG[(i + (a === 'next' ? 1 : CATALOG.length - 1)) % CATALOG.length].id; viewInspect(); }
  if (a === 'throw') startThrow(false);
  if (a === 'ult') startThrow(true);
  if (a === 'spin') { controls.autoRotate = !controls.autoRotate; b.classList.toggle('on', controls.autoRotate); }
  if (a === 'jump') avJump(false);
  if (a === 'runjump') avJump(true);
  if (a === 'athrow') avThrow();
  if (a === 'holdtoggle') { V.an.hold = !V.an.hold; V.toyMesh.visible = V.an.hold; b.classList.toggle('on', V.an.hold); b.textContent = V.an.hold ? 'Holding' : 'Empty hands'; }
  if (a === 'sound') { state.sound = !state.sound; sfx.on = state.sound; b.classList.toggle('on', state.sound); b.textContent = state.sound ? 'Sound on' : 'Sound off'; }
  if (a === 'shake') { state.shake = !state.shake; fx.shakeOn = state.shake; b.classList.toggle('on', state.shake); b.textContent = state.shake ? 'Shake on' : 'Shake off'; }
  if (a === 'quality') { state.quality = state.quality === 'High' ? 'Low' : 'High'; fx.quality = state.quality === 'High' ? 1 : 0.5; b.textContent = 'VFX ' + state.quality; }
});
window.addEventListener('keydown', (e) => {
  if (e.repeat || e.target.closest('input,textarea')) return;
  sfx.ensure();
  const k = e.key;
  if (k >= '1' && k <= '5') { ({ 1: viewLineup, 2: () => viewInspect(), 3: viewAvatar, 4: viewLobby, 5: viewArena })[k](); return; }
  if (V.name === 'inspect') {
    if (k === ' ') { e.preventDefault(); squeezeOn(); }
    if (k === 't' || k === 'T') startThrow(false);
    if ((k === 'u' || k === 'U') && state.toyId === 'Dragon') startThrow(true);
    if (k === 'ArrowRight' || k === 'ArrowLeft') { const i = CATALOG.findIndex((c) => c.id === state.toyId); state.toyId = CATALOG[(i + (k === 'ArrowRight' ? 1 : CATALOG.length - 1)) % CATALOG.length].id; viewInspect(); }
  } else if (V.name === 'avatar') {
    const m = { ArrowUp: 'F', ArrowDown: 'B', ArrowLeft: 'L', ArrowRight: 'R' };
    if (m[k]) { e.preventDefault(); avDash(m[k]); }
    if (k === ' ') { e.preventDefault(); avJump(false); }
    if (k === 'j' || k === 'J') avJump(true);
    if (k === 'f' || k === 'F') avThrow();
  }
});
window.addEventListener('keyup', (e) => { if (e.key === ' ' && V.name === 'inspect') squeezeOff(); });
const ray = new THREE.Raycaster(), ndc = new THREE.Vector2();
let downAt = null;
function labRay(e) { const r = stage.getBoundingClientRect(); ndc.set(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1); ray.setFromCamera(ndc, camera); }
function labHit(e) {
  labRay(e);
  for (const h of ray.intersectObject(V.toy.root, true)) { const p = V.soft.restHit(h); if (p) return p; }
  return null;
}
stage.addEventListener('pointerdown', (e) => {
  sfx.ensure(); downAt = { x: e.clientX, y: e.clientY };
  if (V.name !== 'inspect' || V.throw || !V.soft) return;
  const h = labHit(e);
  if (h) { controls.enabled = false; V.finger = true; V.soft.fingerDown(h); }
});
window.addEventListener('pointermove', (e) => { if (V.name === 'inspect' && V.finger && V.soft) { const h = V.soft.pulling ? null : labHit(e); if (h) V.soft.fingerMove(h); else { labRay(e); V.soft.pullTo(ray.ray); } } });
window.addEventListener('pointerup', () => { if (V.name === 'inspect') { squeezeOff(); if (V.finger) { V.finger = false; V.soft.fingerUp(); } controls.enabled = true; } downAt = null; });

/* ======================= loop ======================= */
const clock = new THREE.Clock();
let densT = 0;
function loop() { requestAnimationFrame(loop); frame(Math.min(0.05, clock.getDelta())); }
window.SD = { advance(sec = 0.5) { for (let t = 0; t < sec; t += 1 / 60) frame(1 / 60); controls.update(); stage._renderer.render(scene, camera); }, V: () => V, state };
function frame(raw) {
  const dt = raw * timeScale;
  fxNow += dt;
  if (camTw) { camTw.t += raw; const k = ease(camTw.t / camTw.dur); camera.position.lerpVectors(camTw.p0, camTw.p1, k); controls.target.lerpVectors(camTw.t0, camTw.t1, k); controls.update(); if (camTw.t >= camTw.dur) camTw = null; }
  if (V.name === 'lineup') {
    V.sq.forEach((q, i) => { q.update(raw); V.toys[i].squash.scale.y *= 1 + 0.008 * Math.sin(fxNow * 2 + i); });
    V.auto -= raw; if (V.auto <= 0) { V.auto = 1.8 + Math.random() * 1.6; const i = (Math.random() * V.sq.length) | 0; const q = V.sq[i]; q.press(); setTimeout(() => q.release(), 260); }
  }
  if (V.name === 'inspect') {
    V.sq.update(raw); V.soft.update(raw); if (V.throw) updateThrow(raw);
    const bar = $('#sqBar'), tx = $('#sqTxt');
    if (bar) { const c = Math.max(0, 1 - V.sq.y) / (1 - V.toy.meta.squeeze.depth); bar.style.width = Math.min(100, c * 100).toFixed(0) + '%'; tx.textContent = `${V.sq.phase[0].toUpperCase() + V.sq.phase.slice(1)} · ${Math.round(Math.max(0, 1 - V.sq.y) * 100)}%`; }
  }
  if (V.target) { const T = V.target; const a = -60 * T.a - 5 * T.v; T.v += a * dt; T.a += T.v * dt; T.wob.rotation.z = T.a * 0.12 * T.face; }
  if (V.name === 'avatar') updateAvatar(dt);
  if (V.name === 'lobby' && V.lobby) { V.lobby.avatars.forEach((a) => a.an.update(dt)); if (V.lobby.update) V.lobby.update(dt, popAt); }
  if (V.name === 'arena' && V.ar && V.ar.flames) { const f = V.ar.flames, tt = fxNow; f.scale.set(1 + 0.08 * Math.sin(tt * 13), 1 + 0.14 * Math.sin(tt * 9), 1 + 0.08 * Math.cos(tt * 11)); f.rotation.y += raw * 0.6; }
  if (V.name === 'arena' && V.sim) {
    V.sim.update(raw, camera, fxNow, DragonHead);
    densT -= raw; if (densT <= 0) { densT = 0.25; const s = fx.stats(); const set = (id, v) => { const el = $(id); if (el) el.textContent = v; }; set('#dP', s.particles); set('#dR', s.ribbons); set('#dH', `${V.sim.throws} / ${V.sim.hits}`); const pb = $('#dPb'), rb = $('#dRb'); if (pb) { pb.style.width = Math.min(100, (s.particles / 400) * 100) + '%'; pb.classList.toggle('over', s.particles > 400); rb.style.width = Math.min(100, (s.ribbons / 12) * 100) + '%'; rb.classList.toggle('over', s.ribbons > 12); } }
  }
  fx.update(dt, camera, fxNow);
  if (toastT > 0) { toastT -= raw; if (toastT <= 0) toast.classList.remove('on'); }
  const r = stage.getBoundingClientRect(), v = V3(); camera.updateMatrixWorld();
  for (const L of labels) {
    if (!L.on) { L.el.style.display = 'none'; continue; }
    v.copy(L.getPos()).project(camera);
    if (v.z > 1 || v.z < -1) { L.el.style.display = 'none'; continue; }
    L.el.style.display = '';
    L.el.style.transform = `translate(${((v.x + 1) / 2) * r.width}px, ${((1 - v.y) / 2) * r.height}px) translate(-50%, -100%)`;
  }
}
viewLineup();
loop();
document.body.classList.add('ready');
