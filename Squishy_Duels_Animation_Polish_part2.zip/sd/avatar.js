import { THREE, V3, mat, mesh, group, warpSphere, superF, face } from './kit.js';
import { toonify } from './toon.js';

export const JOINTS = ['root', 'waist', 'neck', 'lShoulder', 'lElbow', 'lWrist', 'rShoulder', 'rElbow', 'rWrist', 'lHip', 'lKnee', 'lAnkle', 'rHip', 'rKnee', 'rAnkle'];
export const ROBLOX_NAMES = { root: 'Root (LowerTorso)', waist: 'Waist (UpperTorso)', neck: 'Neck (Head)', lShoulder: 'LeftShoulder', lElbow: 'LeftElbow', lWrist: 'LeftWrist', rShoulder: 'RightShoulder', rElbow: 'RightElbow', rWrist: 'RightWrist', lHip: 'LeftHip', lKnee: 'LeftKnee', lAnkle: 'LeftAnkle', rHip: 'RightHip', rKnee: 'RightKnee', rAnkle: 'RightAnkle' };
const GC = new Map();
function rbox(w, h, d, S, n = 6) { const k = [w, h, d, S, n].join(); if (!GC.has(k)) GC.set(k, warpSphere(superF((w / 2) * S, (h / 2) * S, (d / 2) * S, n, n), 28, 20)); return GC.get(k); }

export function buildAvatar(o = {}) {
  const S = o.S ?? 0.28;
  const team = o.team || 'mint';
  const shirtHex = team === 'mint' ? 0x5FD3AE : 0xF2687F;
  const M = {
    skin: mat('avatar_skin', 0xE9BB92, 0.75), shirt: mat('jersey_' + team, shirtHex, 0.7), stripe: mat('jersey_stripe', 0xFFF8EE, 0.7),
    pants: mat('avatar_pants', 0x3F3756, 0.78), shoe: mat('avatar_shoe', 0xFFF8EE, 0.6), sole: mat('sole_' + team, shirtHex, 0.6), band: mat('band_' + team, shirtHex, 0.6),
  };
  const root = group(o.name || 'Avatar_R15');
  const hrp = group('HumanoidRootPart', root, [0, 2.85 * S, 0]);
  const J = {};
  const s = (a) => a.map((v) => v * S);
  J.root = group('Root', hrp);
  mesh(rbox(2, 0.42, 1, S), M.pants, 'LowerTorso', J.root);
  J.waist = group('Waist', J.root, s([0, 0.2, 0]));
  mesh(rbox(2, 1.6, 1, S), M.shirt, 'UpperTorso', J.waist, s([0, 0.8, 0]));
  mesh(rbox(2.04, 0.22, 1.04, S, 8), M.stripe, 'jersey_stripe', J.waist, s([0, 1.0, 0]));
  const badge = team === 'mint' ? new THREE.CylinderGeometry(0.22 * S, 0.22 * S, 0.06 * S, 24).rotateX(Math.PI / 2) : new THREE.BoxGeometry(0.32 * S, 0.32 * S, 0.06 * S).rotateZ(Math.PI / 4);
  mesh(badge, M.stripe, 'team_badge', J.waist, s([0.45, 1.3, 0.52]));
  mesh(badge, M.stripe, 'team_badge_back', J.waist, s([0, 1.0, -0.52]), null, 1.8);
  J.neck = group('Neck', J.waist, s([0, 1.6, 0]));
  const head = mesh(rbox(1.25, 1.2, 1.2, S, 3.4), M.skin, 'Head', J.neck, s([0, 0.62, 0]));
  mesh(new THREE.TorusGeometry(0.6 * S, 0.09 * S, 10, 40), M.band, 'headband', J.neck, s([0, 0.95, 0]), [Math.PI / 2 - 0.08, 0, 0], [1.04, 1, 1]);
  const arm = (side) => {
    const x = side === 'l' ? 1.5 : -1.5;
    const sh = (J[side + 'Shoulder'] = group((side === 'l' ? 'Left' : 'Right') + 'Shoulder', J.waist, s([x, 1.4, 0])));
    mesh(rbox(0.95, 1.17, 0.95, S), M.shirt, (side === 'l' ? 'Left' : 'Right') + 'UpperArm', sh, s([0, -0.385, 0]));
    const el = (J[side + 'Elbow'] = group((side === 'l' ? 'Left' : 'Right') + 'Elbow', sh, s([0, -0.97, 0])));
    mesh(rbox(0.9, 1.05, 0.9, S), M.skin, (side === 'l' ? 'Left' : 'Right') + 'LowerArm', el, s([0, -0.525, 0]));
    const wr = (J[side + 'Wrist'] = group((side === 'l' ? 'Left' : 'Right') + 'Wrist', el, s([0, -1.05, 0])));
    mesh(rbox(0.92, 0.34, 0.92, S, 4), M.skin, (side === 'l' ? 'Left' : 'Right') + 'Hand', wr, s([0, -0.16, 0]));
  };
  arm('l'); arm('r');
  const leg = (side) => {
    const x = side === 'l' ? 0.5 : -0.5, N = side === 'l' ? 'Left' : 'Right';
    const hp = (J[side + 'Hip'] = group(N + 'Hip', J.root, s([x, -0.2, 0])));
    mesh(rbox(0.98, 1.2, 1, S), M.pants, N + 'UpperLeg', hp, s([0, -0.6, 0]));
    const kn = (J[side + 'Knee'] = group(N + 'Knee', hp, s([0, -1.2, 0])));
    mesh(rbox(0.94, 1.15, 0.94, S), M.pants, N + 'LowerLeg', kn, s([0, -0.575, 0]));
    const an = (J[side + 'Ankle'] = group(N + 'Ankle', kn, s([0, -1.15, 0])));
    mesh(rbox(1, 0.3, 1.25, S, 4), M.shoe, N + 'Foot', an, s([0, -0.15, 0.12]));
    mesh(rbox(1.02, 0.1, 1.27, S, 6), M.sole, N + 'FootSole', an, s([0, -0.27, 0.12]));
  };
  leg('l'); leg('r');
  root.updateMatrixWorld(true);
  const tmp = group('tmp', root);
  face(tmp, [head], { y: 5.32 * S, dx: 0.24 * S, eyeR: 0.1 * S, eyes: 'dot', mouth: 'smile', mw: 0.13 * S, my: 0.3 * S, mt: 0.028 * S, bx: 0.4 * S, by: 0.18 * S, br: 0.09 * S, s: 1 });
  root.updateMatrixWorld(true);
  [...tmp.children].forEach((c) => J.neck.attach(c));
  root.remove(tmp);
  const grip = group('RightGripAttachment', J.rWrist, s([0, -0.34, 0]));
  grip.rotation.x = 1.75;
  if (o.toon !== false) toonify(root, { width: o.outline ?? 2.2 });
  return { root, hrp, J, grip, S, team, head };
}

/* ---------- poses ---------- */
const D = Math.PI / 180;
export function pose(o = {}) { const p = { off: o.off ? o.off.slice() : [0, 0, 0] }; for (const j of JOINTS) p[j] = o[j] ? [o[j][0] || 0, o[j][1] || 0, o[j][2] || 0] : [0, 0, 0]; return p; }
export function lerpP(a, b, t, out = pose()) { for (const j of JOINTS) for (let i = 0; i < 3; i++) out[j][i] = a[j][i] + (b[j][i] - a[j][i]) * t; for (let i = 0; i < 3; i++) out.off[i] = a.off[i] + (b.off[i] - a.off[i]) * t; return out; }
function mirror(p) {
  const m = pose(p);
  const sw = (a, b) => { const t = m[a]; m[a] = m[b]; m[b] = t; };
  sw('lHip', 'rHip'); sw('lKnee', 'rKnee'); sw('lAnkle', 'rAnkle');
  for (const j of ['root', 'waist', 'neck', 'lHip', 'lKnee', 'lAnkle', 'rHip', 'rKnee', 'rAnkle']) { m[j][1] *= -1; m[j][2] *= -1; }
  m.lShoulder = [p.lShoulder[0] * 0.6, 0, 10 + Math.max(0, -p.lShoulder[2]) * 0.2]; m.lElbow = [Math.min(-20, p.lElbow[0]), 0, 0];
  m.off[0] *= -1; return m;
}
const READY = { root: [3], lHip: [-3], rHip: [2], lKnee: [8], rKnee: [8], lAnkle: [-4], rAnkle: [-6], lShoulder: [5, 0, 9], lElbow: [-14] };
export const KEY_LABELS = ['Start / compression', 'Push-off', 'Peak burst', 'Decel / plant', 'Recovery'];
const DASH_F = [
  { f: 0, p: pose({ off: [0, -0.32, 0], root: [10], waist: [8], neck: [-14], lHip: [-30], lKnee: [55], lAnkle: [-20], rHip: [-5], rKnee: [50], rAnkle: [-15], lShoulder: [20, 0, 12], lElbow: [-35] }), hold: [0] },
  { f: 2, p: pose({ off: [0, -0.3, 0.15], root: [24], waist: [10], neck: [-28], lHip: [-62], lKnee: [80], lAnkle: [-10], rHip: [6], rKnee: [6], rAnkle: [32], lShoulder: [48, 0, 12], lElbow: [-40] }), hold: [8], ev: 'pushoff' },
  { f: 4, p: pose({ off: [0, -0.05, 0.3], root: [30], waist: [8], neck: [-34], lHip: [-70], lKnee: [85], lAnkle: [-5], rHip: [22], rKnee: [45], rAnkle: [28], lShoulder: [60, 0, 14], lElbow: [-30] }), hold: [14] },
  { f: 7, p: pose({ off: [0, -0.28, 0.05], root: [4], waist: [-10], neck: [4], lHip: [-40], lKnee: [32], lAnkle: [18], rHip: [14], rKnee: [62], rAnkle: [-6], lShoulder: [-25, 0, 20], lElbow: [-55] }), hold: [-10], ev: 'plant' },
  { f: 12, p: pose(Object.assign({ off: [0, -0.04, 0] }, READY)), hold: [0] },
];
const DASH_B = [
  { f: 0, p: pose({ off: [0, -0.3, 0], root: [-6], waist: [-4], neck: [10], lHip: [-10], lKnee: [50], lAnkle: [-20], rHip: [-25], rKnee: [55], rAnkle: [-20], lShoulder: [-10, 0, 14], lElbow: [-40] }), hold: [0] },
  { f: 2, p: pose({ off: [0, -0.22, -0.15], root: [-16], waist: [-6], neck: [22], lHip: [-10], lKnee: [8], lAnkle: [24], rHip: [30], rKnee: [50], rAnkle: [-6], lShoulder: [-30, 0, 18], lElbow: [-45] }), hold: [-8], ev: 'pushoff' },
  { f: 4, p: pose({ off: [0, -0.05, -0.3], root: [-20], waist: [-6], neck: [26], lHip: [-20], lKnee: [30], lAnkle: [10], rHip: [40], rKnee: [35], rAnkle: [-10], lShoulder: [-40, 0, 20], lElbow: [-50] }), hold: [-12] },
  { f: 7, p: pose({ off: [0, -0.3, -0.05], root: [8], waist: [4], neck: [-12], lHip: [-30], lKnee: [45], lAnkle: [-10], rHip: [18], rKnee: [20], rAnkle: [-5], lShoulder: [15, 0, 16], lElbow: [-40] }), hold: [8], ev: 'plant' },
  { f: 12, p: pose(Object.assign({ off: [0, -0.04, 0] }, READY)), hold: [0] },
];
const DASH_L = [
  { f: 0, p: pose({ off: [-0.1, -0.3, 0], root: [4, 0, 8], waist: [4, 0, 4], neck: [-8, 0, -12], lHip: [-10, 0, 8], lKnee: [45], lAnkle: [-15, 0, -6], rHip: [-10, 0, -14], rKnee: [45], rAnkle: [-15, 0, 10], lShoulder: [10, 0, 20], lElbow: [-30] }), hold: [0] },
  { f: 2, p: pose({ off: [0.15, -0.25, 0], root: [6, 0, -20], waist: [2, 0, -6], neck: [-8, 0, 26], lHip: [-10, 0, 34], lKnee: [40], lAnkle: [0, 0, -14], rHip: [-4, 0, -4], rKnee: [6], rAnkle: [10, 0, 14], lShoulder: [0, 0, 55], lElbow: [-20] }), hold: [4], ev: 'pushoff' },
  { f: 4, p: pose({ off: [0.3, -0.05, 0], root: [6, 0, -28], waist: [0, 0, -6], neck: [-6, 0, 34], lHip: [-12, 0, 40], lKnee: [30], lAnkle: [0, 0, -16], rHip: [0, 0, 8], rKnee: [20], rAnkle: [0, 0, 10], lShoulder: [0, 0, 70], lElbow: [-15] }), hold: [8] },
  { f: 7, p: pose({ off: [0.1, -0.28, 0], root: [4, 0, -6], waist: [0, 0, 4], neck: [-4, 0, 2], lHip: [-8, 0, 22], lKnee: [45], lAnkle: [-15, 0, -16], rHip: [-6, 0, -4], rKnee: [35], lShoulder: [0, 0, 30], lElbow: [-30] }), hold: [-6], ev: 'plant' },
  { f: 12, p: pose(Object.assign({ off: [0, -0.04, 0] }, READY)), hold: [0] },
];
const DASH_R = DASH_L.map((k) => ({ f: k.f, p: mirror(k.p), hold: k.hold, ev: k.ev }));
export const DASH = { F: DASH_F, B: DASH_B, L: DASH_L, R: DASH_R };
export const DASH_DIR = { F: [0, 0, 1], B: [0, 0, -1], L: [1, 0, 0], R: [-1, 0, 0] };
export const JUMP = {
  TAKEOFF: pose({ off: [0, -0.15, 0], root: [6], waist: [4], neck: [-10], lHip: [-6], lKnee: [10], lAnkle: [30], rHip: [-4], rKnee: [8], rAnkle: [28], lShoulder: [-70, 0, 16], lElbow: [-30] }),
  RISE: pose({ off: [0, 0.05, 0], root: [2], neck: [-2], lHip: [-42], lKnee: [62], lAnkle: [-8], rHip: [-12], rKnee: [34], rAnkle: [10], lShoulder: [-50, 0, 24], lElbow: [-35] }),
  APEX: pose({ off: [0, 0.1, 0], lHip: [-48], lKnee: [74], rHip: [-30], rKnee: [58], lShoulder: [-30, 0, 32], lElbow: [-40] }),
  FALL: pose({ off: [0, 0, 0], root: [-2], neck: [4], lHip: [-22], lKnee: [26], lAnkle: [-14], rHip: [-8], rKnee: [18], rAnkle: [-12], lShoulder: [-10, 0, 40], lElbow: [-25] }),
  LAND: pose({ off: [0, -0.58, 0], root: [14], waist: [10], neck: [-20], lHip: [-50], lKnee: [88], lAnkle: [-38], rHip: [-44], rKnee: [80], rAnkle: [-36], lShoulder: [-20, 0, 22], lElbow: [-45] }),
};
export const JUMP_LABELS = ['Takeoff', 'Rising', 'Apex', 'Falling', 'Land / compress'];
const HOLD = { rShoulder: [-30, 0, -6], rElbow: [-75, 0, 0], rWrist: [0, 0, 0] };
const THROW = [
  { f: 0, p: { rShoulder: [-30, 0, -6], rElbow: [-75], waist: [0], lShoulder: [5, 0, 9], lElbow: [-14] } },
  { f: 4, p: { rShoulder: [-165, 0, -18], rElbow: [-80], waist: [-4, -30, 0], neck: [0, 30, 0], lShoulder: [-70, 0, 18], lElbow: [-10] } },
  { f: 6, p: { rShoulder: [-120, 0, -10], rElbow: [-18], waist: [8, 18, 0], neck: [0, -18, 0], lShoulder: [-30, 0, 20], lElbow: [-40] }, ev: 'release' },
  { f: 10, p: { rShoulder: [-40, 0, 10], rElbow: [-20], waist: [14, 26, 0], neck: [-10, -26, 0], lShoulder: [20, 0, 14], lElbow: [-50] } },
  { f: 20, p: { rShoulder: [-30, 0, -6], rElbow: [-75], waist: [0], lShoulder: [5, 0, 9], lElbow: [-14] } },
];
const UPPER = ['waist', 'neck', 'lShoulder', 'lElbow', 'rShoulder', 'rElbow', 'rWrist'];
const ease = (t) => 0.5 - 0.5 * Math.cos(Math.PI * t);

export function sampleKeys(keys, frame, out = pose()) {
  if (frame <= keys[0].f) return lerpP(keys[0].p, keys[0].p, 0, out);
  for (let i = 0; i < keys.length - 1; i++) {
    const a = keys[i], b = keys[i + 1];
    if (frame <= b.f) { const t = (frame - a.f) / (b.f - a.f); out.holdX = a.hold ? a.hold[0] + ((b.hold ? b.hold[0] : 0) - a.hold[0]) * ease(t) : 0; return lerpP(a.p, b.p, ease(t), out); }
  }
  const l = keys[keys.length - 1]; out.holdX = 0; return lerpP(l.p, l.p, 0, out);
}

export class Animator {
  constructor(av) {
    this.av = av; this.t = 0; this.phase = 0; this.speed = 0; this.hold = true;
    this.dash = null; this.air = null; this.land = null; this.throwT = -1; this.onEvent = null;
    this.cur = pose(); this._a = pose(); this._b = pose(); this.state = 'Idle';
    this.v0 = 50; this.g = 196.2;
  }
  startDash(dir) { this.dash = { dir, f: 0, fired: {} }; this.state = 'Dash ' + dir; }
  startJump() { this.air = { vy: this.v0, y: 0, t: 0 }; this.land = null; this.ev('takeoff'); }
  startThrow() { this.throwT = 0; this.thrFired = {}; }
  ev(n, d) { this.onEvent && this.onEvent(n, d); }
  get airborne() { return !!this.air; }
  update(dt) {
    this.t += dt;
    const P = this.cur;
    const run = Math.min(1, this.speed / 16);
    this.phase += dt * (Math.PI * 2) / 0.62 * Math.max(run, 0.001);
    const ph = this.phase, br = Math.sin(this.t * 2.2);
    const idle = pose(Object.assign({}, READY, { off: [0, -0.02 + 0.015 * br, 0], waist: [2 + 1.2 * br], neck: [-1.2 * br], lShoulder: [5 + br, 0, 9] }));
    const sF = Math.sin(ph), cF = Math.cos(ph);
    const runP = pose({ off: [0, -0.06 + 0.12 * Math.abs(sF), 0], root: [10, 6 * sF, 0], waist: [4, -8 * sF, 0], neck: [-12, 2 * sF, 0], lHip: [-36 * sF], rHip: [36 * sF], lKnee: [16 + 58 * Math.max(0, cF)], rKnee: [16 + 58 * Math.max(0, -cF)], lAnkle: [-8 + 14 * sF], rAnkle: [-8 - 14 * sF], lShoulder: [32 * sF, 0, 8], lElbow: [-40 - 14 * sF] });
    lerpP(idle, runP, run, P);
    let holdAdd = 0;
    if (this.dash) {
      const d = this.dash; d.f += dt * 30;
      const keys = DASH[d.dir];
      const s = sampleKeys(keys, d.f, this._a);
      for (const k of keys) if (k.ev && d.f >= k.f && !d.fired[k.f]) { d.fired[k.f] = 1; this.ev(k.ev, d.dir); }
      const end = keys[keys.length - 1].f;
      const w = Math.min(1, d.f / 0.9) * (d.f > end - 3 ? Math.max(0, (end - d.f) / 3) : 1);
      lerpP(P, s, Math.min(1, w + (d.f < end - 3 ? 1 : 0)) * (d.f < end - 3 ? 1 : w), P);
      holdAdd += (s.holdX || 0) * w;
      if (d.f >= end) { this.dash = null; this.state = this.speed > 1 ? 'Run' : 'Idle'; }
    }
    if (this.air) {
      const a = this.air; a.t += dt; a.vy -= this.g * dt; a.y += a.vy * dt;
      const k = a.vy / this.v0;
      const s = k > 0.15 ? lerpP(JUMP.APEX, JUMP.RISE, Math.min(1, (k - 0.15) / 0.6), this._a) : lerpP(JUMP.APEX, JUMP.FALL, Math.min(1, (0.15 - k) / 0.7), this._a);
      if (a.t < 0.1) lerpP(s, JUMP.TAKEOFF, 1 - a.t / 0.1, s);
      lerpP(P, s, Math.min(1, a.t / 0.04 + 0.6), P);
      holdAdd += k > 0 ? -12 * k : 6;
      this.state = a.t < 0.1 ? 'Jump · Takeoff' : k > 0.15 ? 'Jump · Rising' : k > -0.15 ? 'Jump · Apex' : 'Jump · Falling';
      if (a.y <= 0 && a.vy < 0) { const heavy = a.vy < -this.v0 * 1.15; this.land = { t: 0, heavy, mvx: this.speed }; this.air = null; this.ev('land', heavy); }
    }
    if (this.land) {
      const l = this.land; l.t += dt;
      const w = l.t < 0.05 ? l.t / 0.05 : Math.max(0, 1 - (l.t - 0.05) / (l.heavy ? 0.3 : 0.22));
      const lp = lerpP(JUMP.LAND, JUMP.LAND, 0, this._b);
      if (l.heavy) { lp.off[1] *= 1.2; } else { lp.off[1] *= 0.85; }
      lerpP(P, lp, ease(Math.min(1, w)) * (this.speed > 1 ? 0.6 : 1), P);
      holdAdd += 6 * w;
      this.state = 'Land' + (l.heavy ? ' (heavy)' : '');
      if (w <= 0 && l.t > 0.05) { this.land = null; this.state = this.speed > 1 ? 'Run' : 'Idle'; }
    }
    if (this.hold) { for (const j in HOLD) { P[j][0] = HOLD[j][0] + (j === 'rShoulder' ? holdAdd : 0); P[j][1] = HOLD[j][1]; P[j][2] = HOLD[j][2]; } }
    if (this.throwT >= 0) {
      this.throwT += dt * 30;
      const f = this.throwT;
      let A = THROW[0], B = THROW[THROW.length - 1], tt = 1;
      for (let i = 0; i < THROW.length - 1; i++) if (f <= THROW[i + 1].f) { A = THROW[i]; B = THROW[i + 1]; tt = ease((f - A.f) / (B.f - A.f)); break; }
      for (const k of THROW) if (k.ev && f >= k.f && !this.thrFired[k.f]) { this.thrFired[k.f] = 1; this.ev(k.ev); }
      for (const j of UPPER) { const a = A.p[j], b = B.p[j]; if (!a && !b) continue; const pa = a || [0, 0, 0], pb = b || [0, 0, 0]; for (let i = 0; i < 3; i++) { const v = (pa[i] || 0) + ((pb[i] || 0) - (pa[i] || 0)) * tt; P[j][i] = j === 'waist' || j === 'neck' ? P[j][i] * 0.4 + v : v; } }
      if (f >= THROW[THROW.length - 1].f) this.throwT = -1;
    }
    this.apply(P);
  }
  apply(P) {
    const J = this.av.J, S = this.av.S;
    for (const j of JOINTS) J[j].rotation.set(P[j][0] * D, P[j][1] * D, P[j][2] * D);
    J.root.position.set(P.off[0] * S, P.off[1] * S, P.off[2] * S);
  }
  airY() { return this.air ? Math.max(0, this.air.y) : 0; }
}
export function applyPose(av, P) { const J = av.J, S = av.S; for (const j of JOINTS) J[j].rotation.set(P[j][0] * D, P[j][1] * D, P[j][2] * D); J.root.position.set(P.off[0] * S, P.off[1] * S, P.off[2] * S); for (const j in HOLD) J[j].rotation.set(HOLD[j][0] * D, HOLD[j][1] * D, HOLD[j][2] * D); }
