import { THREE, V3, mat, mesh, group, STUD, warpSphere, superF } from './kit.js';
import { CATALOG, RARITY, buildToy, byId, Squisher, toonHead } from './toys.js';
import { SFX, FX } from './fx.js';
import { buildAvatar, Animator, DASH_DIR } from './avatar.js';
import { buildBlox } from './blox.js';
import { toonify, setOutlineRes } from './toon.js';
import { ULTS, THROW_STYLE, INSPECT_NOTE } from './ults.js';
import { SoftSquish, SquishAudio, feelOf, WAX, TOY_FEEL, FLAV } from './squish.js';

const S = STUD, s = (v) => v * S, TAU = Math.PI * 2;
const $ = (q) => document.querySelector(q);
const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
const ease = (t) => 0.5 - 0.5 * Math.cos(Math.PI * clamp(t, 0, 1));
const backOut = (t) => { const c = 1.9; return 1 + (c + 1) * Math.pow(t - 1, 3) + c * Math.pow(t - 1, 2); };
const rnd = (a, b) => a + Math.random() * (b - a);
class Sp3 { constructor(k, c, p) { this.k = k; this.c = c; this.p = p ? p.clone() : V3(); this.v = V3(); }
  step(tg, dt) { const n = Math.max(1, Math.ceil(dt / (1 / 240))), h = dt / n; for (let i = 0; i < n; i++) { this.v.x += ((tg.x - this.p.x) * this.k - this.v.x * this.c) * h; this.v.y += ((tg.y - this.p.y) * this.k - this.v.y * this.c) * h; this.v.z += ((tg.z - this.p.z) * this.k - this.v.z * this.c) * h; this.p.addScaledVector(this.v, h); } return this.p; } }
class Sp1 { constructor(k, c) { this.k = k; this.c = c; this.p = 0; this.v = 0; } step(tg, dt) { const n = Math.max(1, Math.ceil(dt / (1 / 240))), h = dt / n; for (let i = 0; i < n; i++) { this.v += ((tg - this.p) * this.k - this.v * this.c) * h; this.p += this.v * h; } return this.p; } }
const kv = (tr, t) => { if (t <= tr[0][0]) return tr[0].slice(1); for (let i = 0; i < tr.length - 1; i++) { const a = tr[i], b = tr[i + 1]; if (t <= b[0]) { const u = ease((t - a[0]) / (b[0] - a[0])); return a.slice(1).map((v, j) => v + (b[j + 1] - v) * u); } } return tr[tr.length - 1].slice(1); };

/* ---------------- renderer / scenes ---------------- */
const canvas = $('#c');
const R = new THREE.WebGLRenderer({ canvas, antialias: true, preserveDrawingBuffer: true });
R.setPixelRatio(Math.min(devicePixelRatio || 1, 2)); R.shadowMap.enabled = true; R.shadowMap.type = THREE.PCFShadowMap; R.autoClear = false;
const world = new THREE.Scene(); world.background = new THREE.Color(0xBDE5FF); world.fog = new THREE.Fog(0xBDE5FF, 26, 90);
const vm = new THREE.Scene();
const cam = new THREE.PerspectiveCamera(70, 1, 0.05, 300); cam.rotation.order = 'YXZ';
const vmCam = new THREE.PerspectiveCamera(70, 1, 0.01, 10);
world.add(new THREE.HemisphereLight(0xffffff, 0x7fae5c, 1.15));
const sun = new THREE.DirectionalLight(0xfff3dc, 2.3); sun.position.set(-14, 26, 10); sun.castShadow = true; sun.shadow.mapSize.set(2048, 2048);
Object.assign(sun.shadow.camera, { left: -26, right: 26, top: 26, bottom: -26, near: 1, far: 80 }); sun.shadow.bias = -0.0005; world.add(sun); world.add(sun.target);
vm.add(new THREE.HemisphereLight(0xffffff, 0xb8c9a8, 1.1));
const vmKey = new THREE.DirectionalLight(0xfff3dc, 1.9); vmKey.position.set(-0.4, 1, 0.6); vm.add(vmKey);
const vmRim = new THREE.DirectionalLight(0xdff1ff, 0.6); vmRim.position.set(1, 0.2, -0.6); vm.add(vmRim);
function resize() { const w = innerWidth, h = innerHeight; R.setSize(w, h, false); cam.aspect = vmCam.aspect = w / h; cam.updateProjectionMatrix(); vmCam.updateProjectionMatrix(); setOutlineRes(w, h); }
addEventListener('resize', resize); resize();
const sfx = new SFX(), fx = new FX(world), vfx = new FX(vm); fx.shakeOn = vfx.shakeOn = false;
const sa = new SquishAudio(sfx);
const arena = buildBlox(); world.add(arena.root);
arena.root.traverse((o) => { if (o.isMesh && !o.userData.isOutline) { o.receiveShadow = true; o.castShadow = !/floor_base|paint|grass_patch|deck_plank|boundary/.test(o.name); } });
const FLOOR = arena.deckY;

/* ---------------- player camera ---------------- */
const yawTo = (from, x, z) => Math.atan2(-(s(x) - from.x), -(s(z) - from.z));
const SPOT = { fp: V3(s(-12), FLOOR + s(5.3), s(10)), tp: V3(s(-14), FLOOR + s(5.3), s(-10)) }, AIM = { fp: [10, 3], tp: [9, -5] }, PITCH = { fp: -0.06, tp: -0.1 };
const P = { pos: SPOT.fp.clone(), yaw: yawTo(SPOT.fp, ...AIM.fp), pitch: PITCH.fp };
const look = { yaw: new Sp1(90, 16), pitch: new Sp1(90, 16), ty: P.yaw, tp: P.pitch, auto: 0 };
look.yaw.p = P.yaw; look.pitch.p = P.pitch;
const fov = new Sp1(170, 17), kick = new Sp3(150, 15), bob = { t: 0 };
let shake = 0, hitstop = 0, timeScale = 1, T = 0;
const FWD = () => V3(-Math.sin(look.yaw.p) * Math.cos(look.pitch.p), Math.sin(look.pitch.p), -Math.cos(look.yaw.p) * Math.cos(look.pitch.p));

/* ---------------- dummies (team B) ---------------- */
const dummies = [[6, -7], [10, 6], [14.5, 9.5]].map(([x, z], i) => {
  const holder = group('dummy_' + i, world, [s(x), FLOOR, s(z)]); const lean = group('lean', holder);
  const av = buildAvatar({ team: 'strawberry', name: 'TargetDummy_' + i }); av.root.rotation.y = -Math.PI / 2; lean.add(av.root);
  av.root.traverse((o) => { if (o.isMesh && !o.userData.isOutline) o.castShadow = true; });
  const an = new Animator(av); an.hold = false; an.t = i * 1.3;
  const fN = [], fS = []; av.root.traverse((o) => { if (o.name === 'face_normal') fN.push(o); if (o.name === 'face_squish') fS.push(o); });
  return { holder, lean, av, an, fN, fS, hit: -1, home: V3(s(x), FLOOR, s(z)) };
});
const chestOf = (d) => d.holder.position.clone().add(V3(0, s(3.9), 0));

/* ---------------- viewmodel: Roblox blocky arms ---------------- */
const rb = (w, h, d, n = 7) => warpSphere(superF(w / 2, h / 2, d / 2, n, n), 28, 20);
const skin = mat('vm_skin', 0xF5CDA4, 0.7), shirt = mat('vm_sleeve_mint', 0x5FD3AE, 0.7), cuff = mat('vm_cuff', 0xFFF8EE, 0.7);
const handG = rb(0.1, 0.094, 0.112), thumbG = rb(0.036, 0.04, 0.062, 5), foreG = rb(0.09, 0.086, 0.3), sleeveG = rb(0.114, 0.11, 0.42), cuffG = rb(0.117, 0.114, 0.036, 8);
function makeArm(side) {
  const root = group('vm_arm_' + (side < 0 ? 'L' : 'R'), vm);
  mesh(handG, skin, 'vm_hand', root); mesh(thumbG, skin, 'vm_thumb', root, [-side * 0.047, 0.026, -0.02], [0, side * 0.35, 0]);
  mesh(foreG, skin, 'vm_forearm', root, [0, 0, 0.2]); mesh(cuffG, cuff, 'vm_cuff', root, [0, 0, 0.35]); mesh(sleeveG, shirt, 'vm_sleeve', root, [0, 0, 0.57]);
  toonify(root, { width: 3 });
  return { side, root, sh: V3(side * 0.5, -0.52, -0.04), sh0: V3(side * 0.5, -0.52, -0.04), pos: new Sp3(520, 40, V3(side * 0.16, -0.25, -0.46)), roll: new Sp1(300, 30) };
}
const armL = makeArm(-1), armR = makeArm(1);
function driveArm(a, tgt, roll, dt) { const H = a.pos.step(tgt, dt); a.root.position.copy(H); a.root.lookAt(a.sh); a.root.rotateZ(a.roll.step(roll, dt)); }
const REST_L = V3(-0.16, -0.23, -0.46), REST_R = V3(0.16, -0.23, -0.46), HOLD = V3(0, -0.13, -0.5), HOLD_R = V3(0, 0.25, 0);
const FOCUS = V3(0, -0.105, -0.44), FOCUS_R = V3(0.1, 0, 0), focus = new Sp1(140, 24); let focusA = 0;
const _ho = new THREE.Object3D(), _tq = V3();
function handForTip(a, tip, roll) { const off = V3(-a.side * 0.0576, 0.026, -0.049); let hp = tip.clone(); for (let i = 0; i < 3; i++) { _ho.position.copy(hp); _ho.lookAt(a.sh); _ho.rotateZ(roll); _tq.copy(off).applyQuaternion(_ho.quaternion); hp = tip.clone().sub(_tq); } return hp; }
const _ta = V3(), _tb = V3(), THUMB_ROLL = 0.4, SH_CRUNCH = [V3(-0.5, -0.56, -0.04), V3(0.5, -0.56, -0.04)], KN_CRUNCH = new THREE.Quaternion().setFromEuler(new THREE.Euler(0.45, 0, 0));
/* knead close-up (matches the reference inspect screen): toy floats big and centred, hands drop away, cursor is the fingertip; F brings both hands up for the thumb crunch */
const KN = { q: new THREE.Quaternion(), w: V3(), keep: false, settle: 0, palm: false, thumb: false, fit: null, home: new THREE.Quaternion().setFromEuler(new THREE.Euler(0.16, 0, 0)) }, kz = new Sp1(130, 23); kz.p = 1;
const _q = new THREE.Quaternion(), _e = new THREE.Euler(0, 0, 0, 'YXZ'), _v1 = V3(); let spin = null;
function kneadFit() {
  const d = 0.42, vh = 2 * d * Math.tan((vmCam.fov * Math.PI) / 360), pxu = vh / innerHeight, wide = innerWidth > 820;
  const pr = panel.getBoundingClientRect(), pk = picker.getBoundingClientRect();
  const l = wide && pk.width ? pk.right + 10 : 0, r = wide && pr.width ? pr.left - 10 : innerWidth, top = wide ? 104 : pk.height ? pk.bottom + 8 : 64, bot = wide ? innerHeight - 66 : pr.height ? pr.top - 8 : innerHeight - 66;
  const fw = Math.max(160, r - l) * pxu, fh = Math.max(140, bot - top) * pxu, sz = H.t.size, K = H.K;
  return { p: V3(((l + r) / 2 - innerWidth / 2) * pxu, -((top + bot) / 2 - innerHeight / 2) * pxu, -d), z: Math.max(1, Math.min((0.82 * fw) / (sz.x * K), (0.74 * fh) / (sz.y * K))) };
}

/* ---------------- held toy ---------------- */
const pivot = group('held_pivot', vm);
const tPos = new Sp3(420, 36, V3(0, -0.45, -0.45)), tRot = new Sp3(260, 30, HOLD_R.clone()), tSq = new Sp3(500, 30, V3(1, 1, 1));
let H = null, ACT = { kind: 'equip', t: 0 }, toyId = 'KittyBread', mode = 'fp';
function equip(id, quiet) {
  if (H) { pivot.remove(H.wrap); H.soft.dispose(); }
  toyId = id || toyId;
  const t = buildToy(toyId, { outline: 3 }); const sz = t.size, K = 0.19 / Math.max(sz.x, sz.y, sz.z);
  const wrap = group('wrap', pivot); wrap.add(t.root); t.root.position.y = -sz.y / 2;
  H = { t, wrap, K, sq: new Squisher(t), hw: (sz.x * K) / 2, hh: (sz.y * K) / 2, hd: (sz.z * K) / 2, glow: null };
  H.soft = new SoftSquish(t, { audio: sa, squisher: H.sq, pan: 0.55 }); H.soft.onCrack = crackFx;
  pivot.scale.setScalar(0.0001); pivot.visible = true; tPos.p.set(0, -0.42, -0.44); tPos.v.set(0, 0, 0);
  if (KN.keep) { KN.fit = kneadFit(); tPos.p.copy(KN.fit.p); KN.q.copy(KN.home); KN.w.set(0, 0, 0); } else KN.fit = null;
  ACT = { kind: 'equip', t: 0 }; if (!quiet) sfx.pop();
  ui();
}
function wrapRot() { for (const k of ['x', 'y', 'z']) { tRot.p[k] = ((tRot.p[k] % TAU) + TAU) % TAU; if (tRot.p[k] > Math.PI) tRot.p[k] -= TAU; } }

/* ---------------- choreography: per-toy inspect ---------------- */
const P0 = [0, 0, 0, 0, 0, 0.25, 0], HF = [1, 0, 0, 0, 0, 0, 0];
const INS = {
  KittyBread: { dur: 2.5, toy: [[0, ...P0.slice(1)], [0.35, 0, 0.05, 0.08, -0.15, 0, 0], [0.7, 0, 0.05, 0.08, -0.1, 0, 0.38], [0.9, 0, 0.05, 0.08, -0.1, 0, -0.1], [1.4, 0, 0.06, 0.06, 0, Math.PI, 0], [1.85, 0, 0.05, 0.08, -0.1, TAU, 0], [2.5, 0, 0, 0, 0, TAU + 0.25, 0]],
    hands: [[0, ...HF], [1.85, 1, 0, 0, 0, 0, 0, 0], [1.95, 1, 0, 0, 0, -0.07, 0.11, 0], [2.05, 1, 0, 0, 0, -0.07, 0.085, 0], [2.15, 1, 0, 0, 0, -0.07, 0.11, 0], [2.4, 1, 0, 0, 0, 0, 0, 0]], sq: [[0, 1, 1, 1], [1.98, 1, 1, 1], [2.05, 1.08, 0.86, 1.08], [2.2, 1, 1, 1]], ev: [[0.68, 'flick'], [2.04, 'pat']] },
  Toast: { dur: 2.2, toy: [[0, ...P0.slice(1)], [0.3, 0, 0.05, 0.05, 0, 0, 0], [0.75, 0, 0.08, 0.05, Math.PI, 0, 0], [1.2, 0, 0.05, 0.05, TAU, 0, 0], [1.9, 0, 0.03, 0.05, TAU, 0, 0], [2.2, 0, 0, 0, TAU, 0.25, 0]],
    hands: [[0, ...HF], [0.3, 0.3, 0, 0, 0, 0, 0, 0], [1.2, 0.3, 0, 0, 0, 0, 0, 0], [1.4, 1, 0, 0, 0, 0, 0, 0], [1.55, 1, 0, 0, 0, -0.06, 0.06, 0.02], [1.65, 1, 0, 0, 0, -0.06, 0.03, 0.02], [1.75, 1, 0, 0, 0, -0.06, 0.06, 0.02], [2.0, 1, 0, 0, 0, 0, 0, 0]], ev: [[0.3, 'flip'], [1.66, 'tap']] },
  Banana: { dur: 2.6, toy: [[0, ...P0.slice(1)], [0.2, 0.03, 0.02, 0.03, 0, 0, 0], [1.3, 0.03, 0.02, 0.03, 0, 0, TAU * 2], [1.7, 0.16, 0.11, 0.3, 0, -0.6, TAU * 2 + Math.PI / 2], [2.15, 0.16, 0.11, 0.3, 0, -0.6, TAU * 2 + Math.PI / 2], [2.6, 0, 0, 0, 0, 0.25, TAU * 2]],
    hands: [[0, ...HF], [0.2, 0.4, -0.05, -0.1, 0, 0.03, 0, 0], [1.3, 0.4, -0.05, -0.1, 0, 0.03, 0, 0], [1.7, 0.6, -0.1, -0.1, 0, 0.02, 0.0, 0], [2.6, 1, 0, 0, 0, 0, 0, 0]], ev: [[0.25, 'twirl'], [0.8, 'twirl'], [1.75, 'ring']] },
  Butter: { dur: 2.3, toy: [[0, ...P0.slice(1)], [0.45, 0, 0.04, 0.06, 0.75, 0, 0], [0.8, -0.05, 0.02, 0.05, 0.4, 0, 0], [1.1, 0.05, 0.02, 0.05, 0.4, 0, 0], [1.4, -0.03, 0.02, 0.05, 0.4, 0, 0], [1.8, 0, 0.03, 0.05, 0, 0.7, 0], [2.3, 0, 0, 0, 0, 0.25, 0]],
    hands: [[0, ...HF], [0.6, 1, 0.02, 0.07, 0, 0, 0, 0], [1.4, 1, 0.02, 0.07, 0, 0, 0, 0], [1.8, 1, 0, 0, 0, 0, 0, 0]], sq: [[0, 1, 1, 1], [0.8, 1.04, 0.92, 1.04], [1.1, 1.04, 0.92, 1.04], [1.4, 1, 1, 1]], ev: [[0.85, 'spread'], [1.8, 'peek']] },
  Chocolate: { dur: 2.4, toy: [[0, ...P0.slice(1)], [0.3, 0, 0.04, 0.06, 0, 0, 0], [0.6, 0, 0.04, 0.06, 0.32, 0, 0], [0.75, 0, 0.04, 0.06, -0.12, 0, 0], [0.95, 0, 0.04, 0.06, 0, 0, 0], [1.5, 0, 0.05, 0.05, 0, Math.PI, 0], [2.0, 0, 0.04, 0.06, 0, TAU, 0], [2.4, 0, 0, 0, 0, TAU + 0.25, 0]],
    hands: [[0, ...HF], [0.6, 1, 0, 0.03, 0.02, 0, 0.03, 0.02], [0.95, 1, 0, 0, 0, 0, 0, 0]], sq: [[0, 1, 1, 1], [0.6, 1, 0.94, 1], [0.75, 1, 1.03, 1], [0.9, 1, 1, 1]], ev: [[0.74, 'snap']] },
  Birdie: { dur: 2.7, toy: [[0, ...P0.slice(1)], [0.25, 0, -0.02, 0, 0, 0, 0], [0.55, 0, 0.1, 0.04, 0, 0, 0], [0.85, 0, 0.02, 0.06, 0, 0, 0], [1.2, 0, 0.03, 0.1, 0, 0, 0.3], [1.5, 0, 0.03, 0.1, 0, 0, -0.2], [1.85, 0, 0.12, 0.06, 0, Math.PI, 0], [2.2, 0, 0.02, 0.04, 0, TAU, 0], [2.7, 0, 0, 0, 0, TAU + 0.25, 0]],
    hands: [[0, ...HF], [0.3, 0.5, -0.05, -0.08, 0.02, 0.05, -0.08, 0.02], [2.3, 0.5, -0.05, -0.08, 0.02, 0.05, -0.08, 0.02], [2.7, 1, 0, 0, 0, 0, 0, 0]], sq: [[0, 1, 1, 1], [0.3, 1.06, 0.88, 1.06], [0.45, 0.94, 1.1, 0.94], [0.85, 1.1, 0.86, 1.1], [1.0, 1, 1, 1]], ev: [[0.4, 'flap'], [1.25, 'tweet'], [1.9, 'flap'], [2.2, 'flap']] },
  Donut: { dur: 2.7, toy: [[0, ...P0.slice(1)], [0.25, 0, 0.03, 0.03, 0, 0, 0], [1.3, 0, 0.03, 0.03, 0, 0, -TAU * 3], [1.75, 0, 0.13, 0.36, 0, 0, -TAU * 3], [2.2, 0, 0.13, 0.36, 0, 0, -TAU * 3], [2.7, 0, 0, 0, 0, 0.25, -TAU * 3]],
    hands: [[0, ...HF], [0.25, 0.55, 0, 0, 0, -0.05, -0.12, 0], [1.3, 0.55, 0, 0, 0, -0.05, -0.12, 0], [1.75, 0.8, -0.05, 0, 0, 0.05, 0, 0], [2.7, 1, 0, 0, 0, 0, 0, 0]], ev: [[0.3, 'twirl'], [0.9, 'twirl'], [1.8, 'peek']] },
  Dragon: { dur: 2.9, toy: [[0, ...P0.slice(1)], [0.45, 0, 0.1, 0.03, -0.2, 0, 0], [0.9, 0, 0.11, 0.03, -0.25, 0, 0], [1.3, 0, 0.08, 0.05, 0, 0, 0], [1.85, 0, 0.05, 0.05, 0, Math.PI, 0], [2.35, 0, 0.04, 0.06, 0, TAU, 0], [2.9, 0, 0, 0, 0, TAU + 0.25, 0]],
    hands: [[0, ...HF], [0.45, 1, 0, -0.02, 0, 0, -0.02, 0], [2.9, 1, 0, 0, 0, 0, 0, 0]], sq: [[0, 1, 1, 1], [0.8, 0.94, 1.12, 0.94], [1.0, 1.04, 0.95, 1.04], [1.2, 1, 1, 1]], ev: [[0.82, 'roar'], [1.9, 'flap']] },
  MochiFox: { dur: 2.6, toy: [[0, ...P0.slice(1)], [0.3, 0, 0.03, 0.05, 0, 0, 0], [0.95, 0, 0.03, 0.05, 0, 0, 0], [1.15, 0, 0.03, 0.05, 0, 0, 0], [1.5, 0, 0.03, 0.05, 0, -0.5, 0], [1.85, 0, 0.03, 0.05, 0, 0.6, 0], [2.6, 0, 0, 0, 0, 0.25, 0]],
    hands: [[0, ...HF], [0.3, 1, 0, 0, 0, 0, 0, 0], [0.95, 1, -0.07, 0.01, 0, 0.07, 0.01, 0], [1.05, 1, 0, 0, 0, 0, 0, 0]], sq: [[0, 1, 1, 1], [0.3, 1, 1, 1], [0.95, 1.6, 0.74, 0.9], [1.1, 0.85, 1.12, 1.05], [1.3, 1.05, 0.96, 1], [1.45, 1, 1, 1]], ev: [[0.35, 'stretch'], [1.0, 'snapback'], [1.5, 'swish']] },
  StrawberryFrog: { dur: 2.7, toy: [[0, ...P0.slice(1)], [0.2, 0.09, 0.0, 0, 0, -0.3, 0], [0.45, 0, 0.12, 0, 0, 0, 0], [0.7, -0.09, 0.0, 0, 0, 0.3, 0], [0.95, 0, 0.12, 0, 0, 0, 0], [1.2, 0.0, 0.02, 0.06, 0, 0, 0], [1.9, 0, 0.03, 0.06, 0, Math.PI, 0], [2.3, 0, 0.03, 0.06, 0, TAU, 0], [2.7, 0, 0, 0, 0, TAU + 0.25, 0]],
    hands: [[0, ...HF], [0.2, 0.35, -0.02, -0.06, 0, 0.02, -0.06, 0], [1.2, 0.35, -0.02, -0.06, 0, 0.02, -0.06, 0], [1.5, 1, 0, 0, 0, 0, 0, 0]], sq: [[0, 1, 1, 1], [0.2, 1.1, 0.85, 1.1], [0.3, 0.92, 1.12, 0.92], [0.7, 1.1, 0.85, 1.1], [0.8, 0.92, 1.12, 0.92], [1.2, 1.08, 0.9, 1.08], [1.35, 1, 1, 1]], ev: [[0.22, 'hop'], [0.72, 'hop'], [1.3, 'ribbit']] },
  BobaBear: { dur: 2.5, toy: [[0, ...P0.slice(1)], [0.2, 0, 0.03, 0.04, 0, 0, 0.25], [0.32, 0, 0.03, 0.04, 0, 0, -0.25], [0.44, 0, 0.03, 0.04, 0, 0, 0.25], [0.56, 0, 0.03, 0.04, 0, 0, -0.25], [0.68, 0, 0.03, 0.04, 0, 0, 0.25], [0.85, 0, 0.03, 0.04, 0, 0, 0], [1.3, 0, 0.12, 0.3, 0.55, 0, 0], [1.85, 0, 0.12, 0.3, 0.55, 0, 0], [2.5, 0, 0, 0, 0, 0.25, 0]],
    hands: [[0, ...HF], [2.5, 1, 0, 0, 0, 0, 0, 0]], ev: [[0.2, 'rattle'], [1.35, 'slurp']] },
  PancakePup: { dur: 2.6, toy: [[0, ...P0.slice(1)], [0.18, 0, -0.03, 0, 0, 0, 0], [0.55, 0, 0.2, 0, -Math.PI, 0, 0], [0.9, 0, -0.02, 0, -TAU, 0, 0], [1.1, 0, 0.01, 0, -TAU, 0, 0], [1.6, 0, 0.04, 0.16, -TAU - 0.25, 0, 0], [2.0, 0, 0.04, 0.16, -TAU - 0.25, 0, 0], [2.6, 0, 0, 0, -TAU, 0.25, 0]],
    hands: [[0, ...HF], [0.18, 1, 0, -0.03, 0, 0, -0.03, 0], [0.3, 0.3, 0, 0, 0, 0, 0, 0], [0.8, 0.3, 0, 0, 0, 0, 0, 0], [0.9, 1, 0, 0, 0, 0, 0, 0]], sq: [[0, 1, 1, 1], [0.9, 1, 1, 1], [0.97, 1.18, 0.74, 1.18], [1.15, 0.95, 1.06, 0.95], [1.3, 1, 1, 1]], ev: [[0.2, 'toss'], [0.92, 'plop'], [1.65, 'sniff']] },
  CloudBunny: { dur: 2.9, toy: [[0, ...P0.slice(1)], [0.35, 0, 0.06, 0, 0, 0, 0], [0.8, 0.04, 0.13, 0.02, 0, 0.3, 0.12], [1.25, -0.04, 0.15, 0.02, 0, -0.2, -0.12], [1.7, 0.03, 0.13, 0.02, 0, 0.1, 0.08], [2.3, 0, 0.0, 0, 0, 0.25, 0], [2.9, 0, 0, 0, 0, 0.25, 0]],
    hands: [[0, ...HF], [0.35, 0.25, 0, 0, 0, 0, 0, 0], [2.0, 0.25, 0, 0, 0, 0, 0, 0], [2.4, 1, 0, 0, 0, 0, 0, 0]], sq: [[0, 1, 1, 1], [2.3, 1, 1, 1], [2.4, 1.1, 0.88, 1.1], [2.6, 1, 1, 1]], ev: [[0.4, 'sparkle'], [1.25, 'sparkle'], [2.35, 'plop']] },
  CupcakeAxolotl: { dur: 2.7, toy: [[0, ...P0.slice(1)], [0.25, 0, 0.04, 0.04, 0, 0, 0], [1.6, 0, 0.04, 0.04, 0, TAU, 0], [2.0, 0, 0.1, 0.14, 0.4, TAU, 0], [2.3, 0, 0.1, 0.14, 0.4, TAU, 0], [2.7, 0, 0, 0, 0, TAU + 0.25, 0]],
    hands: [[0, ...HF], [0.25, 0.5, 0, -0.02, 0, 0, -0.02, 0], [1.6, 0.5, 0, -0.02, 0, 0, -0.02, 0], [2.0, 1, 0, 0, 0, 0, 0, 0]], ev: [[0.3, 'wiggle'], [1.0, 'wiggle'], [2.0, 'blub']] },
};

/* ---------------- dodgeball throws ---------------- */
const TH0 = [0, 0, -0.13, -0.5, 0, 0.25, 0], RH0 = [0, 0.14, -0.165, -0.465], LH0 = [0, -0.14, -0.165, -0.465], RR = [0.16, -0.23, -0.46], LR = [-0.16, -0.23, -0.46];
const THROWS = {
  overhand: { dur: 0.75, rel: 0.27, speed: 20, arc: 0.7, toy: [TH0, [0.17, 0.2, 0.03, -0.3, 0.5, 0, -0.4], [0.27, 0.07, -0.04, -0.78, -0.6, 0, 0]], R: [RH0, [0.17, 0.25, -0.02, -0.27], [0.27, 0.1, -0.08, -0.72], [0.45, -0.06, -0.34, -0.6], [0.75, ...RR]], L: [LH0, [0.17, -0.1, -0.08, -0.68], [0.3, -0.2, -0.3, -0.5], [0.75, ...LR]] },
  sidearm: { dur: 0.75, rel: 0.25, speed: 21, arc: 0.35, toy: [TH0, [0.16, -0.2, -0.18, -0.36, 0, 1.2, 0.3], [0.25, 0.1, -0.16, -0.74, 0, -0.6, 0]], R: [RH0, [0.16, -0.12, -0.22, -0.36], [0.25, 0.18, -0.2, -0.7], [0.45, 0.34, -0.24, -0.48], [0.75, ...RR]], L: [LH0, [0.16, -0.3, -0.2, -0.36], [0.3, -0.24, -0.34, -0.46], [0.75, ...LR]] },
  spiral: { dur: 0.78, rel: 0.29, speed: 24, arc: 0.6, toy: [TH0, [0.12, 0.12, -0.1, -0.4, 0, 1.57, 0], [0.2, 0.2, 0.02, -0.26, 0.4, 1.57, 0], [0.29, 0.06, -0.04, -0.8, -0.2, 1.57, 0]], R: [RH0, [0.12, 0.16, -0.14, -0.4], [0.2, 0.24, -0.02, -0.26], [0.29, 0.1, -0.08, -0.72], [0.47, -0.06, -0.34, -0.6], [0.78, ...RR]], L: [LH0, [0.2, -0.1, -0.08, -0.68], [0.32, -0.2, -0.3, -0.5], [0.78, ...LR]] },
  lob: { dur: 0.85, rel: 0.32, speed: 12, arc: 2.4, toy: [TH0, [0.18, 0.05, -0.42, -0.34, 0.6, 0.25, 0], [0.32, 0.02, -0.06, -0.66, -0.4, 0.25, 0]], R: [RH0, [0.18, 0.14, -0.46, -0.32], [0.32, 0.1, -0.1, -0.62], [0.5, 0.12, 0.0, -0.6], [0.85, ...RR]], L: [LH0, [0.18, -0.18, -0.38, -0.4], [0.4, -0.2, -0.3, -0.5], [0.85, ...LR]] },
  glide: { dur: 0.8, rel: 0.26, speed: 16, arc: 0.4, toy: [TH0, [0.14, 0, -0.27, -0.46, 0.2, 0, 0], [0.26, 0, -0.02, -0.7, -0.3, 0, 0]], R: [RH0, [0.14, 0.08, -0.33, -0.45], [0.26, 0.08, -0.06, -0.66], [0.45, 0.14, 0.02, -0.62], [0.8, ...RR]], L: [LH0, [0.14, -0.08, -0.33, -0.45], [0.26, -0.08, -0.06, -0.66], [0.45, -0.14, 0.02, -0.62], [0.8, ...LR]] },
  skip: { dur: 0.75, rel: 0.24, speed: 17, arc: 0, toy: [TH0, [0.15, 0.26, -0.36, -0.32, 0, -0.8, 0.2], [0.24, 0.04, -0.38, -0.72, 0, 0.4, 0]], R: [RH0, [0.15, 0.3, -0.4, -0.3], [0.24, 0.08, -0.42, -0.66], [0.42, -0.14, -0.4, -0.6], [0.75, ...RR]], L: [LH0, [0.15, -0.24, -0.26, -0.5], [0.75, ...LR]] },
  sling: { dur: 0.95, rel: 0.52, speed: 27, arc: 0.25, toy: [TH0, [0.45, 0.02, -0.16, -0.4, 0, 0, 0], [0.52, 0.0, -0.14, -0.8, 0, 0, 0]], sq: [[0, 1, 1, 1], [0.45, 0.78, 0.85, 1.75], [0.52, 1, 1, 1]], R: [RH0, [0.45, 0.08, -0.17, -0.3], [0.52, 0.1, -0.17, -0.4], [0.95, ...RR]], L: [LH0, [0.2, -0.05, -0.16, -0.66], [0.52, -0.05, -0.16, -0.66], [0.7, -0.2, -0.3, -0.5], [0.95, ...LR]] },
  bounce: { dur: 0.75, rel: 0.27, speed: 18, arc: 0.5, toy: [TH0, [0.17, 0.18, 0.02, -0.32, 0.5, 0, -0.3], [0.27, 0.05, -0.22, -0.78, 0.6, 0, 0]], R: [RH0, [0.17, 0.23, -0.02, -0.3], [0.27, 0.08, -0.24, -0.72], [0.45, -0.04, -0.4, -0.58], [0.75, ...RR]], L: [LH0, [0.17, -0.1, -0.1, -0.66], [0.3, -0.2, -0.3, -0.5], [0.75, ...LR]] },
  shove: { dur: 1.0, rel: 0.55, speed: 22, arc: 0.3, toy: [TH0, [0.4, 0, -0.2, -0.34, 0, 0, 0], [0.55, 0, -0.12, -0.86, 0, 0, 0]], sq: [[0, 1, 1, 1], [0.38, 0.92, 1.1, 0.92], [0.55, 1.08, 0.9, 1.1], [0.6, 1, 1, 1]], R: [RH0, [0.4, 0.12, -0.22, -0.32], [0.55, 0.1, -0.14, -0.78], [1.0, ...RR]], L: [LH0, [0.4, -0.12, -0.22, -0.32], [0.55, -0.1, -0.14, -0.78], [1.0, ...LR]] },
};

/* ---------------- sfx extras ---------------- */
const X = {
  tweet: () => { for (let i = 0; i < 3; i++) sfx.tone('sine', 2200 + i * 200, 3000 + i * 200, 0.06, 0.07, i * 0.08); },
  ribbit: () => { sfx.tone('sawtooth', 180, 120, 0.12, 0.08); sfx.tone('sawtooth', 200, 130, 0.14, 0.08, 0.16); },
  rattle: () => { for (let i = 0; i < 6; i++) sfx.noise('bandpass', 2600, 1800, 0.03, 0.18, i * 0.11, 3); },
  slurp: () => sfx.noise('bandpass', 400, 1400, 0.45, 0.22, 0, 4),
  snap: () => { sfx.noise('highpass', 3000, 2000, 0.05, 0.4); sfx.tone('square', 900, 400, 0.04, 0.05); sfx.sparkle(3); },
  blub: () => { for (let i = 0; i < 4; i++) sfx.tone('sine', 300 + i * 120, 900 + i * 150, 0.06, 0.1, i * 0.09); },
  ring: () => { sfx.tone('square', 1320, 1320, 0.08, 0.04); sfx.tone('square', 1320, 1320, 0.08, 0.04, 0.16); },
};
function toyWorldPos(off = 0) { const p = V3(); H.wrap.getWorldPosition(p); return p.add(V3(0, off, 0)); }
function vEv(name) {
  const tr = H.t.meta.trail, p = toyWorldPos(), m = H.t.meta;
  const pc = (n, o = {}) => vfx.burst(o.shape || tr.shape, o.pos || p, n, Object.assign({ colors: tr.pcols, speed: 0.35, size: 0.006, life: 0.6, gravity: -0.6, drag: 3 }, o));
  switch (name) {
    case 'flick': H.sq.kick(-1.6); sfx.tone('triangle', 900, 1300, 0.08, 0.05); break;
    case 'pat': case 'plop': H.sq.kick(-2); sfx.squish(m.squeeze.pitch); pc(5, { normal: V3(0, 1, 0) }); break;
    case 'flip': case 'twirl': case 'toss': case 'swish': sfx.whoosh(0.22); break;
    case 'tap': sfx.tone('triangle', 620, 560, 0.05, 0.08); pc(3, { shape: 'cube' }); break;
    case 'spread': sfx.noise('lowpass', 900, 500, 0.4, 0.12); break;
    case 'peek': case 'sniff': sfx.tone('sine', 700, 980, 0.12, 0.06); break;
    case 'snap': X.snap(); vfx.burst('spark', p, 8, { colors: [0xE8B84A, 0xFFFFFF], speed: 0.5, size: 0.006, life: 0.5, gravity: 0 }); break;
    case 'flap': H.sq.kick(3); sfx.whoosh(0.12); pc(4, { shape: 'petal', colors: [0xFFFFFF, 0x8BD0F3] }); break;
    case 'tweet': X.tweet(); break;
    case 'roar': sfx.roar(); for (let i = 0; i < 14; i++) vfx.emit('glowdrop', { pos: toyWorldPos(0.07), vel: V3(rnd(-0.12, 0.12), rnd(0.15, 0.4), rnd(0.05, 0.3)), color: [0xFF9A4D, 0xFFD25E, 0xFF6F7D][i % 3], size: 0.007, life: 0.5, gravity: 0.3, drag: 2 }); shake = Math.max(shake, 0.25); break;
    case 'stretch': sfx.squish(m.squeeze.pitch * 0.8); sfx.tone('sine', 200, 120, 0.5, 0.08); break;
    case 'snapback': sfx.release(m.squeeze.pitch); H.sq.kick(4); pc(6); break;
    case 'hop': sfx.pop(); break;
    case 'ribbit': X.ribbit(); pc(4, { shape: 'heart', colors: [0xEE4A5C] }); break;
    case 'rattle': X.rattle(); break;
    case 'slurp': X.slurp(); break;
    case 'sparkle': sfx.sparkle(3); vfx.burst('spark', p, 6, { colors: [0xFFE27A, 0xFFFFFF, 0xD5C8F6], speed: 0.3, size: 0.006, life: 0.6, gravity: 0 }); break;
    case 'wiggle': H.sq.kick(2.5); sfx.tone('sine', 500, 800, 0.1, 0.05); break;
    case 'blub': X.blub(); for (let i = 0; i < 8; i++) vfx.emit('sphere', { pos: toyWorldPos(0.05), vel: V3(rnd(-0.05, 0.05), rnd(0.1, 0.25), rnd(0, 0.15)), color: 0xDDF4FF, size: 0.006, life: 0.7, gravity: 0.2, drag: 1 }); break;
    case 'ring': X.ring(); break;
  }
}

/* ---------------- world projectiles + grounded splat ---------------- */
const protos = {};
function cloneToy(id) {
  const pr = protos[id] || (protos[id] = buildToy(id, { outline: 2.4 }));
  const root = pr.root.clone(true), squash = root.getObjectByName(id + '_deform'), fN = [], fS = [];
  root.traverse((o) => { if (o.name === 'face_normal') fN.push(o); if (o.name === 'face_squish') fS.push(o); if (o.isMesh && !o.userData.isOutline) o.castShadow = true; });
  root.position.set(0, -pr.size.y / 2, 0);
  const carrier = group('fly_' + id, world); carrier.add(root);
  const c = { id, meta: pr.meta, size: pr.size, carrier, root, squash, setFace: (k) => { fN.forEach((g) => (g.visible = k !== 'squish')); fS.forEach((g) => (g.visible = k === 'squish')); } };
  return c;
}
const projs = [];
function launch({ id, from, to, style, speed, arc, scale0, s1 = 1, dummy, kind = 'toy', spin = 1, delay = 0, onHit }) {
  const c = cloneToy(id); c.carrier.position.copy(from); c.carrier.scale.setScalar(scale0 ?? 1);
  const tr = c.meta.trail;
  const ribs = (tr.twin ? [-tr.twin, tr.twin] : [0]).map((o) => ({ o, r: fx.ribbon({ a: tr.a, b: tr.b, width: tr.w * 1.3, life: tr.life, opacity: 0.85, wavy: tr.wavy }) }));
  const dur = from.distanceTo(to) / (speed || 20);
  const q = { c, from: from.clone(), to: to.clone(), style, arc: arc ?? 0.6, dur, t: -delay, ribs, dummy, phase: 'fly', s0: scale0 ?? 1, s1, kind, spin, onHit, bounces: 0 };
  c.setFace('squish'); projs.push(q); return q;
}
function hitDummy(d, dir) {
  d.hit = 0; d.dir = dir.clone().setY(0).normalize(); d.fS.forEach((g) => (g.visible = true)); d.fN.forEach((g) => (g.visible = false));
  const c = chestOf(d);
  fx.burst('spark', c, 10, { colors: [0xFFFFFF, 0xFFE27A], speed: 3, size: 0.05, life: 0.5, gravity: 0 });
  for (let i = 0; i < 5; i++) fx.emit('star', { pos: c.clone().add(V3(0, 0.55, 0)), vel: V3(rnd(-1, 1), rnd(0.8, 1.6), rnd(-1, 1)), color: 0xFFD25E, size: 0.06, life: 0.9, gravity: -1.5, spin: 8 });
}
function groundStart(q, at) {
  q.phase = 'ground'; q.gt = 0; q.at = at.clone(); q.at.y = FLOOR; const tr = q.c.meta.trail;
  fx.splat(q.at.clone().setY(FLOOR + 0.004), V3(0, 1, 0), tr.b, Math.max(q.c.size.x, q.c.size.y) * 0.75, 2.9);
  fx.burst(tr.shape, q.at.clone().setY(FLOOR + 0.1), 14, { colors: tr.pcols, speed: 1.8, size: 0.03, life: 0.6, normal: V3(0, 1, 0), floor: FLOOR + 0.01, gravity: -5 });
  fx.ring(q.at.clone().setY(FLOOR + 0.02), { color: 0xFFFFFF, r0: 0.1, r1: 0.7, life: 0.35, opacity: 0.6 });
  sfx.splat(0.9); q.c.setFace('squish');
  const f = q.at.clone().sub(P.pos).setY(0).normalize(); if (f.lengthSq() < 0.01) f.set(1, 0, 0);
  q.basis = new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(f.clone().cross(V3(0, 1, 0)), f, V3(0, 1, 0)));
  for (const r of q.ribs) r.r.stop();
}
function updateProjs(dt) {
  for (let i = projs.length - 1; i >= 0; i--) {
    const q = projs[i], c = q.c, car = c.carrier;
    if (q.phase === 'fly') {
      q.t += dt; if (q.t < 0) { car.visible = false; continue; } car.visible = true;
      const k = Math.min(1, q.t / q.dur); let p;
      if (q.style === 'skip') { const fl = FLOOR + c.size.y * 0.35; p = q.from.clone().lerp(q.to, k); const b = Math.abs(Math.sin(k * Math.PI * 3)) * 0.7 * (1 - k * 0.6); p.y = k < 0.12 ? q.from.y + (fl - q.from.y) * (k / 0.12) : fl + b + (k > 0.8 ? ((k - 0.8) / 0.2) * (q.to.y - fl - b) : 0); const nb = Math.floor(k * 3); if (k > 0.12 && nb > q.bounces) { q.bounces = nb; fx.burst('sphere', p.clone().setY(FLOOR + 0.05), 6, { colors: [0xFFF6EA, 0xE8D3B4], speed: 1.2, size: 0.04, life: 0.4, flat: true, drag: 4 }); sfx.land(false); } }
      else if (q.style === 'bounce') { const mid = q.from.clone().lerp(q.to, 0.5).setY(FLOOR + c.size.y * 0.3); if (k < 0.5) p = q.from.clone().lerp(mid, k / 0.5); else { p = mid.clone().lerp(q.to, (k - 0.5) / 0.5); p.y += Math.sin(Math.PI * (k - 0.5) / 0.5) * 0.6; } if (k >= 0.5 && !q.bounced) { q.bounced = 1; fx.burst('heart', mid, 6, { colors: [0xEE4A5C, 0x6CC56A], speed: 1.4, size: 0.04, life: 0.5, normal: V3(0, 1, 0) }); fx.ring(mid.clone().setY(FLOOR + 0.02), { color: 0xFFFFFF, r0: 0.1, r1: 0.5, life: 0.3, opacity: 0.6 }); sfx.pop(); } }
      else if (q.style === 'roll') { p = q.from.clone().lerp(q.to, k); p.y = FLOOR + c.size.y * 0.5 * car.scale.y; }
      else { p = q.from.clone().lerp(q.to, k); p.y += Math.sin(Math.PI * k) * q.arc; if (q.style === 'glide') p.y += Math.sin(k * 14) * 0.08; }
      car.position.copy(p); { const big = q.s1 > 1, gk = Math.min(1, q.t / (big ? 0.3 : 0.14)); car.scale.setScalar(q.s0 + (q.s1 - q.s0) * (big ? backOut(gk) : gk)); }
      if (q.style === 'roll' && Math.random() < 0.9) fx.emit('capsule', { pos: p.clone().add(V3(rnd(-0.3, 0.3), rnd(-0.2, 0.4), rnd(-0.3, 0.3))), vel: V3(rnd(-1.5, 1.5), rnd(1, 2.5), rnd(-1.5, 1.5)), color: [0xFFFFFF, 0x7FD3F7, 0xFFD25E, 0xF68FB4, 0x8BE3A1][(Math.random() * 5) | 0], size: 0.035, life: 0.7, gravity: -5, spin: 10 });
      const dir = q.to.clone().sub(q.from).normalize(), r = car.rotation, fm = c.meta.flight;
      if (q.style === 'roll') { car.quaternion.setFromUnitVectors(V3(0, 0, 1), V3(-dir.z, 0, dir.x)); car.rotateZ(-q.t * 22); car.quaternion.premultiply(new THREE.Quaternion().setFromAxisAngle(dir, 0.5 + 0.12 * Math.sin(q.t * 9))); }
      else if (fm === 'glide' || fm === 'face') { car.quaternion.setFromUnitVectors(V3(0, 0, 1), dir); car.rotateZ(Math.sin(q.t * 18) * 0.2); }
      else if (fm === 'frisbee') { r.x = 0.3; r.y += dt * 22; } else if (fm === 'spiral') { car.quaternion.setFromUnitVectors(V3(1, 0, 0), dir); car.rotateX(q.t * 24); }
      else if (fm === 'wheel') { r.z += dt * 20; } else if (fm === 'upright' || fm === 'float') { r.z = Math.sin(q.t * 9) * 0.25; r.y += dt * 3; }
      else { r.x += dt * 12 * q.spin; r.z = Math.sin(q.t * 16) * 0.3; }
      for (const rb of q.ribs) rb.r.push(p.clone().add(V3(0, 0, rb.o)), T);
      const tr = c.meta.trail;
      if (Math.random() < tr.rate * dt * 1.6) fx.emit(tr.shape, { pos: p.clone().add(V3(rnd(-0.1, 0.1), rnd(-0.1, 0.1), rnd(-0.1, 0.1))), vel: dir.clone().multiplyScalar(-1).add(V3(rnd(-0.5, 0.5), rnd(0, 0.6), rnd(-0.5, 0.5))), color: tr.pcols[(Math.random() * tr.pcols.length) | 0], size: rnd(0.025, 0.04), life: 0.55, gravity: tr.gravity ?? -2.5 });
      if (tr.sparkle && Math.random() < 0.4) fx.emit('spark', { pos: p, vel: V3(rnd(-1, 1), rnd(-1, 1), rnd(-1, 1)), color: tr.sparkle, size: 0.025, life: 0.4, gravity: 0 });
      if (tr.ember && Math.random() < 0.7) fx.emit('glowdrop', { pos: p, vel: dir.clone().multiplyScalar(-1.2).add(V3(0, 0.5, 0)), color: [0xFF9A4D, 0xFFD25E][(Math.random() * 2) | 0], size: 0.035, life: 0.35, gravity: 1 });
      if (k >= 1 && q.hoverFn) { q.phase = 'hover'; q.ht = 0; for (const rb of q.ribs) rb.r.stop(); sfx.sparkle(4); continue; }
      if (k >= 1) {
        if (q.onHit) q.onHit(q, p);
        if (q.dummy) { hitDummy(q.dummy, dir); hitstop = 0.05; shake = Math.max(shake, 0.15); }
        fx.burst(tr.shape, p, 16, { colors: tr.pcols, speed: 2.6, size: 0.035, life: 0.7, gravity: -5, floor: FLOOR + 0.01 });
        fx.ring(p, { color: RARITY[c.meta.rarity], r0: 0.05, r1: 0.7, life: 0.3, normal: dir.clone().negate(), opacity: 0.9 });
        fx.flash(p, 0xFFE0B0, 8, 0.2); sfx.splat(1); if (q.dummy) setTimeout(() => sfx.ding(), 50);
        for (const rb of q.ribs) rb.r.stop();
        q.phase = 'fall'; q.vel = dir.clone().multiplyScalar(-1.4).add(V3(rnd(-0.6, 0.6), 2.4, rnd(-0.6, 0.6))); if (q.style === 'roll') q.vel.set(0, 1.6, 0);
      }
    } else if (q.phase === 'hover') {
      q.ht += dt; const g = Math.min(1, q.ht / 0.35); car.scale.setScalar(1 + 2.2 * backOut(g)); car.position.y += Math.sin(q.ht * 3) * 0.004; car.rotation.set(0, q.ht * 0.6, Math.sin(q.ht * 2) * 0.08); c.setFace(q.ht < 2.4 ? 'squish' : 'normal');
      if (Math.random() < dt * 20) fx.emit('sphere', { pos: car.position.clone().add(V3(rnd(-0.8, 0.8), -0.4, rnd(-0.8, 0.8))), vel: V3(0, -2, 0), color: 0xE6DEFF, size: 0.04, life: 0.5, gravity: -6 });
      if (q.ht > 2.6) { q.phase = 'fall'; q.vel = V3(0, -1, 0); }
    } else if (q.phase === 'fall') {
      q.vel.y -= 9.8 * dt; car.position.addScaledVector(q.vel, dt); car.rotation.x += dt * 8; if (car.scale.x !== 1) car.scale.setScalar(car.scale.x > 1 ? Math.max(1, car.scale.x - dt * 4) : Math.min(1, car.scale.x + dt * 2.2));
      if (car.position.y <= FLOOR + c.size.y * 0.3) groundStart(q, car.position);
    } else if (q.phase === 'ground') {
      q.gt += dt; const t = q.gt, fl = Math.min(1, t / 0.07), wob = Math.exp(-t * 6) * Math.sin(t * 30);
      const sxy = 1 + 0.48 * fl + 0.12 * wob + (t > 0.6 ? 0.012 * Math.sin(t * 3) : 0), sz = Math.max(0.14, 1 - 0.76 * fl - 0.1 * wob);
      if (t < 2.4) {
        car.quaternion.slerp(q.basis, Math.min(1, dt * 40)); c.squash.scale.set(sxy, sxy, sz); car.scale.setScalar(1);
        car.position.set(q.at.x, FLOOR + c.size.z * 0.5 * sz + 0.004, q.at.z);
        if (t > 0.55 && !q.calm) { q.calm = 1; c.setFace('normal'); }
      } else {
        const u = Math.min(1, (t - 2.4) / 0.38), e = backOut(u);
        c.squash.scale.set(sxy + (1 - sxy) * e, sxy + (1 - sxy) * e, sz + (1 - sz) * e);
        car.position.y = FLOOR + c.size.z * 0.5 + Math.sin(Math.PI * u) * 0.35 + u * c.size.y * 0.5;
        car.quaternion.slerp(new THREE.Quaternion(), Math.min(1, dt * 10));
        if (!q.peeled) { q.peeled = 1; sfx.pop(); c.setFace('squish'); }
        if (u >= 1) {
          fx.burst('sphere', car.position, 12, { colors: [0xFFFFFF, 0xF4E6D3], speed: 1.2, size: 0.05, life: 0.45, gravity: 0.6, drag: 3 });
          fx.burst('spark', car.position, 6, { colors: [0xFFFFFF, 0xFFE27A], speed: 1, size: 0.03, life: 0.4, gravity: 0 }); sfx.sparkle(2);
          world.remove(car); for (const rb of q.ribs) rb.r.stop(); projs.splice(i, 1);
          if (q.kind === 'toy' && !projs.some((x) => x.kind === 'toy')) { if (ACT.kind === 'empty' || ACT.kind === 'dropwait') { if (ACT.kind === 'dropwait') look.tp = -0.06; equip(); } }
        }
      }
    }
  }
}

/* ---------------- actions ---------------- */
function targetDummy() { const f = FWD(); let best = dummies[0], bd = -2; for (const d of dummies) { const v = chestOf(d).sub(cam.position).normalize(), dt = v.dot(f); if (dt > bd) { bd = dt; best = d; } } return best; }
function start(kind, arg) {
  sfx.ensure();
  if (mode !== 'fp' || !H) return;
  if (kind === 'knead' && ACT.kind === 'knead') return kneadExit();
  if (kind === 'reset') { if (ACT.kind === 'knead') { KN.settle = 0.9; KN.w.set(0, 0, 0); } return; }
  if (kind === 'rewax') { rewax(); return; }
  if (ACT.kind !== 'idle' && !(kind === 'squish' && ACT.kind === 'squish')) return;
  const id = toyId;
  if (kind === 'inspect') ACT = { kind, t: 0, ch: INS[id], fired: {} };
  else if (kind === 'throw') { const st = THROWS[THROW_STYLE[id][0]]; ACT = { kind, t: 0, st, name: THROW_STYLE[id][0], fired: {}, R: [[0, ...armR.pos.p.toArray()], ...st.R.slice(1)], L: [[0, ...armL.pos.p.toArray()], ...st.L.slice(1)] }; if (id === 'Dragon') vEv('roar'); }
  else if (kind === 'drop') { ACT = { kind, t: 0 }; look.tp = -0.62; }
  else if (kind === 'ult') { if (!ULTS[id]) return; ACT = { kind, t: 0, u: ULTS[id], fired: {} }; ACT.tone = sfx.tone && null; }
  else if (kind === 'squish') { ACT = { kind: 'squish', t: 0 }; H.soft.palms(true); }
  else if (kind === 'poke') ACT = { kind, t: 0, k: -1, auto: arg || [[rnd(-0.6, -0.3), rnd(-0.2, 0.15)], [rnd(0.3, 0.6), rnd(-0.1, 0.25)], [rnd(-0.15, 0.15), rnd(-0.55, -0.35)]] };
  else if (kind === 'knead') { ACT = { kind, t: 0 }; KN.q.copy(pivot.quaternion); KN.w.set(0, 0, 0); KN.settle = 0.7; KN.fit = kneadFit(); sfx.whoosh(0.1); }
  ui();
}
function squishUp() { if (ACT.kind !== 'squish') return; H.soft.palms(false); const tr = H.t.meta.trail; vfx.burst(tr.shape, toyWorldPos(0.05), 6, { colors: tr.pcols, speed: 0.45, size: 0.006, life: 0.6, gravity: -0.8, normal: V3(0, 1, 0) }); if (H.t.meta.rarity === 'Epic' || H.t.meta.rarity === 'Exclusive') { vfx.burst('spark', toyWorldPos(0.05), 6, { colors: [0xFFFFFF, tr.sparkle || 0xFFE27A], speed: 0.35, size: 0.005, life: 0.5, gravity: 0 }); sfx.sparkle(2); } ACT = { kind: 'idle', t: 0 }; ui(); }
function kneadExit() {
  if (ACT.kind !== 'knead' && !KN.keep) return;
  if (pokeDown) { pokeDown = false; H.soft.fingerUp(); }
  if (KN.palm) { KN.palm = false; H.soft.palms(false); }
  if (KN.thumb) { KN.thumb = false; H.soft.thumbs(false); }
  spin = null; KN.keep = false;
  const e = new THREE.Euler().setFromQuaternion(KN.q, 'XYZ'); tRot.p.set(e.x, e.y, e.z); tRot.v.set(0, 0, 0); wrapRot();
  if (ACT.kind === 'knead') ACT = { kind: 'idle', t: 0 };
  tipEl.className = ''; canvas.style.cursor = ''; ui();
}
function kneadSwitch(id) { if (pokeDown) { pokeDown = false; H.soft.fingerUp(true); } if (KN.palm) { KN.palm = false; H.soft.palms(false); } if (KN.thumb) { KN.thumb = false; H.soft.thumbs(false); } spin = null; KN.keep = true; equip(id); }
function releaseToWorld(vmPos, extra = {}) {
  const from = cam.localToWorld(vmPos.clone()); const d = extra.dummy || targetDummy();
  pivot.visible = false;
  return launch(Object.assign({ id: toyId, from, to: chestOf(d), style: ACT.name, speed: ACT.st?.speed, arc: ACT.st?.arc, scale0: H.K, dummy: d }, extra));
}
function ultRelease() {
  const id = toyId, u = ULTS[id], tr = H.t.meta.trail, vmP = tPos.p.clone(), from = cam.localToWorld(vmP.clone());
  pivot.visible = false; fov.v += 90; kick.v.x -= 1.2; shake = Math.max(shake, 0.3); sfx.whoosh(0.6);
  const ring = (p, r, c, life = 1) => fx.ring(p.clone().setY(FLOOR + 0.02), { color: c, r0: s(r), r1: s(r), life, pulse: 16, opacity: 0.8, inner: 0.9 });
  if (id === 'Birdie') {
    dummies.forEach((d, i) => launch({ id, from, to: chestOf(d), style: 'glide', speed: s(75), arc: 0.3, scale0: H.K, dummy: d, delay: i * 0.05 }));
  } else if (id === 'Donut') {
    const f = FWD().setY(0).normalize(), start = P.pos.clone().addScaledVector(f, 1.6).setY(FLOOR), end = start.clone().addScaledVector(f, s(60));
    const lane = mesh(new THREE.PlaneGeometry(s(60), s(6)), new THREE.MeshBasicMaterial({ color: 0xF68FB4, transparent: true, opacity: 0.25, depthWrite: false }), 'ult_lane', world);
    lane.rotation.set(-Math.PI / 2, 0, -Math.atan2(f.z, f.x)); lane.position.copy(start.clone().lerp(end, 0.5)).setY(FLOOR + 0.015); setTimeout(() => world.remove(lane), 1600);
    const q = launch({ id, from: start.clone().setY(FLOOR + 0.3), to: end, style: 'roll', speed: s(55), scale0: 0.5, s1: 2.3, dummy: null });
    q.onHit = () => {}; q.roll = true;
    const near = dummies.filter((d) => { const v = d.holder.position.clone().sub(start); const along = v.dot(f), perp = v.clone().addScaledVector(f, -along).length(); return along > 0 && perp < s(3.5); });
    near.forEach((d) => setTimeout(() => { hitDummy(d, f); sfx.splat(1.1); }, (d.holder.position.clone().sub(start).dot(f) / s(55)) * 1000 / timeScale));
    q.sprinkle = true;
  } else if (id === 'CloudBunny') {
    const c = dummies[1].holder.position.clone(); ring(c, 7, 0xB892F0, 3.2);
    const q = launch({ id, from, to: c.clone().setY(FLOOR + s(14)), style: 'lob', speed: 9, arc: 1.4, scale0: H.K, dummy: null });
    q.onHit = (qq) => { qq.hover = 0; };
    q.hoverFn = true;
    const drops = [0, 1, 2, 3, 4].map((k) => { const a = k * 2.4, r = s(2 + (k % 3) * 2); return c.clone().add(V3(Math.cos(a) * r, 0, Math.sin(a) * r)); });
    dummies.forEach((d) => { if (d.holder.position.distanceTo(c) < s(7.5)) drops[drops.length - 1 - dummies.indexOf(d)] = d.holder.position.clone(); });
    drops.forEach((dp, k) => setTimeout(() => {
      fx.ring(dp.clone().setY(FLOOR + 0.02), { color: 0x6A5A9A, r0: s(1.6), r1: s(1.6), life: 0.45, pulse: 30, opacity: 0.5, inner: 0.0 });
      setTimeout(() => { const top = c.clone().setY(FLOOR + s(13)); const drop = mesh(new THREE.SphereGeometry(0.09, 16, 12), mat('rain_drop', 0x9DB8FF, 0.3), 'rain_drop', world); toonify(drop); drop.position.copy(top); RAIN.push({ m: drop, from: top, to: dp, t: 0 }); }, 450 / timeScale);
    }, (900 + k * 360) / timeScale));
  } else if (id === 'CupcakeAxolotl') {
    const d = dummies[0], q = launch({ id, from, to: chestOf(d).add(V3(0, 0.3, 0)), style: 'bubble', speed: s(40), arc: 0.9, scale0: H.K, dummy: d });
    const bub = mesh(new THREE.SphereGeometry(0.42, 32, 24), new THREE.MeshToonMaterial({ color: 0xCFF3FF, transparent: true, opacity: 0.35, depthWrite: false }), 'bubble', q.c.carrier); q.bubble = bub;
    q.onHit = (qq, p) => { qq.c.carrier.remove(bub); fx.ring(p.clone().setY(FLOOR + 0.02), { color: 0x8FDCC4, r0: 0.1, r1: s(6), life: 0.45, opacity: 0.8 }); fx.burst('sphere', p, 26, { colors: [0xDDF4FF, 0xF9AFCB, 0x8FDCC4], speed: 3, size: 0.04, life: 0.6, gravity: -3 }); X.blub(); dummies.forEach((dd) => { if (dd !== d && dd.holder.position.distanceTo(p.clone().setY(FLOOR)) < s(6)) hitDummy(dd, V3(1, 0, 0)); }); };
  } else if (id === 'Dragon') {
    const d = dummies[1], at = d.holder.position.clone(); ring(at, 8, 0xFF9A4D, 1.2);
    const head = toonHead(), f0 = cam.position.clone().addScaledVector(FWD(), 2.4).add(V3(0, 0.3, 0)); head.scale.setScalar(0.3); head.position.copy(f0); world.add(head);
    HEADS.push({ head, from: f0, to: chestOf(d), t: -0.55, rib: null, d, at });
  }
  setTimeout(() => { if (!projs.some((x) => x.kind === 'toy') && ACT.kind === 'empty') equip(); }, 3800 / timeScale);
}
const RAIN = [], HEADS = [];
function updateUltExtras(dt) {
  for (let i = RAIN.length - 1; i >= 0; i--) { const r = RAIN[i]; r.t += dt; const k = Math.min(1, r.t / 0.3); r.m.position.lerpVectors(r.from, r.to, k * k); r.m.scale.set(0.8, 1.4, 0.8);
    if (k >= 1) { world.remove(r.m); fx.ring(r.to.clone().setY(FLOOR + 0.02), { color: 0x9DB8FF, r0: 0.05, r1: s(2), life: 0.3, opacity: 0.8 }); fx.burst('sphere', r.to.clone().setY(FLOOR + 0.05), 8, { colors: [0x9DB8FF, 0xFFFFFF], speed: 1.5, size: 0.03, life: 0.4, normal: V3(0, 1, 0) }); sfx.tone('sine', 900, 400, 0.08, 0.1); const d = dummies.find((dd) => dd.holder.position.distanceTo(r.to) < s(1.5)); if (d) hitDummy(d, V3(0, 0, 1)); RAIN.splice(i, 1); } }
  for (let i = HEADS.length - 1; i >= 0; i--) {
    const h = HEADS[i]; h.t += dt; if (h.t < 0) { const g = clamp((h.t + 0.55) / 0.32, 0, 1); h.head.scale.setScalar(0.3 + 2.3 * backOut(g)); h.head.position.copy(h.from).add(V3(0, Math.sin(T * 40) * 0.01, 0)); h.head.lookAt(h.to); if (Math.random() < 0.6) fx.emit('glowdrop', { pos: h.from.clone().add(V3(rnd(-0.4, 0.4), rnd(-0.3, 0.3), rnd(-0.4, 0.4))), vel: V3(rnd(-0.5, 0.5), rnd(0.5, 1.2), rnd(-0.5, 0.5)), color: [0xFF9A4D, 0xFFD25E][(Math.random() * 2) | 0], size: 0.05, life: 0.4, gravity: 1 }); continue; }
    if (!h.rib) { h.rib = [fx.ribbon({ a: 0xFFE7A0, b: 0xFF9A4D, width: 0.9, life: 0.3, opacity: 0.85 }), fx.ribbon({ a: 0xD9C6FF, b: 0xB892F0, width: 0.45, life: 0.4, opacity: 0.7, wavy: 1 })]; sfx.whoosh(0.4); }
    const k = Math.min(1, h.t / (h.from.distanceTo(h.to) / s(110))), p = h.from.clone().lerp(h.to, k); p.y += Math.sin(Math.PI * k) * 0.5;
    h.head.position.copy(p); h.head.lookAt(h.to); h.rib.forEach((r, j) => r.push(p.clone().add(V3(0, j * 0.08, 0)), T));
    for (let e = 0; e < 3; e++) fx.emit('glowdrop', { pos: p.clone().add(V3(rnd(-0.3, 0.3), rnd(-0.3, 0.3), rnd(-0.3, 0.3))), vel: V3(rnd(-1, 1), rnd(0, 1.5), rnd(-1, 1)), color: [0xFF9A4D, 0xFFD25E, 0xFF6F7D][e], size: 0.06, life: 0.4, gravity: 2 });
    if (k >= 1) {
      world.remove(h.head); h.rib.forEach((r) => r.stop());
      fx.ring(h.at.clone().setY(FLOOR + 0.03), { color: 0xFFD25E, r0: 0.2, r1: s(8), life: 0.35, opacity: 0.95 }); fx.ring(h.at.clone().setY(FLOOR + 0.04), { color: 0xB892F0, r0: 0.2, r1: s(11), life: 0.5, opacity: 0.6 });
      fx.burst('glowdrop', p, 46, { colors: [0xFF9A4D, 0xFFD25E, 0xFF6F7D], speed: 8, size: 0.09, life: 0.6, gravity: -6 });
      fx.burst('sphere', h.at.clone().setY(FLOOR + 0.3), 18, { colors: [0xFFF1E3, 0xE9DDF7], speed: 3.5, size: 0.35, life: 0.8, flat: true, drag: 3, gravity: 0.6 });
      fx.flash(p, 0xFFB060, 40, 0.35); sfx.boom(); shake = Math.max(shake, 0.45); hitstop = 0.08;
      dummies.forEach((d) => { if (d.holder.position.distanceTo(h.at) < s(8)) hitDummy(d, d.holder.position.clone().sub(h.at).add(V3(0.01, 0, 0))); });
      HEADS.splice(i, 1);
    }
  }
}

/* ---------------- per-frame action evaluation ---------------- */
let glow = null;
function updateAction(dt) {
  if (!H) return;
  ACT.t += dt;
  const hw = H.hw + 0.05;
  let toyP = HOLD.clone(), toyR = HOLD_R.clone(), sq = V3(1, 1, 1), Lt = null, Rt = null, lRoll = 0.4, rRoll = -0.4, scale = H.K, hideToy = false;
  const side = (p, o) => [p.clone().add(V3(-hw + o[0], -0.035 + o[1], 0.035 + o[2])), p.clone().add(V3(hw + o[3], -0.035 + o[4], 0.035 + o[5]))];
  const br = Math.sin(T * 2.2);
  toyP.y += 0.004 * br;
  const kn = mode === 'fp' && (ACT.kind === 'knead' || (ACT.kind === 'equip' && KN.keep));
  const wantF = mode === 'fp' && (kn || ACT.kind === 'squish' || ACT.kind === 'poke' || (ACT.kind === 'idle' && H.soft.active && H.soft.since < 1.1));
  focusA = focus.step(wantF ? 1 : 0, dt); toyP.lerp(FOCUS, focusA); toyR.lerp(FOCUS_R, focusA);
  if (mode === 'tp') toyP.add(V3(0.03, -0.075, 0.04));
  switch (ACT.kind) {
    case 'equip': { const u = Math.min(1, ACT.t / 0.38); scale = H.K * Math.max(0.0001, backOut(u)); if (u >= 1) { ACT = KN.keep ? { kind: 'knead', t: 0 } : { kind: 'idle', t: 0 }; KN.keep = false; ui(); } break; }
    case 'inspect': {
      const ch = ACT.ch, t = ACT.t, a = kv(ch.toy, t), hd = kv(ch.hands, t);
      toyP.add(V3(a[0], a[1], a[2])); toyR.set(a[3], a[4], a[5]); if (ch.sq) { const q = kv(ch.sq, t); sq.set(q[0], q[1], q[2]); }
      const [sl, sr] = side(toyP, hd.slice(1)); Lt = REST_L.clone().add(V3(hd[1], hd[2], hd[3])).lerp(sl, hd[0]); Rt = REST_R.clone().add(V3(hd[4], hd[5], hd[6])).lerp(sr, hd[0]);
      for (const [et, n] of ch.ev) if (t >= et && !ACT.fired[et]) { ACT.fired[et] = 1; vEv(n); }
      if (t >= ch.dur) { ACT = { kind: 'idle', t: 0 }; tRot.p.set(...toyR.toArray()); wrapRot(); ui(); }
      break;
    }
    case 'squish': {
      const c = H.soft.palmC, g = H.hw + 0.05 - H.soft.palmD * H.K * 0.94, tr = ACT.t > 0.3 ? 0.0008 * c : 0;
      Lt = toyP.clone().add(V3(-g + Math.sin(T * 53) * tr, -0.02, 0.03)); Rt = toyP.clone().add(V3(g - Math.sin(T * 49) * tr, -0.02, 0.03)); lRoll = 0.4 + 0.3 * c; rRoll = -0.4 - 0.3 * c;
      toyP.x += Math.sin(T * 47) * tr * 0.6;
      shake = Math.max(shake, 0.025 * c);
      break;
    }
    case 'poke': {
      const [hl, hr] = side(toyP, [0, 0, 0, 0, 0, 0]); Lt = hl; Rt = hr;
      if (ACT.auto) {
        const per = 0.46, k = Math.floor(ACT.t / per), ph = ACT.t - k * per;
        if (k >= ACT.auto.length) { H.soft.fingerUp(); ACT = { kind: 'idle', t: 0 }; ui(); break; }
        if (ph < 0.3) { if (ACT.k !== k) { ACT.k = k; const h = H.soft.frontPoint(...ACT.auto[k]); ACT.hand = h.p.x < H.soft.ctr.x - H.soft.size.x * 0.08 ? 'L' : 'R'; H.soft.fingerDown(h); } }
        else if (H.soft.finger) H.soft.fingerUp();
      }
      if (H.soft.finger || H.soft.pulling) { const a = ACT.hand === 'L' ? armL : armR, hp = handForTip(a, vm.worldToLocal(H.soft.fingerTip(V3())), a === armR ? rRoll : lRoll); if (a === armR) Rt = hp; else Lt = hp; }
      break;
    }
    case 'throw': {
      const st = ACT.st, t = ACT.t, a = kv(st.toy, Math.min(t, st.rel));
      toyP.set(a[0], a[1], a[2]); toyR.set(a[3], a[4], a[5]); if (st.sq) { const q = kv(st.sq, t); sq.set(q[0], q[1], q[2]); }
      const r = kv(ACT.R, t), l = kv(ACT.L, t); Rt = V3(...r); Lt = V3(...l); rRoll = -0.4 - (t < st.rel ? 0.5 : 0); lRoll = 0.3;
      if (ACT.name === 'shove' && t < 0.4) { const j = 0.006; toyP.add(V3(rnd(-j, j), rnd(-j, j), 0)); shake = Math.max(shake, 0.12); }
      if (ACT.name === 'sling' && t < 0.45 && t > 0.1) { shake = Math.max(shake, 0.06 * (t / 0.45)); if (!ACT.fired.str) { ACT.fired.str = 1; sfx.squish(H.t.meta.squeeze.pitch * 0.8); } }
      if (t >= st.rel && !ACT.fired.rel) {
        ACT.fired.rel = 1; tPos.p.copy(toyP); releaseToWorld(toyP); fov.v += 80; kick.v.x -= 0.8; shake = Math.max(shake, 0.18); sfx.whoosh(0.5);
        vfx.burst(H.t.meta.trail.shape, toyWorldPos(), 10, { colors: H.t.meta.trail.pcols, speed: 0.8, size: 0.006, life: 0.4 });
        vfx.ring(toyWorldPos(), { color: RARITY[H.t.meta.rarity], r0: 0.01, r1: 0.12, life: 0.25, normal: V3(0, 0, 1), opacity: 0.7 });
      }
      if (t >= st.rel) hideToy = true;
      if (t >= st.dur) { ACT = { kind: 'empty', t: 0 }; ui(); }
      break;
    }
    case 'drop': {
      const t = ACT.t; toyP.add(V3(0, -0.05 * ease(t / 0.3), -0.05 * ease(t / 0.3)));
      Lt = side(toyP, [0, 0, 0, 0, 0, 0])[0]; Rt = side(toyP, [0, 0, 0, 0, 0, 0])[1];
      if (t > 0.42 && !ACT.fired) { ACT.fired = 1; const vmP = toyP.clone(); const from = cam.localToWorld(vmP.clone()); pivot.visible = false; const q = launch({ id: toyId, from, to: from, style: 'drop', speed: 1, scale0: H.K }); q.phase = 'fall'; q.vel = FWD().setY(0).normalize().multiplyScalar(2.1).add(V3(0, 1.1, 0)); q.c.carrier.position.copy(from); q.c.carrier.scale.setScalar(H.K); q.c.setFace('normal'); sfx.whoosh(0.15); ACT = { kind: 'dropwait', t: 0 }; }
      break;
    }
    case 'ult': {
      const u = ACT.u, t = ACT.t, ch = Math.min(1, t / u.charge), e = ease(ch);
      toyP.lerp(V3(0, -0.06, -0.47), e); toyR.set(-0.15 * e, 0, 0); sq.set(1 + 0.08 * Math.sin(t * 40) * ch, 1 - 0.06 * ch, 1);
      if (ch < 1) { const j = 0.004 * ch; toyP.add(V3(rnd(-j, j), rnd(-j, j), 0)); }
      Lt = side(toyP, [0, 0, 0, 0, 0, 0])[0]; Rt = side(toyP, [0, 0, 0, 0, 0, 0])[1];
      if (!glow) { glow = mesh(new THREE.SphereGeometry(1, 24, 16), new THREE.MeshBasicMaterial({ color: RARITY[H.t.meta.rarity], transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false }), 'ult_glow', vm); }
      glow.position.copy(tPos.p); glow.scale.setScalar(0.13 + 0.02 * Math.sin(t * 30)); glow.material.color.set(H.t.meta.id === 'Dragon' ? 0xFF9A4D : RARITY[H.t.meta.rarity]); glow.material.opacity = 0.35 * e;
      if (Math.random() < dt * 60) { const d = V3(rnd(-1, 1), rnd(-1, 1), rnd(-1, 1)).normalize(); vfx.emit('glowdrop', { pos: toyWorldPos().addScaledVector(d, 0.16), vel: d.multiplyScalar(-0.7), color: H.t.meta.trail.pcols[(Math.random() * H.t.meta.trail.pcols.length) | 0], size: 0.005, life: 0.22, gravity: 0, drag: 0 }); }
      shake = Math.max(shake, 0.12 * ch); fov.v -= 6 * dt * 60 * 0.1;
      if (!ACT.fired.c) { ACT.fired.c = 1; if (toyId === 'Dragon') sfx.roar(); else { sfx.tone('sawtooth', 120, 420, u.charge, 0.05); sfx.sparkle(4); } }
      if (ch >= 1 && !ACT.fired.r) { ACT.fired.r = 1; tPos.p.copy(toyP); ultRelease(); glow.material.opacity = 0; vfx.ring(toyWorldPos(), { color: 0xFFFFFF, r0: 0.02, r1: 0.3, life: 0.3, normal: V3(0, 0, 1), opacity: 0.8 }); ACT = { kind: 'empty', t: 0, ult: 1 }; ui(); }
      break;
    }
    case 'empty': case 'dropwait': { Lt = REST_L.clone(); Rt = REST_R.clone(); hideToy = true; break; }
  }
  if (glow && ACT.kind !== 'ult') glow.material.opacity *= Math.exp(-dt * 8);
  if (kn) {
    const f = KN.fit || (KN.fit = kneadFit()), Cn = H.soft.crunch; toyP.copy(f.p); toyP.y += 0.003 * br;
    const ta = Cn.on ? H.soft.thumbTip(0, _ta) : null, tb = Cn.on ? H.soft.thumbTip(1, _tb) : null;
    const shk = 1 - Math.exp(-dt * 9); armL.sh.lerp(ta && tb ? SH_CRUNCH[0] : armL.sh0, shk); armR.sh.lerp(ta && tb ? SH_CRUNCH[1] : armR.sh0, shk);
    if (ta && tb) { lRoll = THUMB_ROLL; rRoll = -THUMB_ROLL; Lt = handForTip(armL, vm.worldToLocal(ta), lRoll); Rt = handForTip(armR, vm.worldToLocal(tb), rRoll); toyP.z += 0.012 * Cn.P; toyP.y -= 0.006 * Cn.P; }
    else { Lt = REST_L.clone().add(V3(-0.1, -0.38, 0.12)); Rt = REST_R.clone().add(V3(0.1, -0.38, 0.12)); }
  }
  if (!kn) { armL.sh.copy(armL.sh0); armR.sh.copy(armR.sh0); }
  if (!Lt) { const [a, b] = side(toyP, [0, 0, 0, 0, 0, 0]); Lt = a; Rt = b; }
  H.sq.update(dt); H.soft.update(dt);
  pivot.position.copy(tPos.step(toyP, dt)); if (jolt > 1e-5) { pivot.position.x += (Math.random() - 0.5) * jolt; pivot.position.y += (Math.random() - 0.5) * jolt; jolt *= Math.exp(-dt * 30); } const rr = tRot.step(toyR, dt); pivot.rotation.set(rr.x, rr.y, rr.z);
  if (kn) {
    if (!spin) { const wl = KN.w.length(); if (wl > 1e-4) KN.q.premultiply(_q.setFromAxisAngle(_v1.copy(KN.w).divideScalar(wl), wl * dt)); KN.w.multiplyScalar(Math.exp(-dt * 2.4)); }
    if (KN.settle > 0) { KN.settle -= dt; KN.q.slerp(KN.home, 1 - Math.exp(-dt * 8)); }
    else if (H.soft.crunch.on && !spin) KN.q.slerp(KN_CRUNCH, 1 - Math.exp(-dt * 5));
    pivot.quaternion.copy(KN.q);
  }
  const ss = tSq.step(sq, dt), zz = kz.step(kn ? (KN.fit || (KN.fit = kneadFit())).z : 1, dt); pivot.scale.set(scale * zz * ss.x, scale * zz * ss.y, scale * zz * ss.z);
  if (hideToy) pivot.visible = false; else if (ACT.kind !== 'dropwait') pivot.visible = true;
  driveArm(armL, Lt, lRoll, dt); driveArm(armR, Rt, rRoll, dt);
}

/* ---------------- dummies ---------------- */
function updateDummies(dt) {
  for (const d of dummies) {
    d.an.update(dt);
    if (d.hit >= 0) {
      d.hit += dt; const t = d.hit, k = Math.exp(-t * 5) * Math.sin(t * 16);
      d.lean.rotation.z = -0.45 * Math.exp(-t * 4) * Math.sign(d.dir.x || 1) + 0.05 * k; d.lean.rotation.x = 0.35 * Math.exp(-t * 4) * d.dir.z;
      d.lean.scale.set(1 + 0.1 * k, 1 - 0.14 * k, 1 + 0.1 * k);
      d.holder.position.copy(d.home).addScaledVector(d.dir, 0.5 * Math.min(1, t * 6) * Math.exp(-t * 1.2));
      if (t > 1.1) { d.hit = -1; d.fN.forEach((g) => (g.visible = true)); d.fS.forEach((g) => (g.visible = false)); d.lean.rotation.set(0, 0, 0); d.lean.scale.setScalar(1); d.holder.position.copy(d.home); }
    }
  }
}

/* ---------------- third-person dash watch ---------------- */
let runner = null;
function makeRunner() {
  const holder = group('runner', world, [s(8), FLOOR, s(-6)]);
  const av = buildAvatar({ team: 'strawberry', name: 'DashingPlayer' }); av.root.rotation.y = -Math.PI / 2; holder.add(av.root);
  av.root.traverse((o) => { if (o.isMesh && !o.userData.isOutline) o.castShadow = true; });
  const toy = protos.Donut ? protos.Donut.root.clone(true) : buildToy('Donut', { outline: 2.4 }).root; toy.scale.setScalar(0.8); toy.position.set(0, 0, -0.12); av.grip.add(toy);
  const an = new Animator(av);
  an.onEvent = (n, d) => {
    const foot = (sd) => { const p = V3(); av.J[sd + 'Ankle'].getWorldPosition(p); p.y = FLOOR + 0.03; return p; };
    if (n === 'pushoff') { const p = foot(d === 'L' ? 'r' : 'l'); fx.burst('sphere', p, 12, { colors: [0xFFF6EA, 0xE6D2B5], speed: 2, size: 0.07, life: 0.5, flat: true, drag: 4.5, gravity: 0.4 }); fx.ring(p, { color: 0xFFFFFF, r0: 0.1, r1: 0.8, life: 0.3, opacity: 0.55 }); sfx.dash(); }
    if (n === 'plant') { fx.burst('sphere', foot(d === 'R' ? 'r' : 'l'), 8, { colors: [0xFFF6EA, 0xE6D2B5], speed: 1.4, size: 0.06, life: 0.45, flat: true, drag: 5, gravity: 0.3 }); sfx.land(false); }
    if (n === 'takeoff') { fx.burst('sphere', holder.position.clone().setY(FLOOR + 0.03), 8, { colors: [0xFFF6EA], speed: 1.2, size: 0.06, life: 0.4, flat: true, drag: 5 }); sfx.jump(); }
    if (n === 'land') { fx.ring(holder.position.clone().setY(FLOOR + 0.02), { color: 0xFFFFFF, r0: 0.15, r1: d ? 1.1 : 0.75, life: 0.35, opacity: 0.6 }); fx.burst('sphere', holder.position.clone().setY(FLOOR + 0.04), d ? 14 : 9, { colors: [0xFFF6EA, 0xE6D2B5], speed: 1.6, size: 0.06, life: 0.5, flat: true, drag: 5, gravity: 0.3 }); sfx.land(d); }
  };
  runner = { holder, av, an, home: holder.position.clone(), dash: null, run: null, auto: false, autoT: 0, i: 0 };
}
function rDash(dir) {
  sfx.ensure(); const r = runner; if (!r || r.dash || r.an.airborne || r.run) return;
  const d = DASH_DIR[dir], w = V3(d[0], 0, d[2]).applyAxisAngle(V3(0, 1, 0), -Math.PI / 2), D = s(14);
  const p = r.holder.position, next = p.clone().addScaledVector(w, D);
  const stump = V3(s(14), p.y, 0), seg = (a, b) => { const ab = b.clone().sub(a), u = clamp(stump.clone().sub(a).dot(ab) / ab.lengthSq(), 0, 1); return a.clone().addScaledVector(ab, u).setY(p.y).distanceTo(stump); };
  if (next.z > s(9) || next.z < s(-20) || next.x < s(1) || next.x > s(26) || seg(p, next) < s(4.5)) { fx.burst('sphere', p.clone().setY(FLOOR + 0.6), 14, { colors: [0xFFFFFF], speed: 1.4, size: 0.12, life: 0.45, drag: 3 }); p.copy(r.home).addScaledVector(w, -D / 2); sfx.pop(); }
  r.dash = { w, t: 0, D, ribs: [fx.ribbon({ a: 0xF8CAD4, b: 0xFFFFFF, width: 0.32, life: 0.2, opacity: 0.5 }), fx.ribbon({ a: 0xFFFFFF, b: 0xF8CAD4, width: 0.2, life: 0.16, opacity: 0.4 }), fx.ribbon({ a: 0xFFFFFF, b: 0xF8CAD4, width: 0.12, life: 0.14, opacity: 0.35 })] };
  r.an.startDash(dir); ui();
}
function rJump(run) { sfx.ensure(); const r = runner; if (!r || r.dash || r.an.airborne || r.run) return; if (run) { r.holder.position.copy(r.home).add(V3(0, 0, s(-12))); r.run = { t: 0, jumped: false, after: 0 }; } else r.an.startJump(); }
function updateRunner(dt) {
  const r = runner; if (!r) return; const an = r.an;
  if (r.auto && !r.dash && !an.airborne && !r.run) { r.autoT -= dt; if (r.autoT <= 0) { const seq = ['L', 'R', 'R', 'L', 'F', 'B', 'J', 'L', 'R']; const c = seq[r.i++ % seq.length]; c === 'J' ? rJump(false) : rDash(c); r.autoT = 0.75; } }
  if (r.dash) {
    const d = r.dash; d.t += dt; const T2 = 0.22, e = (x) => 1 - Math.pow(1 - clamp(x, 0, 1), 3);
    r.holder.position.addScaledVector(d.w, d.D * (e(d.t / T2) - e((d.t - dt) / T2)));
    if (d.t < 0.26) { const w = V3(); r.av.J.waist.getWorldPosition(w); d.ribs[0].push(w.clone().add(V3(0, 0.3, 0)), T); d.ribs[1].push(w.clone().add(V3(0, -0.2, 0)), T); d.ribs[2].push(w.clone().add(V3(0, 0.75, 0)), T); if (Math.random() < 0.6) fx.emit('capsule', { pos: w.clone().add(V3(rnd(-0.3, 0.3), rnd(-0.6, 0.8), rnd(-0.3, 0.3))), vel: d.w.clone().multiplyScalar(-3), color: 0xFFFFFF, size: 0.025, life: 0.2, gravity: 0, drag: 2 }); }
    else if (!d.stop) { d.stop = 1; d.ribs.forEach((x) => x.stop()); }
    if (d.t > 0.55) { r.dash = null; ui(); }
  }
  if (r.run) { const q = r.run; q.t += dt; let sp = 16; if (q.t > 0.32 && !q.jumped) { q.jumped = true; an.startJump(); } if (q.jumped && !an.airborne) { q.after += dt; sp = Math.max(0, 16 * (1 - q.after / 0.3)); } an.speed = sp; r.holder.position.z += s(sp) * dt; r.av.root.rotation.y = -Math.PI / 2 + Math.PI / 2 * Math.min(1, sp / 4) * 0; r.holder.rotation.y = sp > 0.5 ? Math.PI / 2 : r.holder.rotation.y * 0.9; if (q.after > 0.5) { r.run = null; an.speed = 0; r.holder.rotation.y = 0; } }
  an.update(dt);
  r.holder.position.y = FLOOR + s(an.airY());
}

/* ---------------- UI ---------------- */
const panel = $('#panel'), bar = $('#bar'), picker = $('#picker');
function ui() {
  const m = byId(toyId), u = ULTS[toyId], st = THROW_STYLE[toyId], fl = feelOf(toyId), wx = WAX[TOY_FEEL[toyId] || 'foam'];
  picker.innerHTML = CATALOG.map((c) => `<button data-toy="${c.id}" class="${c.id === toyId ? 'on' : ''}" style="--c:${RARITY[c.rarity]}" ${mode !== 'fp' ? 'disabled' : ''}><i></i>${c.name}${ULTS[c.id] ? '<em>ULT</em>' : ''}</button>`).join('');
  const busy = ACT.kind !== 'idle', kn = mode === 'fp' && (ACT.kind === 'knead' || KN.keep);
  if (mode === 'fp') {
    bar.innerHTML = kn ? `
      <button data-a="knead" class="on"><b>Back</b><kbd>E</kbd></button>
      <button data-a="crunch" class="${KN.thumb ? 'on' : ''}"><b>Thumb crunch</b><kbd>F hold</kbd></button>
      <button data-a="squish" class="${KN.palm ? 'on' : ''}"><b>Squeeze</b><kbd>Q hold</kbd></button>
      <button data-a="rewax"><b>Re-wax</b><kbd>W</kbd></button>
      <button data-a="reset"><b>Face front</b><kbd>R</kbd></button>` : `
      <button data-a="knead" ${busy ? 'disabled' : ''}><b>Knead</b><kbd>E</kbd></button>
      <button data-a="inspect" ${busy ? 'disabled' : ''}><b>Inspect</b><kbd>R</kbd></button>
      <button data-a="squish" ${busy && ACT.kind !== 'squish' ? 'disabled' : ''} class="${ACT.kind === 'squish' ? 'on' : ''}"><b>Squish</b><kbd>F hold</kbd></button>
      <button data-a="poke" ${busy ? 'disabled' : ''}><b>Poke</b><kbd>P</kbd></button>
      <button data-a="throw" ${busy ? 'disabled' : ''}><b>Throw</b><kbd>T</kbd></button>
      <button data-a="drop" ${busy ? 'disabled' : ''}><b>Drop</b><kbd>G</kbd></button>
      ${u ? `<button data-a="ult" class="ult" ${busy ? 'disabled' : ''}><b>Ultimate</b><kbd>Q</kbd></button>` : ''}`;
    panel.innerHTML = `<div class="ph"><b>${m.name}</b><span class="chip" style="--c:${RARITY[m.rarity]}">${m.rarity}</span></div>
      <div class="row"><span>Squeeze</span><p><b>${fl.label}.</b> ${fl.note}</p></div>
      <div class="row"><span>Coat</span><p>${sa.mode === 'slime' ? 'Off. Slime sounds.' : sa.flav === 'soft' ? '<b>Soft squish.</b> A muffled foam squeeze with a gentle grain, no wax crackle.' : sa.flav === 'light' ? '<b>Light crunch.</b> A thin, dull crust: a few soft crackles over a squishy body.' : `<b>${wx.label}.</b> ${wx.note}`}</p></div>
      ${kn ? `<div class="row"><span>Sound</span><div class="mini">${[['soft', 'Soft squish'], ['light', 'Light crunch'], ['crunch', 'Wax crunch'], ['slime', 'Slime']].map(([k, n]) => `<button data-snd="${k}" class="${(sa.mode === 'slime' ? 'slime' : sa.flav) === k ? 'on' : ''}">${n}</button>`).join('')}</div></div>
      <div class="row"><span>Compare</span><div class="mini"><button data-ab="ref">▶ Your clip</button></div></div>` : ''}
      <div class="row"><span>Inspect</span><p>${INSPECT_NOTE[toyId]}</p></div>
      <div class="row"><span>Throw</span><p>${st[1]} · ${THROWS[st[0]].speed * (1 / S) | 0} st/s visual pace, release on frame ${Math.round(THROWS[st[0]].rel * 30)}</p></div>
      <div class="row"><span>Grounded</span><p>Lands face-up, flattens to ${Math.round(24)}% height, wobbles, peels back up after 2.4 s.</p></div>
      ${u ? `<div class="ultc"><div class="uh"><b>${u.name}</b><span>Ultimate · proposed balance</span></div>${u.stats.map(([k, v]) => `<div class="kv"><span>${k}</span><b>${v}</b></div>`).join('')}<p>${u.counter}</p></div>` : `<p class="fine">Ultimates are reserved for Epic and Exclusive squishies.</p>`}
      <p class="fine">${kn ? 'Hold F to thumb-crunch it like your clip · drag on it to knead · drag off its edge to stretch · drag the background to spin · W re-waxes · ← → switch squishy' : 'E to knead it up close · click or drag on it to poke · drag elsewhere to look · ← → switch squishy'}</p>`;
  } else {
    bar.innerHTML = ['F', 'L', 'R', 'B'].map((d) => `<button data-d="${d}" ${runner && (runner.dash || runner.an.airborne) ? 'disabled' : ''}><b>Dash ${{ F: 'toward', B: 'away', L: 'their left', R: 'their right' }[d]}</b><kbd>${{ F: '↓', B: '↑', L: '→', R: '←' }[d]}</kbd></button>`).join('') + `<button data-j="0"><b>Jump</b><kbd>Space</kbd></button><button data-j="1"><b>Run + jump</b><kbd>J</kbd></button><button data-auto="1" class="${runner && runner.auto ? 'on' : ''}"><b>Auto</b><kbd>A</kbd></button>`;
    panel.innerHTML = `<div class="ph"><b>Watching a dash</b><span class="chip" style="--c:#F2687F">3rd person</span></div>
      <p class="fine">Low body line, push-off puff, 3 short ribbons, plant puff; head stays level. Visual 12 f @ 30 fps · gameplay 14 st in 0.22 s (provisional).</p>`;
  }
  document.body.classList.toggle('tp', mode === 'tp'); document.body.classList.toggle('knead', kn);
  if (kn && H) KN.fit = kneadFit();
  if (kn) { const wide = innerWidth > 820, pr = panel.getBoundingClientRect(), pk = picker.getBoundingClientRect(), l = wide && pk.width ? pk.right + 10 : 0, r = wide && pr.width ? pr.left - 10 : innerWidth; waxHud.style.left = (l + r) / 2 + 'px'; waxHud.style.maxWidth = Math.max(0, r - l) + 'px'; }
  $('#modeFP').classList.toggle('on', mode === 'fp'); $('#modeTP').classList.toggle('on', mode === 'tp');
}
const rc = new THREE.Raycaster(), ndc = new THREE.Vector2(), tipEl = $('#tip');
function setRay(e) { ndc.set((e.clientX / innerWidth) * 2 - 1, -(e.clientY / innerHeight) * 2 + 1); rc.setFromCamera(ndc, vmCam); }
function tip(e, over) { tipEl.style.translate = `${e.clientX}px ${e.clientY}px`; tipEl.classList.toggle('over', !!over); tipEl.classList.toggle('press', pokeDown); tipEl.classList.toggle('pull', !!(pokeDown && H && H.soft.pulling)); }
function toyHit(e) {
  if (!H || mode !== 'fp' || !pivot.visible) return null;
  setRay(e);
  for (const h of rc.intersectObject(H.wrap, true)) { const r = H.soft.restHit(h); if (r) return r; }
  return null;
}
let pokeDown = false;
document.addEventListener('pointerdown', (e) => {
  const b = e.target.closest('button'); sfx.ensure();
  if (!b) {
    if (e.target !== canvas) return;
    try { canvas.setPointerCapture(e.pointerId); } catch (_) {}
    if (ACT.kind === 'knead') { const h = toyHit(e); if (h) { pokeDown = true; H.soft.fingerDown(h); } else { spin = { x: e.clientX, y: e.clientY, t: performance.now() }; KN.w.set(0, 0, 0); KN.settle = 0; } tip(e, !!h); return; }
    const h = ACT.kind === 'idle' ? toyHit(e) : null;
    if (h) { pokeDown = true; ACT = { kind: 'poke', t: 0, hand: h.p.x < H.soft.ctr.x - H.soft.size.x * 0.08 ? 'L' : 'R' }; H.soft.fingerDown(h); ui(); }
    else drag = { x: e.clientX, y: e.clientY };
    return;
  }
  if (b.dataset.a === 'squish') { e.preventDefault(); if (ACT.kind === 'knead') { if (!KN.palm) { if (KN.thumb) { KN.thumb = false; H.soft.thumbs(false); } KN.palm = 'btn'; H.soft.palms(true); } } else start('squish'); }
  if (b.dataset.a === 'crunch') { e.preventDefault(); if (ACT.kind === 'knead' && !KN.thumb) { KN.thumb = 'btn'; crunchOn(); } }
});
document.addEventListener('pointerup', (e) => {
  drag = null; if (ACT.kind === 'squish') squishUp();
  if (KN.palm === 'btn') { KN.palm = false; H.soft.palms(false); }
  if (KN.thumb === 'btn') crunchOff();
  if (spin) { if (performance.now() - spin.t > 90) KN.w.set(0, 0, 0); spin = null; }
  if (pokeDown) { pokeDown = false; H.soft.fingerUp(); if (ACT.kind === 'poke' && !ACT.auto) { ACT = { kind: 'idle', t: 0 }; ui(); } }
  if (ACT.kind === 'knead') tip(e, e.target === canvas && !!toyHit(e));
});
document.addEventListener('click', (e) => {
  const b = e.target.closest('button'); if (!b || b.disabled) return;
  if (b.dataset.toy && mode === 'fp' && (ACT.kind === 'idle' || ACT.kind === 'equip' || ACT.kind === 'knead')) { sfx.tick(); if (ACT.kind === 'knead' || KN.keep) kneadSwitch(b.dataset.toy); else equip(b.dataset.toy); }
  if (b.dataset.a && b.dataset.a !== 'squish' && b.dataset.a !== 'crunch') start(b.dataset.a);
  if (b.dataset.snd) setSnd(b.dataset.snd);
  if (b.dataset.ab) playAB(b.dataset.ab);
  if (b.dataset.d) rDash(b.dataset.d);
  if (b.dataset.j) rJump(b.dataset.j === '1');
  if (b.dataset.auto) { runner.auto = !runner.auto; runner.autoT = 0; ui(); }
  if (b.id === 'modeFP' || b.id === 'modeTP') setMode(b.id === 'modeFP' ? 'fp' : 'tp');
  if (b.dataset.speed) { timeScale = +b.dataset.speed; document.querySelectorAll('[data-speed]').forEach((x) => x.classList.toggle('on', x === b)); }
  if (b.id === 'snd') { sfx.on = !sfx.on; b.textContent = sfx.on ? 'Sound on' : 'Sound off'; b.classList.toggle('on', sfx.on); }
});
let drag = null;
addEventListener('pointermove', (e) => {
  if (pokeDown) {
    if (ACT.kind === 'poke' || ACT.kind === 'knead') { const h = H.soft.pulling ? null : toyHit(e); if (h) H.soft.fingerMove(h); else { setRay(e); H.soft.pullTo(rc.ray); } }
    if (ACT.kind === 'knead') tip(e, true);
    return;
  }
  if (spin) { const k = 0.0085, dx = e.clientX - spin.x, dy = e.clientY - spin.y, now = performance.now(), ds = Math.max(0.008, (now - spin.t) / 1000); spin.x = e.clientX; spin.y = e.clientY; spin.t = now; KN.q.premultiply(_q.setFromEuler(_e.set(dy * k, dx * k, 0))); KN.w.set(clamp((dy * k) / ds, -14, 14), clamp((dx * k) / ds, -14, 14), 0); return; }
  if (!drag) {
    if (e.target !== canvas) return;
    if (ACT.kind === 'knead') { const h = toyHit(e); tip(e, !!h); canvas.style.cursor = h ? 'none' : ''; }
    else canvas.style.cursor = ACT.kind === 'idle' && toyHit(e) ? 'pointer' : '';
    return;
  }
  look.ty -= (e.clientX - drag.x) * 0.0035; look.tp = clamp(look.tp - (e.clientY - drag.y) * 0.0035, -1.1, 0.8); drag = { x: e.clientX, y: e.clientY }; });
canvas.addEventListener('dblclick', () => { if (ACT.kind === 'knead') return; look.ty = yawTo(SPOT[mode], ...AIM[mode]); look.tp = PITCH[mode]; });
addEventListener('keydown', (e) => {
  if (e.repeat) return; sfx.ensure(); const k = e.key.toLowerCase();
  if (mode === 'fp' && (ACT.kind === 'knead' || KN.keep)) {
    if (k === 'e' || k === 'escape') kneadExit(); if (k === 'r') start('reset'); if (k === 'w') start('rewax');
    if (k === 'f' && ACT.kind === 'knead' && !KN.thumb) { KN.thumb = 'key'; crunchOn(); }
    if (k === 'q' && ACT.kind === 'knead' && !KN.palm) { if (KN.thumb) { KN.thumb = false; H.soft.thumbs(false); } KN.palm = 'key'; H.soft.palms(true); ui(); }
    if (k === 'arrowright' || k === 'arrowleft') { const i = CATALOG.findIndex((c) => c.id === toyId); kneadSwitch(CATALOG[(i + (k === 'arrowright' ? 1 : CATALOG.length - 1)) % CATALOG.length].id); }
  } else if (mode === 'fp') { if (k === 'e') start('knead'); if (k === 'r') start('inspect'); if (k === 'f') start('squish'); if (k === 't') start('throw'); if (k === 'g') start('drop'); if (k === 'q') start('ult'); if (k === 'p') start('poke'); if (k === 'arrowright' || k === 'arrowleft') { if (ACT.kind !== 'idle') return; const i = CATALOG.findIndex((c) => c.id === toyId); equip(CATALOG[(i + (k === 'arrowright' ? 1 : CATALOG.length - 1)) % CATALOG.length].id); } }
  else { const m = { arrowdown: 'F', arrowup: 'B', arrowright: 'L', arrowleft: 'R' }; if (m[k]) { e.preventDefault(); rDash(m[k]); } if (k === ' ') { e.preventDefault(); rJump(false); } if (k === 'j') rJump(true); if (k === 'a') { runner.auto = !runner.auto; ui(); } }
  if (k === '1') setMode('fp'); if (k === '2') setMode('tp');
});
addEventListener('keyup', (e) => {
  const k = e.key.toLowerCase();
  if (k === 'f') { if (ACT.kind === 'squish') squishUp(); if (KN.thumb === 'key') crunchOff(); }
  if (k === 'q' && KN.palm === 'key') { KN.palm = false; H.soft.palms(false); ui(); }
});
function setMode(m) {
  if (ACT.kind === 'knead' || KN.keep) kneadExit();
  mode = m; sfx.tick();
  if (m === 'tp') { if (!runner) makeRunner(); runner.holder.visible = true; dummies.forEach((d) => (d.holder.visible = false)); if (ACT.kind === 'idle' || ACT.kind === 'equip') ACT = { kind: 'idle', t: 0 }; }
  else { if (runner) { runner.holder.visible = false; runner.auto = false; } dummies.forEach((d) => (d.holder.visible = true)); }
  P.pos.copy(SPOT[m]); look.ty = look.yaw.p = yawTo(SPOT[m], ...AIM[m]); look.tp = look.pitch.p = PITCH[m]; look.yaw.v = look.pitch.v = 0;
  ui();
}

/* ---------------- wax crunch: flakes, jolt, re-wax, sound mode, A/B, HUD ---------------- */
let jolt = 0, hudT = 0, abSrc = null; const _cp = V3(), _cn = V3(), _cc = new THREE.Color(), WHITE = new THREE.Color(0xFFFFFF), AB = {};
function crackFx(c, E) {
  if (!H || mode !== 'fp' || !pivot.visible) return;
  if (E > 1.4) jolt = Math.max(jolt, 0.0005 * E * (0.4 + 0.6 * c.I));
  if (E < 0.6 || Math.random() > 0.25 + 0.4 * c.I) return;
  const m = Array.isArray(c.pt.o.material) ? c.pt.o.material[0] : c.pt.o.material; if (!m || !m.color) return;
  H.soft.cellWorld(c, _cp, _cn); _cc.copy(m.color).lerp(WHITE, 0.3);
  const zz = Math.max(1, kz.p * 0.8), n = 1 + (Math.random() < 0.3 * E ? 1 : 0);
  for (let i = 0; i < n; i++) vfx.emit('flake', { pos: _cp.clone().addScaledVector(_cn, 0.002), vel: _cn.clone().multiplyScalar(rnd(0.1, 0.28)).add(V3(rnd(-0.08, 0.08), rnd(0.02, 0.12), rnd(-0.04, 0.04))), color: _cc.getHex(), size: rnd(0.0016, 0.0032) * zz, life: rnd(0.5, 0.9), gravity: -1.1, drag: 1.4, spin: rnd(8, 18) });
}
function crunchOn() { if (!H) return; if (pokeDown) { pokeDown = false; H.soft.fingerUp(true); } if (KN.palm) { KN.palm = false; H.soft.palms(false); } spin = null; KN.w.set(0, 0, 0); KN.settle = 0; H.soft.thumbs(true); ui(); }
function crunchOff() { if (!KN.thumb) return; KN.thumb = false; H.soft.thumbs(false); KN.settle = 0.9; ui(); }
function rewax() { if (!H) return; H.soft.rewax(); sfx.sparkle(3); vfx.burst('spark', toyWorldPos(), 10, { colors: [0xFFFFFF, 0xFFF2B8], speed: 0.22, size: 0.004, life: 0.45, gravity: 0, drag: 2.5, spread: H.hw * kz.p * 0.7 }); }
function setSnd(m) { sa.mode = m === 'slime' ? 'slime' : 'wax'; if (FLAV[m]) sa.flav = m; sa.quiet(); document.body.classList.toggle('slime', sa.mode === 'slime' || sa.flav === 'soft'); sfx.tick(); ui(); }
async function playAB(k) {
  const c = sfx.ensure(); if (!c) return;
  try {
    const b = AB[k] || (AB[k] = await c.decodeAudioData(await (await fetch(k === 'ref' ? 'audio/ref-clip2.wav' : 'audio/wax-preview.wav')).arrayBuffer()));
    if (abSrc) try { abSrc.stop(); } catch (_) {}
    const s = c.createBufferSource(), g = c.createGain(); g.gain.value = 0.9; s.buffer = b; s.connect(g); g.connect(sfx.master); s.start(); abSrc = s;
  } catch (err) { console.warn('A/B audio', err); }
}
const waxHud = $('#wax'), waxEl = { bar: $('#wax i b'), txt: $('#wax em'), n: $('#wax small') };
function hud(dt) {
  if (!H || !waxEl.bar || !document.body.classList.contains('knead')) return;
  hudT -= dt; if (hudT > 0) return; hudT = 0.1;
  const w = Math.round(H.soft.waxLeft * 100); waxEl.bar.style.width = w + '%'; const l = H.soft.local; waxEl.txt.textContent = l > 0.7 ? 'Crunchy' : l > 0.4 ? 'Crackled' : 'Soft'; waxEl.n.textContent = H.soft.cracks.toLocaleString() + ' cracks';
}

/* ---------------- loop ---------------- */
let last = performance.now();
function frame(dtRaw) {
  let dt = dtRaw * timeScale; if (hitstop > 0) { hitstop -= dtRaw; dt *= 0.08; } T += dt;
  look.yaw.step(look.ty, dtRaw); look.pitch.step(look.tp, dtRaw);
  kick.step(V3(), dt); fov.step(-55 * focusA, dt); shake = Math.max(0, shake - dt * 1.4);
  const sh = shake * shake * 0.03;
  cam.position.copy(P.pos).add(V3(0, Math.sin(T * 1.6) * 0.003, 0));
  cam.rotation.set(look.pitch.p + kick.p.x * 0.04 + (Math.random() - 0.5) * sh, look.yaw.p + (Math.random() - 0.5) * sh, kick.p.z * 0.03 + Math.sin(T * 0.8) * 0.002);
  cam.fov = 70 + fov.p * 0.1; cam.updateProjectionMatrix(); cam.updateMatrixWorld();
  sun.position.copy(P.pos).add(V3(-14, 26, 10)); sun.target.position.copy(P.pos).add(V3(10, 0, 0));
  updateAction(dt); updateProjs(dt); updateUltExtras(dt); updateDummies(dt); updateRunner(dt); hud(dtRaw);
  armL.root.visible = armR.root.visible = true;
  vm.position.set(Math.sin(T * 0.9) * 0.002, Math.sin(T * 1.7) * 0.003 + kick.p.x * 0.01, 0); vm.rotation.set(kick.p.x * 0.02, 0, 0);
  if (arena.flames) { arena.flames.scale.set(1 + 0.08 * Math.sin(T * 13), 1 + 0.14 * Math.sin(T * 9), 1 + 0.08 * Math.cos(T * 11)); arena.flames.rotation.y += dt * 0.6; if (Math.random() < dtRaw * 6) { const p = V3(); arena.flames.getWorldPosition(p); fx.emit('glowdrop', { pos: p.add(V3(rnd(-0.2, 0.2), 0.6, rnd(-0.2, 0.2))), vel: V3(rnd(-0.2, 0.2), rnd(0.8, 1.4), rnd(-0.2, 0.2)), color: [0xFF9A4D, 0xFFD25E][(Math.random() * 2) | 0], size: 0.05, life: 0.9, gravity: 0.2, drag: 0.5 }); } }
  fx.update(dt, cam, T); vfx.update(dt, vmCam, T);
  R.clear(); R.render(world, cam); R.clearDepth();
  if (document.body.classList.contains('knead')) { // knead: hands always draw over the toy (viewmodel pass), so pressing thumbs never sink into it
    armL.root.visible = armR.root.visible = false; R.render(vm, vmCam); armL.root.visible = armR.root.visible = true; R.clearDepth();
    const kids = vm.children, vis = kids.map((o) => o.visible); for (const o of kids) if (!o.isLight && o !== armL.root && o !== armR.root) o.visible = false;
    R.render(vm, vmCam); kids.forEach((o, i) => (o.visible = vis[i]));
  } else R.render(vm, vmCam);
}
function loop(now) { requestAnimationFrame(loop); const d = Math.min(0.05, (now - last) / 1000); last = now; if (!window.SDFP.freeze) frame(d); }
window.SDFP = { freeze: false, advance(sec = 0.5) { for (let t = 0; t < sec; t += 1 / 60) frame(1 / 60); }, start, equip, setMode, kneadExit, rDash, rJump, squishUp, crunch(on = true) { if (ACT.kind !== 'knead') return; if (on && !KN.thumb) { KN.thumb = 'api'; crunchOn(); } else if (!on) crunchOff(); }, get arms() { return [armL, armR]; }, SH_CRUNCH, get audio() { return sa; }, get act() { return ACT.kind; }, get soft() { return H && H.soft; }, get runner() { return runner; }, get cam() { return cam; } };
document.body.classList.toggle('slime', sa.mode === 'slime' || sa.flav === 'soft');
equip('KittyBread', true);
addEventListener('resize', () => { if (H && (ACT.kind === 'knead' || KN.keep)) { KN.fit = kneadFit(); ui(); } });
ui();
requestAnimationFrame(loop);
document.body.classList.add('ready');
