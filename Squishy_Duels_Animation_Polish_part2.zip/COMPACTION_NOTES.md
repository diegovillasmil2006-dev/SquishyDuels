# Compaction notes

Made so the project fits GitHub's web upload limit (under 100 files per upload). Nothing unique was removed.

## Duplicates removed (video data verified identical)
- uploads/squish animation-ee716cfd.mp4  (same as uploads/squish animation.mp4)
- uploads/clip-1791497182692-t9sx.mp4    (same as uploads/squish animation.mp4)
- uploads/Video Project 2-18f219d6.mp4   (same as uploads/Video Project 2.mp4)

## Bundled
- shots/ (110 screenshots) -> shots.zip (stored without recompression, same images). Unzip it to get the shots/ folder back.
