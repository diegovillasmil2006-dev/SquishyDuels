# Big-number progression: design spec

Date: 2026-10-12 · Status: **waiting for your yes** · Every number is a proposal [P], tested only in a simulation.
This replaces the capsule numbers in `2026-10-11-lobby-bases-capsules-design.md` §5. The map, the bases and how capsules look and move stay as they are there.

## 1. What the reference games do (Steal an Egg, Steal a Brainrot, Ride a Pet, Dig a Pet)
- The loop is always the same: earn → buy something better → earn faster.
- Every step costs much more than the last (Steal an Egg's treadmill: 15–40×) but pays only a few times more (2–2.5×), so each step takes a bit longer. That's the grind.
- The jumps feel huge because several boosts multiply each other (pet × tier × rarity).
- Numbers grow from tens to trillions, and the next thing is always just out of reach.
- We copy the shape, not their names or numbers. No rebirths: your brief said no (see the questions at the end).

## 2. Decisions
1. **Big jumps in everything** (you, 2026-10-12): Coins and Grip grow from tens to quadrillions.
2. **One number drives everything: the squeeze value** = squishy power × capsule power. Capsules, your own taps and every reward come from it.
3. **Capsules: 10 tiers × 10 levels** (Lv1–100). Every new tier is a new look and a big jump.
4. **Squishies: power by rarity** (×1, ×4, ×16, ×64) and new prices spread across the whole game, like a ladder. **Each squishy fits in one capsule at a time.**
5. **Prices are fixed**, so you outgrow them. **Rewards grow with you**: they're counted in squeezes.
6. **Removed: the capsule hourly cap.** It stopped farming. Active play still pays more, because taps and duels add on top of the capsules.
7. **Kept:** no Robux anywhere in this, no pay while offline, no rebirths, no timers that push spending.

## 3. The squeeze value
- **Capsule power** CP(L) = round(10 × 1.13^(L−1) × 2^(tier−1)). Lv1 = 10, Lv100 = 921M.
- **Squishy power:** Common ×1 · Uncommon ×4 · Epic ×16 · Exclusive (Dragon) ×64. Replaces `CoinsByRarity` (1 / 1 / 2 / 2).
- **A capsule squeeze pays** Coins = squishy power × CP, and Grip = CP.
- **Your own squeezes** (tap, hold) pay the same as your best capsule, whichever squishy you're holding. That way you can duel with any squishy and still earn the same.
- In your base, every tap also pushes each capsule 0.15 of a squeeze forward (lobby spec).

## 4. Capsule tiers
| Tier | Look | Levels | Squeezes every | Coins per squeeze, Common (first → last level) | Evolve price | Needs Grip | Reached: active | Reached: AFK only |
|---|---|---|---|---|---|---|---|---|
| 1 | Foam | 1–10 | 4.0 s | 10 → 30 | start | — | start | start |
| 2 | Jelly | 11–20 | 3.5 s | 68 → 204 | 28K | Lv 10 | 25 min | 4.0 h |
| 3 | Marshmallow | 21–30 | 3.1 s | 461 → 1.39K | 520K | Lv 20 | 1.9 h | 11 h |
| 4 | Gummy | 31–40 | 2.7 s | 3.13K → 9.4K | 9.8M | Lv 30 | 3.5 h | 23 h |
| 5 | Taffy | 41–50 | 2.4 s | 21.2K → 63.8K | 182M | Lv 40 | 6.3 h | 32 h |
| 6 | Caramel | 51–60 | 2.1 s | 144K → 433K | 3.4B | Lv 50 | 10 h | 50 h |
| 7 | Bubblegum | 61–70 | 1.9 s | 979K → 2.94M | 64B | Lv 60 | 15 h | 63 h |
| 8 | Rainbow | 71–80 | 1.6 s | 6.65M → 20M | 1.18T | Lv 70 | 24 h | 94 h |
| 9 | Crystal | 81–90 | 1.4 s | 45.1M → 136M | 22T | Lv 80 | 32 h | 132 h |
| 10 | Royal | 91–100 | 1.3 s | 306M → 921M | 420T | Lv 90 | 53 h | 223 h |

- With Dragon in the capsule, multiply the Coins by 64 (Royal Lv100: 58.9B Coins per squeeze).
- Looks: Foam cream · Jelly glossy red · Marshmallow white with toasted trim · Gummy see-through green · Taffy pink and white stripes · Caramel amber · Bubblegum bright pink · Rainbow stripes · Crystal icy and see-through · Royal purple and gold. The four old looks stay as tiers 1, 2, 3 and 10.

## 5. Level prices
- Price from L to L+1 = 1,000 × 1.34^(L−1), rounded to 2 digits. The evolve levels (10 → 11, 20 → 21 … 90 → 91) cost 2× that.
- Each level costs 1.34× the last but pays about 1.13× more, so every level takes a little longer.

| Level | Price |
|---|---|
| 1 → 2 | 1K |
| 2 → 3 | 1.3K |
| 5 → 6 | 3.2K |
| 9 → 10 | 10K |
| 10 → 11 | 28K (evolve) |
| 11 → 12 | 19K |
| 20 → 21 | 520K (evolve) |
| 30 → 31 | 9.8M (evolve) |
| 40 → 41 | 182M (evolve) |
| 50 → 51 | 3.4B (evolve) |
| 60 → 61 | 64B (evolve) |
| 70 → 71 | 1.18T (evolve) |
| 80 → 81 | 22T (evolve) |
| 90 → 91 | 420T (evolve) |
| 95 → 96 | 890T |
| 99 → 100 | 2.9Qa |

One capsule from Lv1 to Lv100 costs 11.5Qa in total and all 4 cost 46.1Qa, spent bit by bit. The biggest single price is 2.9Qa, under the 9Qa cap.

## 6. Squishy ladder
| Rarity | Squishies | Capsule power | Price now | New price | First one bought (active) |
|---|---|---|---|---|---|
| Common | Toast, Banana, Boba Bear, Pancake Pup (Kitty Bread stays free) | ×1 | 1,200 | 10K | 13 min |
| Uncommon | Butter, Chocolate, Mochi Fox, Strawberry Frog | ×4 | 2,500 | 2.7M | 2.7 h |
| Epic | Birdie, Donut, Cloud Bunny, Cupcake Axolotl | ×16 | 7,500 | 1.7B | 8.6 h |
| Exclusive | Dragon | ×64 | 25,000 | 1.1T | 23 h |

- A squishy sits in one capsule at a time, so you want 4 good ones. Four capsules with Dragon + 3 Epics is the long goal.
- Powers live in `Catalog` (`squeezeCoins` becomes `power`), so one squishy can be tuned later without touching the others.

## 7. Slots
Slot 2: 2.5K · Slot 3: 80K · Slot 4: 1.5M, unlocked in order. A new capsule starts at Lv1 and catches up fast, because early levels are cheap.

## 8. Boxes
The price rule stays: a squishy's shop price is never more than what you'd expect to spend in boxes to get it (`Pricing.ceiling`). Squishy prices are now far apart, so each box covers a narrower range:

| Box | Price (now) | Contents and odds |
|---|---|---|
| Snack | 150K (400) | Commons 80% (20% each), Uncommons 20% (5% each). Epics move out. |
| Sweet | 450M (1,500) | Uncommons 60% (15% each), Epics 39.96% (9.99% each), Dragon 0.04% |
| Treat (free on day 7) | free | unchanged: Commons 56%, Uncommons 34%, Epics 10% |

- Rule check: Snack Uncommon 150K × 10,000 / 500 = 3M ≥ 2.7M ✓ · Sweet Epic 450M × 10,000 / 999 = 4.5B ≥ 1.7B ✓ · Sweet Dragon 450M × 10,000 / 4 = 1.125T ≥ 1.1T ✓.
- Weights: Snack 4 × 2,000 + 4 × 500 · Sweet 4 × 1,500 + 4 × 999 + 4 (each sums to 10,000).
- **Doubles:** a double gives back a quarter of the box price (Snack 37.5K, Sweet 112.5M; Treat: a quarter of the Snack price). This replaces refunds by rarity.

## 9. Rewards, counted in squeezes
Reward in Coins = squeezes × your squeeze value. A new player's squeeze is 10 Coins, so Daily day 1 = 100 squeezes = 1,000 Coins.

| Reward | Squeezes |
|---|---|
| Duel win / draw / loss | 600 / 300 / 180 (3× today's 200 / 100 / 60) |
| Daily days 1–7 | 100, 150, 200, 250, 300, 400, 500 (same numbers as today) |
| Daily quests | same numbers as today (100–450) |
| Starter tasks | same numbers as today (50–150) |

- Duels are ×3 so an hour of duels (about 20 matches) pays about the same as an hour of holding squeeze: 7,800 vs 8,000 squeezes. Today duels pay a third of that.
- The same-opponent rule stays (×0.25 after 6 results with one player in an hour).

## 10. Grip
- Grip per squeeze = capsule power (10 at the start, the same as today's first trainer). Double Grip still doubles your own squeezes.
- Levels 1–100 (was 1–50). Totals: Lv10 76K · Lv20 1.1M · Lv30 11M · Lv40 140M · Lv50 1.1B · Lv60 13B · Lv70 150B · Lv80 1.2T · Lv90 21T · Lv100 380T. The full list is at the end.
- Each tier needs a Grip level: Jelly Lv10, Marshmallow Lv20, … Royal Lv90. In the simulation, active players are never held back by it (they hit it before they have the Coins).
- New ranks: Legend 60 · Mythic 70 · Cosmic 80 · Galaxy 90 · Infinite 100 (Soft, Firm, Strong, Iron, Titan and Master stay at 1–50).

## 11. Pacing (simulation)
- **Active:** each hour 30 min holding squeeze in your base + 30 min of duels; capsules always on; buys the best deal.
- **AFK only:** capsules only, no taps, no duels.

| Milestone | Active | AFK only |
|---|---|---|
| First upgrade | 1 min | 7 min |
| Slot 2 (+ a Common) | 13 min | 2.6 h |
| Jelly | 25 min | 4.0 h |
| Slot 3 | 65 min | 7.2 h |
| Marshmallow | 1.9 h | 11 h |
| First Uncommon | 2.7 h | 19 h |
| Slot 4 | 2.9 h | 17 h |
| Gummy | 3.5 h | 23 h |
| Taffy | 6.3 h | 32 h |
| First Epic | 8.6 h | 45 h |
| Caramel | 10 h | 50 h |
| Bubblegum | 15 h | 63 h |
| Dragon | 23 h | 92 h |
| Rainbow | 24 h | 94 h |
| Crystal | 32 h | 132 h |
| Royal | 53 h | 223 h |
| Everything maxed | 130 h | 458 h |

- Income per hour (active): after 1 h 1.76M · 10 h 16B · 50 h 119T · 100 h 746T.
- Longest wait between two buys (active): first hour 5 min · 1–10 h 46 min · 10–50 h 1.6 h · after 50 h 4.1 h.
- Coins earned over the whole run (spent along the way): 46.1Qa. The most a player holds at once: 2.91Qa.

## 12. Limits and display
- **Max Coins** 1B → **9 Qa** (9,000,000,000,000,000). Luau numbers are exact up to about 9.007 Qa, so whole Coins stay exact.
- **Max Grip** 1B → 9 Qa.
- `Format.coins` gets B, T and Qa: "1.23B", "45.6T", "2.85Qa" (still cut, never rounded up).
- **Guards:**
  - G3 becomes a squeeze count: 43,200 an hour, the anti-autoclicker cap. It's no longer a Coin number, because Coins per squeeze now grow.
  - The 50,000 Coins/h alert becomes 30,000 squeezes/h.
  - `maxGripPerEvent` = CP(100) × 2 = 1.84B, and `gripAlertPerHour` = 43,212 × that.
  - G7b stays: Coin bundles stay off (`allowBundlesWithCapsules = false`). The bundle amounts need redoing before Robux is ever turned on.

## 13. Code changes (Claude Code announces each one and waits for your yes; snapshot first)
- `Config/Economy.luau`: maxCoins; `CoinsByRarity` → `SquishyPower`; duel rewards, daily and quests in squeezes; refunds per box (25%); "capsule" Coin reason.
- `Config/Grip.luau`: maxGrip; maxLevel 100; LevelTotals; Ranks; new `Capsule` block (tiers, times, CP, prices, Grip gates, slots). Pads, trainers, slow training and gates go (lobby spec §13).
- `Catalog.luau` (new prices, power) · `Boxes.luau` (Snack and Sweet) · `Pricing.luau` (`duplicateRefund(boxId)`) · `QuestDefs.luau` (rewards are squeezes) · `Util/Format.luau` (B/T/Qa).
- `GripMath` + a new `CapsuleMath` (squeeze value, prices, tiers) · Strings (tier names, ranks, "×16 power") · UI (capsule card shows tier and level; shop cards show capsule power).
- Profile: version bump + migration (§14). Validators: G1 (100 levels), G3, G5, G7b and the box price rule.

## 14. Old saves
- Coins and squishies are kept. Trainer Coins are refunded (lobby spec).
- Nobody's Grip level drops: Grip goes up to the new total for their old level.
- If no real players have played yet, skip this.

## 15. Tests
- **Unit:**
  - CP is 10 at Lv1 and rises every level.
  - Prices only go up, and evolves cost 2×.
  - The Grip gates work.
  - The squeeze value uses your best capsule.
  - Rewards = squeezes × value.
  - Box weights sum to 10,000 and pass the price rule; a double gives back 25%.
  - Format shows K, M, B, T and Qa, and is cut, not rounded.
  - Coins stop at 9 Qa.
  - Old saves migrate (§14).
- **Studio** (after your OK): a test account plays through Marshmallow. Check the pops, the capsule card, the shop prices and the boxes.

## 16. Open questions
1. **Rebirths?** Your brief said no. Those games use rebirths for the very long grind.
2. **Duels ×3** (600 / 300 / 180 squeezes)?
3. **The box changes** (Epics leave the Snack Box; Dragon drops to 0.04% in the Sweet Box)?

## Appendix: Grip level totals (Lv1–100)
- Lv1–10: 0 · 1,000 · 1,700 · 3,000 · 5,100 · 8,700 · 15,000 · 26,000 · 44,000 · 76,000
- Lv11–20: 100,000 · 130,000 · 170,000 · 220,000 · 290,000 · 380,000 · 500,000 · 650,000 · 850,000 · 1,100,000
- Lv21–30: 1,400,000 · 1,800,000 · 2,200,000 · 2,800,000 · 3,600,000 · 4,500,000 · 5,700,000 · 7,200,000 · 9,100,000 · 11,000,000
- Lv31–40: 15,000,000 · 19,000,000 · 25,000,000 · 32,000,000 · 41,000,000 · 52,000,000 · 67,000,000 · 87,000,000 · 110,000,000 · 140,000,000
- Lv41–50: 180,000,000 · 220,000,000 · 270,000,000 · 330,000,000 · 400,000,000 · 500,000,000 · 610,000,000 · 750,000,000 · 920,000,000 · 1,100,000,000
- Lv51–60: 1,400,000,000 · 1,800,000,000 · 2,300,000,000 · 3,000,000,000 · 3,800,000,000 · 4,900,000,000 · 6,200,000,000 · 8,000,000,000 · 10,000,000,000 · 13,000,000,000
- Lv61–70: 17,000,000,000 · 21,000,000,000 · 27,000,000,000 · 35,000,000,000 · 44,000,000,000 · 57,000,000,000 · 72,000,000,000 · 92,000,000,000 · 120,000,000,000 · 150,000,000,000
- Lv71–80: 190,000,000,000 · 230,000,000,000 · 280,000,000,000 · 340,000,000,000 · 420,000,000,000 · 510,000,000,000 · 630,000,000,000 · 770,000,000,000 · 950,000,000,000 · 1,200,000,000,000
- Lv81–90: 1,600,000,000,000 · 2,100,000,000,000 · 2,800,000,000,000 · 3,700,000,000,000 · 4,900,000,000,000 · 6,600,000,000,000 · 8,800,000,000,000 · 12,000,000,000,000 · 16,000,000,000,000 · 21,000,000,000,000
- Lv91–100: 28,000,000,000,000 · 38,000,000,000,000 · 50,000,000,000,000 · 67,000,000,000,000 · 90,000,000,000,000 · 120,000,000,000,000 · 160,000,000,000,000 · 210,000,000,000,000 · 290,000,000,000,000 · 380,000,000,000,000
