# Lobby bases + capsules: design spec (v2)

Date: 2026-10-11 · Status: **waiting for your yes** · [P] = proposal, not playtested yet.

## 0. What I read
- From the SquishyDuels folder: Config (Economy, Grip, Squeeze, Duel, Net, Monetization), SqueezeLimit, GripMath, Catalog and the folder layout. Every number below comes from there.
- This folder works Studio-first. Its CLAUDE.md says "Studio is the source of truth" and "No Rojo". Several paths in the brief don't exist here (src/editor, src/tests, tools/check.ps1, docs/). The real places are:
  - lobby builder: `ServerStorage/SDTools` (Main, Builders/LobbyBuilder, Kit, Verify)
  - tests: `ServerStorage/UnitTest/Cases` (RunUnitTest)
  - config: `ReplicatedStorage/Shared/Config/*`, `Shared/World/WorldLayout`, `Shared/Art/Palette`, `Shared/Strings`
  - services: `ServerScriptService/Server/Services` · client: `StarterPlayerScripts/Client`
- **Missing:** DESIGN.md and PROGRESS.md aren't in this folder. The § numbers below come from code comments.

## 1. Decisions
From the brief:
1. No stealing. Every player has their own base. Visitors can look but can't do anything.
2. Capsules pay Coins and Grip on their own.
3. Capsules work like treadmills: they squeeze a squishy automatically, upgrade with Coins, and speed up when you tap.
4. Blocky, LEGO-style decor.

Your answers:
5. Taps push your capsules only while you stand in your own base.
6. Capsules replace the 3 giant pads and the 8 trainer upgrades. The pads become capsule **looks** at capsule Lv5, 15 and 30.
7. Any squishy you own can go in a capsule, and rarer ones pay a bit more. You get 1 capsule free and can unlock up to 4 in total with Coins.
8. *(Removed 2026-10-12: no hourly cap.)* Capsules can pay up to **75%**. ⚠ See 5.4: I measured this against holding-squeeze, not against duels.
9. **10 bases** on a smaller island. Servers hold 10 players instead of 20.
10. **Bright colours** like the references. *(Your pick came back as "option_1", which I read as Bright. If you meant Pastel, I'll switch it.)*

What the code changed about the first draft:
- Duels are 1v1 (3 lives, 120 s), so 10 players fill 5 duels at once. No problem there.
- Squeezing already pays Coins with no hourly limit (your change today, spec 2026-10-11 §5). Holding-squeeze pays about **8,000 Coins/h** with a Common. Duels pay about **2,600/h** (around 20 matches, half of them won).
- All 14 squishies are in the Catalog, so every prop below is named after a real one.

## 2. Map (top-down, studs)
```
                               N (0°)
                ~  ~  ~  ~  ~  water  ~  ~  ~  ~  ~
           ~                  [B1]                    ~
       ~         [B10]                   [B2]            ~
     ~                .-----------------------.             ~
   ~     [B9]       /  Fountain   Shop    Box       [B3]      ~
  ~                |                             |               ~
W ~   [B8]         |  Mats  [ DUEL TOWER ]  Range |      [B4]    ~  E
  ~                |                             |               ~
   ~     [B7]         Coll.    Daily    Quests /    [B5]      ~
     ~                '-----------------------'             ~
       ~                      [B6]                       ~
           ~          sand beach, r 160–176           ~
                ~  ~  ~  ~  ~  ~  ~  ~  ~  ~  ~
                               S (180°)
  [B] = base, 44 × 52 · 10 bases in a ring, 36° apart · every gate faces the tower
```

| Zone | Size (studs) |
|---|---|
| Island | grass to r 160, beach to r 176 (Ø 352). The old 20-base plan was Ø 512 |
| Squish Square (hub) | Ø 140, raised 0.9, white curb |
| Duel stage | Ø 44, under the tower, same 10 queue pads |
| Duel tower (landmark) | 4 pillars 7 × 7 at (±14, ±14), deck at 36, blocky Dragon on top, about 68 tall |
| Name painted on the ground | "SQUISH SQUARE", in a ring at r 26–36 |
| Garden ring | r 70–96, 10 paths (8 wide) from the hub to the gates |
| Bases | 44 × 52, gates at r 96, backs at r 148, 36° apart |
| Gaps between bases | 17 st at the gates, 50 st at the backs (trees, rocks, sea views) |
| Walking | gate → Duel stage 74 st ≈ 4.6 s · spawn → Duel stage 116 st ≈ 7.3 s (WalkSpeed 16) |

## 3. Hub stations (stalls at r 46, set between the paths so every path has a clear view of the tower)
| Angle | Station | Change |
|---|---|---|
| centre | Duel queue | moves under the tower, same rules |
| 18° | Shop | stall with a striped awning |
| 54° | Squishy Box | stall with a giant gift box on top |
| 90–126° | Practice range | 44-st lane along the hub edge, 3 dummies |
| 162° | Quests | stall with a notice board |
| 198° | Daily | stall with a 7-day calendar block |
| 234° | Collection | stall with a toy shelf |
| 270–306° | Foam mats | 6 mats + giant Kitty Bread (kept, tier 1) |
| 342° | Butter Fountain | mid-size prop, not a station |
| removed | 3 giant pads + Jelly gates | become capsule looks (5.2) |

## 4. Base layout (44 × 52, local +z faces the hub)
```
 back, r 148
 z −26 ┌─────── back wall 44 × 9 · big statue of the squishy in capsule 1 ───────┐
       │  Birdie nest planter        [spawn] faces the gate         Toast bench  │
 z −8  │     ( C1 ) free             ┊ path ┊              ( C2 )              │
       │                             ┊ 8 st ┊                                  │
 z +8  │     ( C3 ) price + lock     ┊      ┊              ( C4 ) price + lock  │
       │  Chocolate flower box       ┊      ┊         Kitty Loaf mailbox        │
 z +26 └─ fence ─────── [ Donut Arch gate · 16 wide · name sign ] ───── fence ──┘
 front, r 96 → path to the hub
```
- Capsules sit at x = ±13 on 8 × 8 pads. From spawn, the camera looks between the 4 capsules, out through the gate, to the tower. Visitors who come in through the gate see the statue at the end of the path.
- Floor: a 1-st plinth in a light shade of the owner colour, studs on top, rim in the full colour. Fence: white rails, posts every 8 st with caps in the owner colour.
- An empty plot (nobody on it): grey floor, "Open plot" sign, empty pads, no statue.
- You spawn here when you join and every time you respawn.

## 5. Capsules
> **Numbers replaced 2026-10-12:** the rules, upgrade table and pacing below (5.4–5.6) are replaced by `2026-10-12-big-number-progression-design.md`: 10 tiers × 10 levels, no hourly cap, one squishy per capsule. 5.1–5.3 (build, looks, feel) still apply; the four looks become tiers 1, 2, 3 and 10.

**5.1 Build** (about 16 parts plus the squishy model): a drum (Ø7 × 1.5), a glass tube (Ø6 × 7, see-through), a cap and a press, the squishy inside (3.5 st tall), a ring on the drum that fills up until the next squeeze, trim in the look's colour, and a level plate.

**5.2 Looks** (the old pads, same numbers as `Config.Grip.Pads`)
| Look | Capsule level | Needs Grip level | Coins per squeeze | Grip per squeeze |
|---|---|---|---|---|
| Foam | 1–4 | — | +0 | ×1 |
| Jelly | 5–14 | 5 | +1 | ×1.5 |
| Marshmallow | 15–29 | 15 | +2 | ×2 |
| Royal | 30 | 30 | +3 | ×3 |

**5.3 Feel:** the press comes down in 0.16 s, holds for 0.14 s and rises in 0.32 s. The squishy squashes to 58% height and 125% width, then springs back to 112% height and wobbles. On the hit, the owner sees "+2 Coins +30 Grip" pop up. Visitors see the squash and a sparkle but no numbers. A tap gives every capsule a small 8% squish. An upgrade gets a ring flash, the squishy spins and stretches, brick confetti flies, and the level plate pops. A new look gets a bigger burst and the tube changes.

**5.4 Rules** [P]
- **Speed:** a capsule squeezes every 6 s × 0.96^(Lv−1), so 6.0 s at Lv1 and 1.84 s at Lv30.
- **Pay per squeeze (whole numbers):** Coins = the squishy's squeeze Coins (`CoinsByRarity`: Common 1, Uncommon 1, Epic 2, Exclusive 2) + the look bonus. Grip = the capsule's Grip power × the look.
- **Grip power** goes from 10 at Lv1 to 100 at Lv30 (10 × 10^((Lv−1)/29)). It replaces the trainers (10 → 100).
- **Your own squeezes:** your taps get the Grip power of your best capsule (this replaces your trainer level). While you're **in your own base**, taps also get your best look's bonus, like standing on a pad used to, and every tap pushes each capsule 0.15 of a squeeze forward. The existing anti-autoclicker limit (12 a second) still applies.
- ⚠ **Coin cap per hour** = 75% of an hour of holding-squeeze at your best look: **6,000 / 12,000 / 18,000 / 24,000** (Foam / Jelly / Marshmallow / Royal). You picked "75% of an hour of duels". Measured that way the cap is only about 2,000, and 3 starter capsules hit it, so upgrades would stop paying. Measured against holding-squeeze, capsules really are a big earner, but they never beat squeezing yourself. Tell me if you'd rather keep the duel version.
- **Grip cap per hour:** 25% of your holding rate. This is today's slow-training limit (`Afk.maxShareOfActive`, G9), unchanged.
- The cap counts everything capsules pay, from waiting and from taps. Your own taps aren't capped. The hour starts with the first capsule payment and is **saved in your profile**, so leaving and rejoining doesn't reset it.
- No offline pay. No Double Grip on capsule squeezes (like slow training today).
- **Slots:** slot 2 costs 1,500, slot 3 costs 8,000, slot 4 costs 30,000, unlocked in order. **Upgrade** Lv→Lv+1 costs round(300 × 1.2^(Lv−1)).

**5.5 Upgrade table** (one capsule)
| Lv | Squeezes every | Squeezes/h | Look | Coins/squeeze Common / Epic | Grip/squeeze | Coins/h Common | Grip/h | Cost to next |
|---|---|---|---|---|---|---|---|---|
| 1 | 6.00 s | 600 | Foam | 1 / 2 | 10 | 600 | 6,000 | 300 |
| 2 | 5.76 s | 625 | Foam | 1 / 2 | 11 | 625 | 6,875 | 360 |
| 3 | 5.53 s | 651 | Foam | 1 / 2 | 12 | 651 | 7,813 | 432 |
| 4 | 5.31 s | 678 | Foam | 1 / 2 | 13 | 678 | 8,816 | 518 |
| 5 | 5.10 s | 706 | Jelly | 2 / 3 | 21 | 1,413 | 14,835 | 622 |
| 8 | 4.51 s | 798 | Jelly | 2 / 3 | 25.5 | 1,597 | 20,361 | 1,075 |
| 10 | 4.16 s | 866 | Jelly | 2 / 3 | 30 | 1,733 | 25,992 | 1,548 |
| 12 | 3.83 s | 940 | Jelly | 2 / 3 | 36 | 1,880 | 33,843 | 2,229 |
| 15 | 3.39 s | 1,063 | Marshmallow | 3 / 4 | 60 | 3,188 | 63,754 | 3,852 |
| 18 | 3.00 s | 1,201 | Marshmallow | 3 / 4 | 78 | 3,603 | 93,677 | 6,656 |
| 20 | 2.76 s | 1,303 | Marshmallow | 3 / 4 | 90 | 3,909 | 117,284 | 9,584 |
| 22 | 2.55 s | 1,414 | Marshmallow | 3 / 4 | 106 | 4,242 | 149,886 | 13,802 |
| 25 | 2.25 s | 1,598 | Marshmallow | 3 / 4 | 134 | 4,795 | 214,164 | 23,849 |
| 28 | 1.99 s | 1,806 | Marshmallow | 3 / 4 | 170 | 5,419 | 307,098 | 41,211 |
| 29 | 1.91 s | 1,882 | Marshmallow | 3 / 4 | 184 | 5,645 | 346,238 | 49,453 |
| 30 | 1.84 s | 1,960 | Royal | 4 / 5 | 300 | 7,841 | 588,040 | max |

One capsule from Lv1 to Lv30 costs 295,221 Coins (the trainers cost 332,000). All 4 plus the slots cost 1,220,384.

**5.6 Pacing** (simulated play: each hour 30 min holding-squeeze at home + 30 min of duels, capsules running all the time; the player buys the next slot as soon as they can, otherwise the cheapest upgrade)
| | Common squishies | Epic squishies |
|---|---|---|
| First upgrade | 2 min | 1 min |
| Slot 2 · 3 · 4 | 14 min · 2.2 h · 7.1 h | 7 min · 77 min · 5.1 h |
| Jelly look | 24 min | 12 min |
| Marshmallow look | 3.5 h | 2.3 h |
| Royal look (needs Grip Lv30) | 36.2 h | 31.1 h |
| Everything maxed | 40 h | 34 h |
| Longest wait between buys, before Lv25 | 60 min | 55 min |
| Longest wait, Lv25–30 | 1.8 h | 1.7 h |

**5.7 Old saves:** Coins spent on trainers come back as Coins on the first join after the update (reason "refund"), with a toast saying "Your trainer Coins are back. Spend them on your capsules."

## 6. Server and data
- **BaseService** (new): when a player joins, it gives them the lowest free plot, puts their name on the sign and spawns them there. When they leave, the plot goes back to "Open plot". When they rejoin, their levels come back (the plot number can be different). If no plot is free, it tries again for up to 5 s and spawns them in the hub meanwhile.
- **CapsuleService** (new): a server tick every 0.25 s moves progress forward and pays through EconomyService and GripService, after the cap check. It counts squeezes in an attribute (`SD_Squeezes`), so clients play the animation without extra remotes.
- **Remotes** (`Config.Net`): CapsuleUpgrade(slot, expectedPrice), CapsuleUnlock(slot, expectedPrice) and CapsuleSet(slot, squishyId), with the same limits as TrainerUpgrade (1 a second, one at a time). Taps keep using SqueezeRequest, and the server checks that the root part is inside the caller's own base. **No remote takes a base id**: the server only ever touches the caller's own base. It checks types, slot 1–4, that the player owns the squishy, the price, Grip gates and the next-level order, and that the player isn't in a duel. It reuses `GripMath.upgradeDecision`'s order of checks.
- **Coin reason:** add "capsule" to `Economy.CoinReasons`.
- **Profile:** `capsules = { slots, list = { { level, squishyId } }, hour = { start, coins, grip } }`. Bump the profile version and add a migration for the trainer refund (in Server/Data).

## 7. Decor props (one or more per squishy, all anchored parts)
| Prop | Squishy | Where | Parts |
|---|---|---|---|
| Dragon Spire (top of the tower) | Dragon | hub centre, the landmark | ~60 |
| Donut Arch gate | Donut | every base gate | ~20 |
| Kitty Loaf Mailbox | Kitty Bread | every base | 6 |
| Toast Bench · Toast Stack Tower | Toast | bases · garden at 18° | 8 · 30 |
| Banana Slide | Banana | garden at 90° | 28 |
| Butter Fountain | Butter | hub at 342° | 18 |
| Chocolate flower box · Chocolate bar benches | Chocolate | bases · hub (×6) | 6 · 10 |
| Birdie Nest Planter | Birdie | every base | 9 |
| Mochi Fox lanterns | Mochi Fox | the 10 path mouths at the hub | 8 |
| Frog Lily Pond (+ lily pads on the sea) | Strawberry Frog | garden at 198° | 30 |
| Boba Pearl bollards | Boba Bear | along the paths (×4 each) | 2 |
| Pancake Stack tables | Pancake Pup | hub (×4) | 8 |
| Cloud Bunny clouds | Cloud Bunny | sky (×6) | 6 |
| Cupcake trees | Cupcake Axolotl | garden, gaps between bases, beach | 9 |

Layers: the tower is the big landmark. Then mid-size props: stalls, arches, fountain, slide, pond, statues. Then small details: lanterns, bollards, flowers, brick sprinkles, lily pads.
**Part budget** [P]: hub up to 2,000 · each base up to 220 (capsules included) · garden, beach and sky up to 1,000 · **total up to 5,200**. Turn off collision where nobody walks, turn off touch on all of it, and turn off shadows on parts smaller than 2 st. Studs come from Roblox's own Studs surface (nothing to upload; I'll check it still renders).

## 8. Colours (new entries in Palette.luau) [P]
- Ground: grass #5CCB4E, grass edge #3E9E3A, sand #F5DC9B, sea #2BA7E3, shallow water #6FD3F5. Hub: tiles #F6F7F9 and #E3E8EF, curb #FFFFFF, wood #A8673A.
- 10 base colours, one per plot (B1 → B10): red #E8343F, orange #FF8A1F, yellow #FFC51F, lime #9BE22B, teal #1FC7B6, sky #38B6FF, blue #2E7BF0, navy #2B3A8C, purple #8E4FE0, pink #FF5FA2.
- The Duel pads keep the team colours, mint #5FD3AE and strawberry #F2687F.

## 9. UI (fits the current HUD)
- **Capsule card:** opens when you tap or click a capsule, or press E near one. That tap doesn't count as a squeeze. It shows the squishy (tap to swap), the level, squeeze time now → next, Coins/h and Grip/h, and one big Upgrade button with the price. At Lv4, 14 and 29 it also shows a preview of the next look and its Grip-level lock.
- **Locked slot:** "Unlock · 8,000" with a lock icon.
- **Visitors** see the same card, read-only: "Only Mia can upgrade this."
- *(Removed 2026-10-12, no cap.)* **Cap bar:** a thin bar under the Coin counter while capsules pay: "Capsules this hour: 4,120 / 12,000". When it's full, the text says "Full. Squeeze yourself to keep earning." No countdowns that push spending, no Robux prompts.
- New text keys `capsule.*` and `base.*` go in Strings.luau.

## 10. Analytics (proposed only, not built; still undecided)
base_assigned · capsule_slot_unlocked · capsule_upgraded {level, look} · capsule_cap_reached · capsule_tap_session {taps} · base_visited {owner ≠ visitor}

## 11. Robux guards (Robux is still off; this adds no products)
- G7b: `allowBundlesWithTrainer` becomes `allowBundlesWithCapsules = false`. Coin bundles stay off while capsules turn Coins into Grip power.
- G7: add "capsule" to the training words that no bundle or pass name may use.
- G3: the capsule cap (24,000 at most) stays under `maxSqueezeCoinsPerHour` (216,000). The 50,000/h warning log now counts capsule Coins too.
- Exclusive pays the same as Epic, so a squishy sold for Robux later could never pay more.

## 12. Doc changes (in DESIGN.md and PROGRESS.md, once I know where they are)
- §17.0: "Idle play never pays Coins" becomes "Only your base capsules pay Coins while you're idle, only while you're in the server, up to the hourly cap."
- §15: change log for 2026-10-11 (the §17.0 change, the pads and trainers removed, 10-player servers).
- §7 / §7.5: the candy plaza is replaced by the island map above.
- §17.3.6 slow training → capsules (G9 limit kept) · §17.5 trainers → capsule levels · §17.6 Jelly gates removed.
- PROGRESS: step M5 goes from 20 to 10 players, and the decisions log gets decisions 1–10. The polish list doesn't change.
- **Server size:** you change it yourself (Game Settings → Places → Server Size = 10). I won't touch settings.

## 13. Removals (each needs your yes before it's deleted)
- the giant pads (`WorldLayout.GiantPads`, squeeze_07–09, `Config.Anim.giantPad`, rule G10)
- the Jelly gates (`Config.Grip.Gate`)
- slow training (`Config.Grip.Afk`, `GripMath.afkGrip / afkMinutes`)
- the trainers (`Config.Grip.Trainer`, the TrainerUpgrade remote, the trainer parts of GripMath and GripService)
- their builders in LobbyBuilder, their client controller and their tests

Before deleting anything, Claude Code lists every file and caller and shows you the list.

## 14. Test plan
**Unit tests** (UnitTest/Cases):
- the speed gets faster every level
- pay per squeeze and the look bonus match the table
- Grip gates block the next look
- both caps stop pay, and the saved hour survives a rejoin
- taps push capsules only inside your own base
- slot order and prices
- a visitor, bad input, a wrong price and spam are all turned away
- save → load, plus the trainer refund
- the Robux guards above

**Studio** (only after you say OK to Play; Test → Local Server with 2–3 players):
- each player gets a named base, and it frees when they leave
- a visitor can't upgrade or swap
- Coins and Grip go up and stop at the cap
- levels come back after a rejoin
- all stations can be reached
- part count and frame time, before vs after

**Pictures:** top-down, a base close-up, the player view at 1920 × 1080 and 844 × 390, and the old lobby next to the new one.
