# Build plan: lobby bases + big-number progression

Date: 2026-10-12 · For Claude Code in the SquishyDuels repo · Status: **approved specs, plan waiting for your yes**
Specs:
- `docs/superpowers/specs/2026-10-11-lobby-bases-capsules-design.md` (the island, the bases, the capsules)
- `docs/superpowers/specs/2026-10-12-big-number-progression-design.md` (all the numbers)

## How every phase runs
1. Tell jjayx in simple words **what** you'll do, **why**, and **what it will change** (CLAUDE.local.md rule 2), then wait for a yes.
2. Take a snapshot `Snapshot: before <phase>` (rule 3; every phase here is a big change).
3. Work in Studio with the Studio MCP tools. No Rojo, and never edit `src/` or `world/` by hand. `script_read` a script right before you edit it, because the co-owner may be editing too (CLAUDE.md).
4. Run `RunUnitTest`. Everything must pass before you move on.
5. Take a snapshot after the phase and report back in 3–5 short, simple lines (rule 1).

## Before Phase 1
- The design docs (`SQUISHY_DUELS_*.md`) are on VillasmilGaming's PC (`C:\Users\diego\Desktop\ROBLOXSTEALAPIZZA\`). Ask jjayx to tell Diego about these specs. Diego either applies the doc edits in Phase 7, or sends the files.
- Tell VillasmilGaming before Phase 4 and Phase 6: they rebuild the lobby and remove systems.
- Load skills when you reach them: `game-feel` (Phase 5 pops and bursts), `roblox-ui` (Phase 5 screens).

## Phase 1: numbers only (no world changes)
- `Util/Format.luau`: `coins()` gets B, T and Qa, still cut and never rounded up.
- New `Shared/CapsuleMath.luau`, pure functions:
  - tier, interval, power and price per level
  - slot prices
  - squishy power
  - squeeze value (best capsule)
  - reward Coins = squeezes × value
  - the Grip gate per tier
- `Config/Grip.luau`:
  - maxGrip → 9 Qa, maxLevel → 100, the new LevelTotals (progression appendix), Ranks + 5
  - a new `Capsule` block holding the tiers, times, prices, gates and slots
  - pads, trainers, slow training and gates stay switched on until Phase 6
- `Config/Economy.luau`:
  - maxCoins → 9 Qa
  - `SquishyPower` 1 / 4 / 16 / 64
  - duel rewards 600 / 300 / 180 squeezes; daily and quests count in squeezes
  - refunds = 25% of the box price
  - the "capsule" Coin reason
- Shop, boxes and quests:
  - `Catalog.luau`: new shop prices, plus power.
  - `Boxes.luau`: the new Snack and Sweet weights and prices.
  - `Pricing.luau`: `duplicateRefund(boxId)`.
  - `QuestDefs.luau`: rewards read as squeezes; the numbers stay the same.
- `Config.validate`:
  - G1 covers 100 levels.
  - G3 becomes a squeeze count.
  - G5 uses the new `maxGripPerEvent`.
  - G7b is renamed `allowBundlesWithCapsules`.
  - The box price rule passes with the new numbers.
- Tests (`UnitTest/Cases`), as listed in progression spec §15:
  - Format
  - CapsuleMath tables
  - box sums and the price rule
  - refunds
  - the 9 Qa clamp

## Phase 2: save data
- Profile gets `capsules = { slots, list = { { level, squishyId } } }`, plus a version bump.
- Migration:
  - trainer Coins refunded
  - Grip raised so nobody's level drops
  - each squishy in one capsule only
- Tests: save → load round trip, migration of an old profile, a profile at the caps.

## Phase 3: server
- **BaseService:**
  - 10 plots.
  - On join: the lowest free plot, the name sign, spawn at the gate.
  - On leave: back to "Open plot". On rejoin: levels restored.
  - If no plot is free, retry for 5 s, with the player in the hub meanwhile.
- **CapsuleService:**
  - a 0.25 s tick advances each capsule and pays Coins (reason "capsule") and Grip
  - an `SD_Squeezes` attribute drives the client animation
  - home taps push every capsule 0.15 of a squeeze; they come from `SqueezeRequest` and count only inside the caller's own base
- **Remotes** (`Config.Net`):
  - `CapsuleUpgrade(slot, expectedPrice)`, `CapsuleUnlock(slot, expectedPrice)`, `CapsuleSet(slot, squishyId)`
  - checks: types, slot 1–4, the squishy is owned, the price, the Grip gate, the order, not in a duel; 1 a second, one at a time
  - **no remote ever takes a base id**
- **Squeezes and rewards:**
  - Your own squeeze pays the squeeze value and the Grip of your best capsule level. Double Grip still ×2.
  - Duels, daily, quests and starter tasks pay squeezes × value, worked out when the reward is given.
- **Tests:**
  - a visitor, bad input, a wrong price, spam and calls during a duel are refused
  - pay per tick matches CapsuleMath
  - taps outside your base don't push

## Phase 4: the island (world)
- `SDTools/Builders`: build Squish Island from lobby spec §2–4 and §7, with the colours from §8 in `Art/Palette`.
  - The stations keep working at their new places (`World/WorldLayout`).
  - Part budget: 5,200 at most.
- Capsule models get the 10 tier looks (progression §4).
- Studio check:
  - part count and frame time, before and after
  - pictures: top-down, a base, the spawn view on a phone and a PC
- Server size → 10: jjayx sets this in Game Settings (never change settings yourself).

## Phase 5: client
- Capsule feel (`game-feel`):
  - press, squash and spring back
  - Coin and Grip pops for the owner only
  - an upgrade burst and a bigger burst when the tier changes
- Capsule card (`roblox-ui`, built from `Client/UI`):
  - the squishy (tap to swap), tier and level, the next tier preview, Coins/h and Grip/h, one big Upgrade or Evolve button with the price
  - locked slot card; visitors see it read-only
- Shop cards show capsule power; the box odds panel shows the new odds.
- All numbers go through `Format.coins`; nameplate ranks go up to Lv100.
- Phone first: nothing covers the player or the play area.

## Phase 6: removals (a separate yes for each)
- Removed: the giant pads, the Jelly gates, slow training, the trainers and the TrainerUpgrade remote.
- First list every file and caller and show jjayx. Remove only after the yes, then update the tests.

## Phase 7: docs and final check
- DESIGN and PROGRESS edits from lobby spec §11 and the progression spec, done by whoever has the files.
- `RunUnitTest`: all pass.
- After jjayx says OK to Play: Local Server with 2–3 players. Check that:
  - every player gets a base, and it frees up when they leave
  - a visitor can't upgrade
  - Coins and Grip go up
  - levels come back after a rejoin
  - every station can be reached
  - a test account can reach Marshmallow
- Final snapshot, then a short simple report.
